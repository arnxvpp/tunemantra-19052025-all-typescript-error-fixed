# Royalty System Documentation\n\nThis directory contains documentation related to the royalty calculation and payment system in the TuneMantra platform.
