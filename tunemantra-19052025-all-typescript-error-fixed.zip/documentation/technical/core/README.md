# Core Documentation\n\nThis directory contains documentation related to the core components of the TuneMantra platform.
