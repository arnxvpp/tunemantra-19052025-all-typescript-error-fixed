# Blockchain Integration Service\n\nThis document details the blockchain integration service implemented in the TuneMantra platform.
