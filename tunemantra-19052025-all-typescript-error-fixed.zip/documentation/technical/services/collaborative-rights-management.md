# Collaborative Rights Management Service\n\nThis document details the collaborative rights management service implemented in the TuneMantra platform.
