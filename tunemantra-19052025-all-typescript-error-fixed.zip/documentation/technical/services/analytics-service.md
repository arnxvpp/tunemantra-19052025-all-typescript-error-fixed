# Analytics Service\n\nThis document details the analytics service implemented in the TuneMantra platform.
