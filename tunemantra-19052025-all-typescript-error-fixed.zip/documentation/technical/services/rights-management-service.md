# Rights Management Service\n\nThis document details the rights management service implemented in the TuneMantra platform.
