# Advanced Analytics Export Service\n\nThis document details the advanced analytics export service implemented in the TuneMantra platform.
