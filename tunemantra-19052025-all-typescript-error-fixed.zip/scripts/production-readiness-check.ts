/**
 * Production Readiness Check
 * 
 * This script verifies that the blockchain integration is ready for production use.
 * It runs a series of checks to ensure proper configuration and functionality.
 * 
 * Usage: npx tsx scripts/production-readiness-check.ts
 */

import { ethers } from 'ethers';
import dotenv from 'dotenv';
import fs from 'fs';
import path from 'path';

// Load the correct environment variables based on NODE_ENV
const env = process.env.NODE_ENV || 'development';
if (env === 'production') {
  dotenv.config({ path: '.env.production' });
} else {
  dotenv.config({ path: '.env.development' });
}

// Define colors for console output
const colors = {
  reset: '\x1b[0m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
  white: '\x1b[37m'
};

// Logging utilities
function logSection(title: string) {
  console.log(`\n${colors.blue}=== ${title} ===${colors.reset}\n`);
}

function logSuccess(message: string) {
  console.log(`${colors.green}✓ SUCCESS: ${message}${colors.reset}`);
}

function logError(message: string) {
  console.log(`${colors.red}✗ ERROR: ${message}${colors.reset}`);
}

function logWarning(message: string) {
  console.log(`${colors.yellow}⚠ WARNING: ${message}${colors.reset}`);
}

function logInfo(message: string) {
  console.log(`${colors.cyan}ℹ INFO: ${message}${colors.reset}`);
}

// Interface for storing test results
interface TestResult {
  name: string;
  passed: boolean;
  message: string;
}

// Required environment variables for blockchain functionality
const requiredEnvVars = [
  // Polygon Mumbai testnet
  'POLYGON_MUMBAI_RPC_URL',
  'POLYGON_MUMBAI_CHAIN_ID',
  'POLYGON_MUMBAI_RIGHTS_CONTRACT',
  'POLYGON_MUMBAI_NFT_CONTRACT',
  
  // Polygon Mainnet
  'POLYGON_MAINNET_RPC_URL',
  'POLYGON_MAINNET_CHAIN_ID',
  'POLYGON_MAINNET_RIGHTS_CONTRACT',
  'POLYGON_MAINNET_NFT_CONTRACT',
  
  // Ethereum Mainnet
  'ETH_MAINNET_RPC_URL',
  'ETH_MAINNET_CHAIN_ID',
  'ETH_MAINNET_RIGHTS_CONTRACT',
  'ETH_MAINNET_NFT_CONTRACT',
  
  // Account and API keys
  'ETH_ACCOUNT_ADDRESS',
  'ETH_ACCOUNT_PRIVATE_KEY',
  'IPFS_API_KEY',
  'IPFS_API_SECRET'
];

// Optional but recommended environment variables
const recommendedEnvVars = [
  'OPTIMISM_MAINNET_RPC_URL',
  'OPTIMISM_MAINNET_CHAIN_ID',
  'OPTIMISM_MAINNET_RIGHTS_CONTRACT',
  'BASE_MAINNET_RPC_URL',
  'BASE_MAINNET_CHAIN_ID',
  'BASE_MAINNET_RIGHTS_CONTRACT',
  'BLOCKCHAIN_MAX_RETRIES',
  'BLOCKCHAIN_RETRY_DELAY'
];

/**
 * Check environment variables
 */
async function checkEnvironmentVariables(): Promise<TestResult[]> {
  logSection('Environment Variables Check');
  
  const results: TestResult[] = [];
  let missingRequired = false;
  let missingRecommended = false;
  
  // Check required environment variables
  for (const envVar of requiredEnvVars) {
    if (!process.env[envVar]) {
      logError(`Missing required environment variable: ${envVar}`);
      results.push({
        name: `Required Env Var: ${envVar}`,
        passed: false,
        message: `Missing required environment variable: ${envVar}`
      });
      missingRequired = true;
    } else {
      logSuccess(`Found required environment variable: ${envVar}`);
      results.push({
        name: `Required Env Var: ${envVar}`,
        passed: true,
        message: `Found required environment variable: ${envVar}`
      });
    }
  }
  
  // Check recommended environment variables
  for (const envVar of recommendedEnvVars) {
    if (!process.env[envVar]) {
      logWarning(`Missing recommended environment variable: ${envVar}`);
      results.push({
        name: `Recommended Env Var: ${envVar}`,
        passed: true, // Not critical for passing
        message: `Missing recommended environment variable: ${envVar}`
      });
      missingRecommended = true;
    } else {
      logSuccess(`Found recommended environment variable: ${envVar}`);
      results.push({
        name: `Recommended Env Var: ${envVar}`,
        passed: true,
        message: `Found recommended environment variable: ${envVar}`
      });
    }
  }
  
  if (missingRequired) {
    logError('Missing required environment variables. Please add them to .env.production');
  } else if (missingRecommended) {
    logWarning('Some recommended environment variables are missing. Consider adding them for better functionality.');
  } else {
    logSuccess('All environment variables are properly configured.');
  }
  
  return results;
}

/**
 * Check blockchain connections
 */
async function checkBlockchainConnections(): Promise<TestResult[]> {
  logSection('Blockchain Network Connections');
  
  const results: TestResult[] = [];
  const networks = [
    { name: 'Polygon Mumbai', rpcUrl: process.env.POLYGON_MUMBAI_RPC_URL },
    { name: 'Polygon Mainnet', rpcUrl: process.env.POLYGON_MAINNET_RPC_URL },
    { name: 'Ethereum Mainnet', rpcUrl: process.env.ETH_MAINNET_RPC_URL },
    { name: 'Optimism Mainnet', rpcUrl: process.env.OPTIMISM_MAINNET_RPC_URL },
    { name: 'Base Mainnet', rpcUrl: process.env.BASE_MAINNET_RPC_URL }
  ];
  
  for (const network of networks) {
    if (!network.rpcUrl) {
      logWarning(`Skipping connection test for ${network.name} - no RPC URL configured`);
      continue;
    }
    
    try {
      const provider = new ethers.JsonRpcProvider(network.rpcUrl);
      const blockNumber = await provider.getBlockNumber();
      
      logSuccess(`Successfully connected to ${network.name} - current block: ${blockNumber}`);
      results.push({
        name: `${network.name} Connection`,
        passed: true,
        message: `Successfully connected to ${network.name} - current block: ${blockNumber}`
      });
    } catch (error) {
      logError(`Failed to connect to ${network.name}: ${(error as Error).message}`);
      results.push({
        name: `${network.name} Connection`,
        passed: false,
        message: `Failed to connect to ${network.name}: ${(error as Error).message}`
      });
    }
  }
  
  return results;
}

/**
 * Check smart contract addresses
 */
async function checkSmartContractAddresses(): Promise<TestResult[]> {
  logSection('Smart Contract Addresses Check');
  
  const results: TestResult[] = [];
  const contractConfigs = [
    { network: 'Polygon Mumbai', 
      rights: process.env.POLYGON_MUMBAI_RIGHTS_CONTRACT, 
      nft: process.env.POLYGON_MUMBAI_NFT_CONTRACT,
      rpcUrl: process.env.POLYGON_MUMBAI_RPC_URL },
    { network: 'Polygon Mainnet', 
      rights: process.env.POLYGON_MAINNET_RIGHTS_CONTRACT, 
      nft: process.env.POLYGON_MAINNET_NFT_CONTRACT,
      rpcUrl: process.env.POLYGON_MAINNET_RPC_URL },
    { network: 'Ethereum Mainnet', 
      rights: process.env.ETH_MAINNET_RIGHTS_CONTRACT, 
      nft: process.env.ETH_MAINNET_NFT_CONTRACT,
      rpcUrl: process.env.ETH_MAINNET_RPC_URL }
  ];
  
  for (const config of contractConfigs) {
    if (!config.rpcUrl) {
      logWarning(`Skipping contract check for ${config.network} - no RPC URL configured`);
      continue;
    }
    
    // Check rights contract
    if (!config.rights) {
      logError(`Missing rights contract address for ${config.network}`);
      results.push({
        name: `${config.network} Rights Contract`,
        passed: false,
        message: `Missing rights contract address for ${config.network}`
      });
    } else if (!ethers.isAddress(config.rights)) {
      logError(`Invalid rights contract address for ${config.network}: ${config.rights}`);
      results.push({
        name: `${config.network} Rights Contract Format`,
        passed: false,
        message: `Invalid rights contract address format for ${config.network}: ${config.rights}`
      });
    } else {
      logSuccess(`Valid rights contract address for ${config.network}: ${config.rights}`);
      results.push({
        name: `${config.network} Rights Contract Format`,
        passed: true,
        message: `Valid rights contract address for ${config.network}: ${config.rights}`
      });
      
      // Try to connect to the contract
      try {
        const provider = new ethers.JsonRpcProvider(config.rpcUrl);
        const code = await provider.getCode(config.rights);
        
        if (code === '0x') {
          logError(`No contract code found at rights contract address for ${config.network}`);
          results.push({
            name: `${config.network} Rights Contract Existence`,
            passed: false,
            message: `No contract code found at rights contract address for ${config.network}`
          });
        } else {
          logSuccess(`Verified rights contract exists on ${config.network}`);
          results.push({
            name: `${config.network} Rights Contract Existence`,
            passed: true,
            message: `Verified rights contract exists on ${config.network}`
          });
        }
      } catch (error) {
        logError(`Failed to verify rights contract on ${config.network}: ${(error as Error).message}`);
        results.push({
          name: `${config.network} Rights Contract Verification`,
          passed: false,
          message: `Failed to verify rights contract on ${config.network}: ${(error as Error).message}`
        });
      }
    }
    
    // Check NFT contract
    if (!config.nft) {
      logError(`Missing NFT contract address for ${config.network}`);
      results.push({
        name: `${config.network} NFT Contract`,
        passed: false,
        message: `Missing NFT contract address for ${config.network}`
      });
    } else if (!ethers.isAddress(config.nft)) {
      logError(`Invalid NFT contract address for ${config.network}: ${config.nft}`);
      results.push({
        name: `${config.network} NFT Contract Format`,
        passed: false,
        message: `Invalid NFT contract address format for ${config.network}: ${config.nft}`
      });
    } else {
      logSuccess(`Valid NFT contract address for ${config.network}: ${config.nft}`);
      results.push({
        name: `${config.network} NFT Contract Format`,
        passed: true,
        message: `Valid NFT contract address for ${config.network}: ${config.nft}`
      });
      
      // Try to connect to the contract
      try {
        const provider = new ethers.JsonRpcProvider(config.rpcUrl);
        const code = await provider.getCode(config.nft);
        
        if (code === '0x') {
          logError(`No contract code found at NFT contract address for ${config.network}`);
          results.push({
            name: `${config.network} NFT Contract Existence`,
            passed: false,
            message: `No contract code found at NFT contract address for ${config.network}`
          });
        } else {
          logSuccess(`Verified NFT contract exists on ${config.network}`);
          results.push({
            name: `${config.network} NFT Contract Existence`,
            passed: true,
            message: `Verified NFT contract exists on ${config.network}`
          });
        }
      } catch (error) {
        logError(`Failed to verify NFT contract on ${config.network}: ${(error as Error).message}`);
        results.push({
          name: `${config.network} NFT Contract Verification`,
          passed: false,
          message: `Failed to verify NFT contract on ${config.network}: ${(error as Error).message}`
        });
      }
    }
  }
  
  return results;
}

/**
 * Check wallet configuration
 */
async function checkWalletConfiguration(): Promise<TestResult[]> {
  logSection('Wallet Configuration Check');
  
  const results: TestResult[] = [];
  const privateKey = process.env.ETH_ACCOUNT_PRIVATE_KEY;
  const address = process.env.ETH_ACCOUNT_ADDRESS;
  
  if (!privateKey) {
    logError('Missing ETH_ACCOUNT_PRIVATE_KEY');
    results.push({
      name: 'Private Key',
      passed: false,
      message: 'Missing ETH_ACCOUNT_PRIVATE_KEY'
    });
    return results;
  }
  
  if (!address) {
    logError('Missing ETH_ACCOUNT_ADDRESS');
    results.push({
      name: 'Account Address',
      passed: false,
      message: 'Missing ETH_ACCOUNT_ADDRESS'
    });
    return results;
  }
  
  // Check if private key is valid format
  let wallet: ethers.Wallet;
  try {
    wallet = new ethers.Wallet(privateKey);
    logSuccess('Private key has valid format');
    results.push({
      name: 'Private Key Format',
      passed: true,
      message: 'Private key has valid format'
    });
  } catch (error) {
    logError(`Invalid private key format: ${(error as Error).message}`);
    results.push({
      name: 'Private Key Format',
      passed: false,
      message: `Invalid private key format: ${(error as Error).message}`
    });
    return results;
  }
  
  // Check if address matches private key
  const derivedAddress = wallet.address;
  if (derivedAddress.toLowerCase() === address.toLowerCase()) {
    logSuccess('Account address matches private key');
    results.push({
      name: 'Address Match',
      passed: true,
      message: 'Account address matches private key'
    });
  } else {
    logError(`Account address (${address}) does not match the address derived from private key (${derivedAddress})`);
    results.push({
      name: 'Address Match',
      passed: false,
      message: `Account address (${address}) does not match the address derived from private key (${derivedAddress})`
    });
  }
  
  // Check wallet balance on primary networks
  const networks = [
    { name: 'Polygon Mumbai', rpcUrl: process.env.POLYGON_MUMBAI_RPC_URL },
    { name: 'Polygon Mainnet', rpcUrl: process.env.POLYGON_MAINNET_RPC_URL },
    { name: 'Ethereum Mainnet', rpcUrl: process.env.ETH_MAINNET_RPC_URL }
  ];
  
  for (const network of networks) {
    if (!network.rpcUrl) {
      logWarning(`Skipping balance check for ${network.name} - no RPC URL configured`);
      continue;
    }
    
    try {
      const provider = new ethers.JsonRpcProvider(network.rpcUrl);
      const balance = await provider.getBalance(address);
      const etherBalance = ethers.formatEther(balance);
      
      logSuccess(`${network.name} balance: ${etherBalance} ETH`);
      
      // Check if balance is zero
      if (balance === 0n) {
        logWarning(`Wallet has zero balance on ${network.name} - transactions will fail`);
        results.push({
          name: `${network.name} Balance`,
          passed: false,
          message: `Wallet has zero balance on ${network.name} - transactions will fail`
        });
      } else {
        results.push({
          name: `${network.name} Balance`,
          passed: true,
          message: `Wallet has ${etherBalance} ETH on ${network.name}`
        });
      }
    } catch (error) {
      logError(`Failed to check balance on ${network.name}: ${(error as Error).message}`);
      results.push({
        name: `${network.name} Balance Check`,
        passed: false,
        message: `Failed to check balance on ${network.name}: ${(error as Error).message}`
      });
    }
  }
  
  return results;
}

/**
 * Check IPFS configuration
 */
async function checkIPFSConfiguration(): Promise<TestResult[]> {
  logSection('IPFS Configuration Check');
  
  const results: TestResult[] = [];
  const ipfsApiKey = process.env.IPFS_API_KEY;
  const ipfsApiSecret = process.env.IPFS_API_SECRET;
  
  if (!ipfsApiKey) {
    logError('Missing IPFS_API_KEY');
    results.push({
      name: 'IPFS API Key',
      passed: false,
      message: 'Missing IPFS_API_KEY'
    });
  } else {
    logSuccess('IPFS_API_KEY is configured');
    results.push({
      name: 'IPFS API Key',
      passed: true,
      message: 'IPFS_API_KEY is configured'
    });
  }
  
  if (!ipfsApiSecret) {
    logError('Missing IPFS_API_SECRET');
    results.push({
      name: 'IPFS API Secret',
      passed: false,
      message: 'Missing IPFS_API_SECRET'
    });
  } else {
    logSuccess('IPFS_API_SECRET is configured');
    results.push({
      name: 'IPFS API Secret',
      passed: true,
      message: 'IPFS_API_SECRET is configured'
    });
  }
  
  // Note: We don't actually test the IPFS credentials since that would
  // require uploading a file, which might not be desirable in a simple check
  
  return results;
}

/**
 * Check database tables related to blockchain
 */
async function checkDatabaseTables(): Promise<TestResult[]> {
  logSection('Database Tables Check');
  
  const results: TestResult[] = [];
  
  // List of required tables for blockchain functionality
  const requiredTables = [
    'blockchain_transactions',
    'nft_tokens',
    'rights_records',
    'rights_verifications',
    'rights_disputes'
  ];
  
  // In a real implementation, this would connect to the database
  // and check if these tables exist, but for now we'll just check
  // if the schema file contains references to these tables
  
  try {
    // Check if schema file exists
    const schemaPath = path.join(process.cwd(), 'shared', 'schema.ts');
    if (!fs.existsSync(schemaPath)) {
      logError('Schema file not found: shared/schema.ts');
      requiredTables.forEach(table => {
        results.push({
          name: `Table: ${table}`,
          passed: false,
          message: 'Schema file not found: shared/schema.ts'
        });
      });
      return results;
    }
    
    // Read schema file content
    const schemaContent = fs.readFileSync(schemaPath, 'utf8');
    
    // Check each required table
    for (const table of requiredTables) {
      if (schemaContent.includes(`export const ${table}`)) {
        logSuccess(`Table '${table}' is defined in schema`);
        results.push({
          name: `Table: ${table}`,
          passed: true,
          message: `Table '${table}' is defined in schema`
        });
      } else {
        logError(`Table '${table}' is not defined in schema`);
        results.push({
          name: `Table: ${table}`,
          passed: false,
          message: `Table '${table}' is not defined in schema`
        });
      }
    }
  } catch (error) {
    logError(`Failed to check database tables: ${(error as Error).message}`);
    requiredTables.forEach(table => {
      results.push({
        name: `Table: ${table}`,
        passed: false,
        message: `Failed to check database tables: ${(error as Error).message}`
      });
    });
  }
  
  return results;
}

/**
 * Main function to run all production readiness checks
 */
async function checkProductionReadiness() {
  console.log(`\n${colors.blue}=============================================${colors.reset}`);
  console.log(`${colors.blue}       Blockchain Production Readiness Check       ${colors.reset}`);
  console.log(`${colors.blue}=============================================${colors.reset}\n`);
  
  console.log(`${colors.yellow}Environment:${colors.reset} ${env}`);
  console.log(`${colors.yellow}Time:${colors.reset} ${new Date().toISOString()}\n`);
  
  // Run all checks and collect results
  const results: TestResult[] = [
    ...(await checkEnvironmentVariables()),
    ...(await checkBlockchainConnections()),
    ...(await checkSmartContractAddresses()),
    ...(await checkWalletConfiguration()),
    ...(await checkIPFSConfiguration()),
    ...(await checkDatabaseTables())
  ];
  
  // Print summary
  logSection('Production Readiness Summary');
  
  const totalTests = results.length;
  const passedTests = results.filter(r => r.passed).length;
  const failedTests = totalTests - passedTests;
  
  console.log(`${colors.yellow}Total tests:${colors.reset} ${totalTests}`);
  console.log(`${colors.green}Passed:${colors.reset} ${passedTests}`);
  console.log(`${colors.red}Failed:${colors.reset} ${failedTests}`);
  
  const passPercentage = (passedTests / totalTests) * 100;
  console.log(`${colors.yellow}Pass rate:${colors.reset} ${passPercentage.toFixed(2)}%`);
  
  if (failedTests === 0) {
    console.log(`\n${colors.green}✓ ALL CHECKS PASSED - BLOCKCHAIN INTEGRATION IS READY FOR PRODUCTION${colors.reset}`);
    return true;
  } else {
    console.log(`\n${colors.red}✗ SOME CHECKS FAILED - BLOCKCHAIN INTEGRATION IS NOT READY FOR PRODUCTION${colors.reset}`);
    
    // Print the failed tests for reference
    console.log(`\n${colors.red}Failed tests:${colors.reset}`);
    const failedResults = results.filter(r => !r.passed);
    failedResults.forEach((result, i) => {
      console.log(`${colors.red}${i + 1}. ${result.name}: ${result.message}${colors.reset}`);
    });
    
    return false;
  }
}

// Run the production readiness check
checkProductionReadiness()
  .then(passed => {
    if (!passed) {
      process.exit(1);
    }
  })
  .catch(error => {
    console.error(`${colors.red}Error running production readiness check:${colors.reset}`, error);
    process.exit(1);
  });