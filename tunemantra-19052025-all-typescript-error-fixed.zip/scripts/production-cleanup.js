/**
 * TuneMantra Production Cleanup Utility
 * 
 * This script removes unnecessary files and directories for production deployment.
 * It helps reduce package size and remove development-only content.
 * 
 * Usage: node scripts/production-cleanup.js
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// Colors for console output
const colors = {
  reset: '\x1b[0m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m'
};

// Directories to remove in production
const DIRECTORIES_TO_REMOVE = [
  '.github',
  '.vscode',
  'docs',
  'tests',
  'test',
  'coverage',
  'mock-data',
  '.old_documentation_backup',
  'attached_assets'
];

// Files to remove in production
const FILES_TO_REMOVE = [
  '.gitignore',
  '.eslintrc.js',
  '.eslintignore',
  '.prettierrc',
  '.prettierignore',
  'CONTRIBUTING.md',
  'CHANGELOG.md',
  'jest.config.js',
  'tsconfig.tsbuildinfo',
  'LICENSE',
  'DOCUMENTATION.md',
  'DOCUMENTATION_REORGANIZATION_SUMMARY.md'
];

// Calculate directory size
function getDirectorySize(dirPath) {
  if (!fs.existsSync(dirPath)) return 0;
  
  let size = 0;
  const files = fs.readdirSync(dirPath);
  
  for (const file of files) {
    const filePath = path.join(dirPath, file);
    const stats = fs.statSync(filePath);
    
    if (stats.isDirectory()) {
      size += getDirectorySize(filePath);
    } else {
      size += stats.size;
    }
  }
  
  return size;
}

// Format size to human-readable format
function formatSize(bytes) {
  if (bytes === 0) return '0 Bytes';
  
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  
  return parseFloat((bytes / Math.pow(1024, i)).toFixed(2)) + ' ' + sizes[i];
}

// Remove a directory recursively
function removeDirectory(dirPath) {
  if (!fs.existsSync(dirPath)) return;
  
  const size = getDirectorySize(dirPath);
  console.log(`${colors.yellow}Removing directory:${colors.reset} ${dirPath} (${formatSize(size)})`);
  
  try {
    fs.rmSync(dirPath, { recursive: true, force: true });
    console.log(`${colors.green}✓ Successfully removed${colors.reset}`);
    return size;
  } catch (err) {
    console.error(`${colors.red}Error removing directory:${colors.reset} ${err.message}`);
    return 0;
  }
}

// Remove a file
function removeFile(filePath) {
  if (!fs.existsSync(filePath)) return 0;
  
  const stats = fs.statSync(filePath);
  const size = stats.size;
  
  console.log(`${colors.yellow}Removing file:${colors.reset} ${filePath} (${formatSize(size)})`);
  
  try {
    fs.unlinkSync(filePath);
    console.log(`${colors.green}✓ Successfully removed${colors.reset}`);
    return size;
  } catch (err) {
    console.error(`${colors.red}Error removing file:${colors.reset} ${err.message}`);
    return 0;
  }
}

// Remove source map files
function removeSourceMaps() {
  console.log(`\n${colors.cyan}Removing source map files...${colors.reset}`);
  
  let totalSize = 0;
  let count = 0;
  
  const findSourceMaps = (dirPath) => {
    if (!fs.existsSync(dirPath)) return;
    
    const files = fs.readdirSync(dirPath);
    
    for (const file of files) {
      const filePath = path.join(dirPath, file);
      const stats = fs.statSync(filePath);
      
      if (stats.isDirectory()) {
        findSourceMaps(filePath);
      } else if (file.endsWith('.map')) {
        const size = removeFile(filePath);
        totalSize += size;
        count++;
      }
    }
  };
  
  findSourceMaps(path.join(process.cwd(), 'dist'));
  
  console.log(`${colors.green}✓ Removed ${count} source map files (${formatSize(totalSize)})${colors.reset}`);
  
  return totalSize;
}

// Install only production dependencies
function installProductionDependencies() {
  console.log(`\n${colors.cyan}Installing production dependencies only...${colors.reset}`);
  
  const nodeModulesSize = getDirectorySize(path.join(process.cwd(), 'node_modules'));
  
  try {
    // Remove node_modules
    fs.rmSync(path.join(process.cwd(), 'node_modules'), { recursive: true, force: true });
    
    // Install production dependencies
    execSync('npm ci --production', { stdio: 'inherit' });
    
    const newNodeModulesSize = getDirectorySize(path.join(process.cwd(), 'node_modules'));
    const savedSize = nodeModulesSize - newNodeModulesSize;
    
    console.log(`${colors.green}✓ Installed production dependencies${colors.reset}`);
    console.log(`${colors.blue}Original node_modules size:${colors.reset} ${formatSize(nodeModulesSize)}`);
    console.log(`${colors.blue}New node_modules size:${colors.reset} ${formatSize(newNodeModulesSize)}`);
    console.log(`${colors.green}Space saved:${colors.reset} ${formatSize(savedSize)}`);
    
    return savedSize;
  } catch (err) {
    console.error(`${colors.red}Error installing production dependencies:${colors.reset} ${err.message}`);
    return 0;
  }
}

// Main cleanup function
function cleanup() {
  console.log(`${colors.cyan}===========================================================${colors.reset}`);
  console.log(`${colors.cyan}    TuneMantra Production Cleanup Utility${colors.reset}`);
  console.log(`${colors.cyan}===========================================================${colors.reset}`);
  console.log('');
  
  // Calculate initial project size
  const initialSize = getDirectorySize(process.cwd());
  console.log(`${colors.blue}Initial project size:${colors.reset} ${formatSize(initialSize)}`);
  console.log('');
  
  // Remove directories
  console.log(`${colors.cyan}Removing development directories...${colors.reset}`);
  let totalSaved = 0;
  
  for (const dir of DIRECTORIES_TO_REMOVE) {
    const dirPath = path.join(process.cwd(), dir);
    const size = removeDirectory(dirPath);
    totalSaved += size;
  }
  
  // Remove files
  console.log(`\n${colors.cyan}Removing development files...${colors.reset}`);
  
  for (const file of FILES_TO_REMOVE) {
    const filePath = path.join(process.cwd(), file);
    const size = removeFile(filePath);
    totalSaved += size;
  }
  
  // Remove source maps
  totalSaved += removeSourceMaps();
  
  // Install production dependencies
  totalSaved += installProductionDependencies();
  
  // Calculate final project size
  const finalSize = getDirectorySize(process.cwd());
  
  // Print summary
  console.log(`\n${colors.cyan}===========================================================${colors.reset}`);
  console.log(`${colors.cyan}    Cleanup Summary${colors.reset}`);
  console.log(`${colors.cyan}===========================================================${colors.reset}`);
  console.log(`${colors.blue}Initial project size:${colors.reset} ${formatSize(initialSize)}`);
  console.log(`${colors.blue}Final project size:${colors.reset} ${formatSize(finalSize)}`);
  console.log(`${colors.green}Total space saved:${colors.reset} ${formatSize(totalSaved)}`);
  console.log(`${colors.green}Size reduction:${colors.reset} ${(totalSaved / initialSize * 100).toFixed(2)}%`);
  console.log(`${colors.cyan}===========================================================${colors.reset}`);
  
  console.log(`\n${colors.green}✓ Production cleanup completed successfully!${colors.reset}`);
  console.log(`\n${colors.yellow}Note: This script has permanently removed files and directories.${colors.reset}`);
  console.log(`${colors.yellow}If you need to restore them, you should retrieve them from version control.${colors.reset}`);
}

// Execute cleanup
cleanup();