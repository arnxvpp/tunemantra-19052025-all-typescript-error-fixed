/**
 * Complete Blockchain Testing Suite
 * 
 * This script provides a comprehensive testing suite for TuneMantra's blockchain functionality.
 * It combines all blockchain testing scenarios in one place and provides a structured
 * approach to testing different aspects of the blockchain integration.
 * 
 * USAGE: npx tsx scripts/complete-blockchain-test-suite.ts
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { ethers } from 'ethers';
import colors from 'colors';

// Configure colors for terminal output
colors.enable();

// Setup environment for testing
process.env.NODE_ENV = 'development';
process.env.BLOCKCHAIN_SIMULATION = 'true';

// Get current file and directory path
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');
const devEnvPath = path.join(rootDir, '.env.development');

// Check and load environment variables
console.log(`\n${'='.repeat(80)}`.cyan);
console.log(`BLOCKCHAIN TESTING SUITE - TuneMantra Platform`.cyan.bold);
console.log(`${'='.repeat(80)}\n`.cyan);

console.log(`🔍 Looking for environment file at: ${devEnvPath}`);
if (fs.existsSync(devEnvPath)) {
  console.log(`✅ Environment file found`.green);
  dotenv.config({ path: devEnvPath });
}

// Always set these testing values to ensure the test works regardless of environment loading
console.log(`🔧 Setting required test environment variables...`);
process.env.BLOCKCHAIN_SIMULATION = 'true';
process.env.MUMBAI_RPC_URL = 'https://polygon-mumbai-bor.publicnode.com';
process.env.MUMBAI_PRIVATE_KEY = '0x1234567890123456789012345678901234567890123456789012345678901234';
process.env.MUMBAI_NFT_CONTRACT_ADDRESS = '0x1234567890123456789012345678901234567890';
process.env.MUMBAI_RIGHTS_CONTRACT_ADDRESS = '0x1234567890123456789012345678901234567890';

// Log configuration
console.log("\n📋 Testing configuration:".cyan);
console.log({
  NODE_ENV: process.env.NODE_ENV,
  BLOCKCHAIN_SIMULATION: process.env.BLOCKCHAIN_SIMULATION,
  MUMBAI_RPC_URL: process.env.MUMBAI_RPC_URL,
  MUMBAI_PRIVATE_KEY: process.env.MUMBAI_PRIVATE_KEY ? "Set (not showing full value)" : "Not set",
  MUMBAI_NFT_CONTRACT_ADDRESS: process.env.MUMBAI_NFT_CONTRACT_ADDRESS,
  MUMBAI_RIGHTS_CONTRACT_ADDRESS: process.env.MUMBAI_RIGHTS_CONTRACT_ADDRESS
});

// Import all required modules
import { blockchainConnector } from '../server/services/blockchain-connector';
import { createRightsRecord, updateRightsVerificationStatus } from '../server/services/db-helpers';
import { assetTypeEnum, rightsTypeEnum, ownerTypeEnum, blockchainNetworkEnum } from '../shared/schema';
import { db } from '../server/db';
import { eq } from 'drizzle-orm';

// Test data
const TEST_DATA = {
  networkId: 'mumbai', // Polygon Mumbai testnet
  assetId: `TRACK_${Date.now()}`,
  assetType: 'track',
  ownerAddress: '0x1234567890123456789012345678901234567890',
  verifierAddress: '0x9876543210987654321098765432109876543210',
  rightsType: 'master',
  ownerType: 'artist',
  percentage: 75,
  startDate: new Date(),
  endDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000), // 1 year from now
  territories: ['global', 'US', 'EU', 'JP']
};

// Re-initialize the connector with our environment variables
console.log("\n🔄 Initializing blockchain connector...".cyan);
(blockchainConnector as any).initializeProviders();

// Helper function to generate test signatures
async function generateTestSignature(message: string): Promise<string> {
  const testPrivateKey = '0x0123456789012345678901234567890123456789012345678901234567890123';
  const wallet = new ethers.Wallet(testPrivateKey);
  return wallet.signMessage(message);
}

// Helper for test output formatting
function logSection(title: string) {
  console.log(`\n${'='.repeat(80)}`.cyan);
  console.log(`${title}`.cyan.bold);
  console.log(`${'-'.repeat(80)}`.cyan);
}

function logSubSection(title: string) {
  console.log(`\n${'-'.repeat(40)}`.yellow);
  console.log(`${title}`.yellow);
  console.log(`${'-'.repeat(40)}`.yellow);
}

// Test functions
async function testNetworkConfiguration() {
  logSection('NETWORK CONFIGURATION TEST');
  
  try {
    // Get configured networks
    const networks = blockchainConnector.getConfiguredNetworks();
    console.log(`Available networks: ${networks.join(', ')}`);
    
    // Check if test network is available
    if (!networks.includes(TEST_DATA.networkId)) {
      console.error(`❌ Test network ${TEST_DATA.networkId} not available`.red);
      throw new Error(`Network ${TEST_DATA.networkId} not available`);
    }
    
    console.log(`✅ Test network ${TEST_DATA.networkId} is available`.green);
    
    // Get network info
    const networkInfo = blockchainConnector.getNetworkInfo(TEST_DATA.networkId);
    console.log(`Network details:`, networkInfo);
    
    return true;
  } catch (error) {
    console.error(`❌ Network configuration test failed:`.red, error);
    return false;
  }
}

async function testDatabaseAccess() {
  logSection('DATABASE ACCESS TEST');
  
  try {
    // Check database connection
    console.log('Testing database connection...');
    const testQuery = await db.execute('SELECT NOW() as time');
    
    if (testQuery.rows && testQuery.rows.length > 0) {
      console.log(`✅ Database connection successful`.green);
      console.log(`Current database time: ${testQuery.rows[0].time}`);
    } else {
      throw new Error('Database query returned no results');
    }
    
    // Check rights_records table structure
    const tableInfo = await db.execute(
      `SELECT column_name, data_type, is_nullable 
       FROM information_schema.columns 
       WHERE table_name = 'rights_records' 
       ORDER BY ordinal_position`
    );
    
    if (tableInfo.rows.length > 0) {
      console.log(`\n✅ rights_records table structure:`.green);
      console.table(tableInfo.rows);
      
      // Check for essential columns
      const columns = tableInfo.rows.map((row: any) => row.column_name);
      const requiredColumns = [
        'id', 'asset_id', 'asset_type', 'rights_type', 'owner_type', 
        'owner_id', 'owner_address', 'percentage', 'start_date', 'end_date',
        'verification_status', 'blockchain_network_id'
      ];
      
      const missingColumns = requiredColumns.filter(col => !columns.includes(col));
      
      if (missingColumns.length > 0) {
        console.error(`❌ Missing required columns in rights_records table:`.red, missingColumns);
        return false;
      }
    } else {
      console.error(`❌ Could not retrieve rights_records table structure`.red);
      return false;
    }
    
    // Check enum values
    logSubSection('Enum Values');
    console.log("- Asset Types:", Object.values(assetTypeEnum.enumValues));
    console.log("- Rights Types:", Object.values(rightsTypeEnum.enumValues));
    console.log("- Owner Types:", Object.values(ownerTypeEnum.enumValues));
    console.log("- Blockchain Networks:", Object.values(blockchainNetworkEnum.enumValues));
    
    // Verify our test data uses valid enum values
    if (!Object.values(assetTypeEnum.enumValues).includes(TEST_DATA.assetType as any)) {
      console.error(`❌ Invalid asset type: ${TEST_DATA.assetType}`.red);
      return false;
    }
    
    if (!Object.values(rightsTypeEnum.enumValues).includes(TEST_DATA.rightsType as any)) {
      console.error(`❌ Invalid rights type: ${TEST_DATA.rightsType}`.red);
      return false;
    }
    
    if (!Object.values(ownerTypeEnum.enumValues).includes(TEST_DATA.ownerType as any)) {
      console.error(`❌ Invalid owner type: ${TEST_DATA.ownerType}`.red);
      return false;
    }
    
    if (!Object.values(blockchainNetworkEnum.enumValues).includes(TEST_DATA.networkId as any)) {
      console.error(`❌ Invalid network ID: ${TEST_DATA.networkId}`.red);
      return false;
    }
    
    console.log(`✅ Test data uses valid enum values`.green);
    return true;
  } catch (error) {
    console.error(`❌ Database access test failed:`.red, error);
    return false;
  }
}

async function testDirectDatabaseInsertion() {
  logSection('DIRECT DATABASE INSERTION TEST');
  
  try {
    console.log('Inserting test rights record directly into database...');
    const result = await createRightsRecord({
      assetId: `DIRECT_DB_${Date.now()}`,
      assetType: TEST_DATA.assetType,
      rightsType: TEST_DATA.rightsType,
      ownerType: TEST_DATA.ownerType,
      ownerId: 1,
      ownerAddress: TEST_DATA.ownerAddress,
      percentage: TEST_DATA.percentage,
      startDate: TEST_DATA.startDate,
      endDate: TEST_DATA.endDate,
      territories: TEST_DATA.territories,
      blockchainNetworkId: TEST_DATA.networkId,
      verificationStatus: 'pending'
    });
    
    console.log(`✅ Record created with ID: ${result.id}`.green);
    console.log('Record details:', result);
    
    // Attempt to update verification status
    console.log('\nUpdating verification status...');
    
    // Ensure result.id is a number before passing to updateRightsVerificationStatus
    if (result && result.id && typeof result.id === 'number') {
      const updateResult = await updateRightsVerificationStatus(
        result.id,
        'verified',
        1,
        new Date(),
        '0x' + '0'.repeat(64)
      );
      
      console.log(`✅ Verification status updated: ${updateResult}`.green);
    } else {
      console.error(`❌ Could not update verification status: result.id is not a valid number`.red);
    }
    
    return result;
  } catch (error) {
    console.error(`❌ Direct database insertion test failed:`.red, error);
    if (error instanceof Error) {
      console.error(`   Message: ${error.message}`);
      console.error(`   Stack: ${error.stack}`);
    } else {
      console.error(error);
    }
    return null;
  }
}

async function testRegisterRights() {
  logSection('RIGHTS REGISTRATION TEST');
  
  try {
    console.log('Registering rights via blockchain connector...');
    console.log('Test data:', {
      networkId: TEST_DATA.networkId,
      assetId: TEST_DATA.assetId,
      assetType: TEST_DATA.assetType,
      rightsType: TEST_DATA.rightsType,
      ownerType: TEST_DATA.ownerType,
      ownerAddress: TEST_DATA.ownerAddress,
      percentage: TEST_DATA.percentage,
      startDate: TEST_DATA.startDate,
      endDate: TEST_DATA.endDate,
      territories: TEST_DATA.territories
    });
    
    const result = await blockchainConnector.registerRights(
      TEST_DATA.networkId,
      TEST_DATA.assetId,
      TEST_DATA.assetType,
      TEST_DATA.rightsType,
      TEST_DATA.ownerType,
      TEST_DATA.ownerAddress,
      TEST_DATA.percentage,
      TEST_DATA.startDate,
      TEST_DATA.endDate,
      TEST_DATA.territories,
      1, // ownerId
      1  // userId
    );
    
    if (!result.success) {
      console.error(`❌ Rights registration failed: ${result.error}`.red);
      return null;
    }
    
    console.log(`✅ Rights registered successfully`.green);
    console.log('Rights ID:', result.rightsId);
    console.log('Transaction Hash:', result.transactionHash);
    
    return result;
  } catch (error) {
    console.error(`❌ Rights registration test failed:`.red, error);
    if (error instanceof Error) {
      console.error(`   Message: ${error.message}`);
      console.error(`   Stack: ${error.stack}`);
    } else {
      console.error(error);
    }
    return null;
  }
}

async function testGetRightsInfo(rightsId: number) {
  logSection('RIGHTS INFO RETRIEVAL TEST');
  
  try {
    console.log(`Getting rights info for ID ${rightsId}...`);
    const result = await blockchainConnector.getRightsInfo(
      TEST_DATA.networkId,
      rightsId
    );
    
    if (!result.success) {
      console.error(`❌ Rights info retrieval failed: ${result.error}`.red);
      return false;
    }
    
    console.log(`✅ Rights info retrieved successfully`.green);
    console.log('Rights info:', result.data);
    
    return true;
  } catch (error) {
    console.error(`❌ Rights info retrieval test failed:`.red, error);
    return false;
  }
}

async function testVerifyRights(rightsId: number) {
  logSection('RIGHTS VERIFICATION TEST');
  
  try {
    console.log(`Verifying rights for ID ${rightsId}...`);
    
    // Generate a test signature
    const message = `Verify rights record ${rightsId} for asset ${TEST_DATA.assetId}`;
    const signature = await generateTestSignature(message);
    
    console.log(`Generated test signature for message "${message}"`);
    
    const result = await blockchainConnector.verifyRights(
      TEST_DATA.networkId,
      rightsId,
      TEST_DATA.verifierAddress,
      signature,
      1 // userId
    );
    
    if (!result.success) {
      console.error(`❌ Rights verification failed: ${result.error}`.red);
      return false;
    }
    
    console.log(`✅ Rights verified successfully`.green);
    console.log('Transaction Hash:', result.transactionHash);
    console.log('Verification Status:', result.verificationStatus);
    
    return true;
  } catch (error) {
    console.error(`❌ Rights verification test failed:`.red, error);
    return false;
  }
}

async function testNFTMinting() {
  logSection('NFT MINTING TEST');
  
  try {
    console.log('Minting NFT for test asset...');
    
    const metadata = {
      name: `Track: ${TEST_DATA.assetId}`,
      description: "Test track NFT for TuneMantra platform",
      image: "https://tunemantra.com/placeholder-nft.jpg",
      attributes: [
        {
          trait_type: "Asset Type",
          value: TEST_DATA.assetType
        },
        {
          trait_type: "Rights Type",
          value: TEST_DATA.rightsType
        },
        {
          trait_type: "Creation Date",
          value: new Date().toISOString().split('T')[0]
        }
      ]
    };
    
    const result = await blockchainConnector.mintNFT(
      TEST_DATA.networkId,
      TEST_DATA.ownerAddress,
      TEST_DATA.assetId,
      metadata,
      1 // userId
    );
    
    if (!result.success) {
      console.error(`❌ NFT minting failed: ${result.error}`.red);
      return null;
    }
    
    console.log(`✅ NFT minted successfully`.green);
    console.log('Token ID:', result.tokenId);
    console.log('Transaction Hash:', result.transactionHash);
    
    return result;
  } catch (error) {
    console.error(`❌ NFT minting test failed:`.red, error);
    return null;
  }
}

async function testTokenDetails(tokenId: string) {
  logSection('TOKEN DETAILS TEST');
  
  try {
    console.log(`Getting token details for ID ${tokenId}...`);
    const result = await blockchainConnector.getTokenDetails(
      TEST_DATA.networkId,
      tokenId
    );
    
    if (!result.success) {
      console.error(`❌ Token details retrieval failed: ${result.error}`.red);
      return false;
    }
    
    console.log(`✅ Token details retrieved successfully`.green);
    console.log('Token details:', {
      metadata: result.metadata,
      owner: result.owner
    });
    
    return true;
  } catch (error) {
    console.error(`❌ Token details test failed:`.red, error);
    return false;
  }
}

// Main test orchestration
async function runAllTests() {
  console.log("\n🚀 Starting complete blockchain test suite...".green.bold);
  
  try {
    // Test 1: Network Configuration
    const networkConfigured = await testNetworkConfiguration();
    if (!networkConfigured) {
      throw new Error('Network configuration test failed');
    }
    
    // Test 2: Database Access
    const databaseAccessible = await testDatabaseAccess();
    if (!databaseAccessible) {
      throw new Error('Database access test failed');
    }
    
    // Test 3: Direct Database Insertion
    const dbInsertResult = await testDirectDatabaseInsertion();
    if (!dbInsertResult) {
      throw new Error('Direct database insertion test failed');
    }
    
    // Test 4: Rights Registration
    const registerResult = await testRegisterRights();
    if (!registerResult || !registerResult.success || !registerResult.rightsId) {
      throw new Error('Rights registration test failed');
    }
    
    const rightsId = registerResult.rightsId;
    
    // Test 5: Rights Info Retrieval
    const rightsInfoSuccess = await testGetRightsInfo(rightsId);
    if (!rightsInfoSuccess) {
      throw new Error('Rights info retrieval test failed');
    }
    
    // Test 6: Rights Verification
    const verifySuccess = await testVerifyRights(rightsId);
    if (!verifySuccess) {
      throw new Error('Rights verification test failed');
    }
    
    // Test 7: NFT Minting
    const nftResult = await testNFTMinting();
    if (!nftResult || !nftResult.success || !nftResult.tokenId) {
      throw new Error('NFT minting test failed');
    }
    
    // Test 8: Token Details
    const tokenDetailsSuccess = await testTokenDetails(nftResult.tokenId);
    if (!tokenDetailsSuccess) {
      throw new Error('Token details test failed');
    }
    
    // All tests passed
    logSection('TEST SUITE RESULTS');
    console.log(`✅ All blockchain tests completed successfully!\n`.green.bold);
    console.log(`Summary:`.cyan);
    console.log(`- Network configuration: ${'SUCCESS'.green}`);
    console.log(`- Database access: ${'SUCCESS'.green}`);
    console.log(`- Direct database insertion: ${'SUCCESS'.green}`);
    console.log(`- Rights registration: ${'SUCCESS'.green} (ID: ${rightsId})`);
    console.log(`- Rights info retrieval: ${'SUCCESS'.green}`);
    console.log(`- Rights verification: ${'SUCCESS'.green}`);
    console.log(`- NFT minting: ${'SUCCESS'.green} (Token: ${nftResult.tokenId})`);
    console.log(`- Token details: ${'SUCCESS'.green}`);
    
    return true;
  } catch (error) {
    logSection('TEST SUITE RESULTS');
    console.error(`❌ Test suite failed:`.red.bold, error);
    return false;
  }
}

// Run the complete test suite
runAllTests()
  .then((success) => {
    if (!success) {
      process.exit(1);
    }
  })
  .catch((error) => {
    console.error(`Unhandled error in test suite:`.red.bold, error);
    process.exit(1);
  });