# TuneMantra: Windows Localhost Deployment Tool (PowerShell version)
# Run this script as administrator for best results

# Check if running as administrator
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

function Write-Header {
    Write-Host "=======================================================" -ForegroundColor Cyan
    Write-Host "TuneMantra: Windows Localhost Deployment Tool" -ForegroundColor Cyan
    Write-Host "=======================================================" -ForegroundColor Cyan
    Write-Host "This script will automate the setup of TuneMantra on Windows."
    Write-Host ""
    Write-Host "Prerequisites:" -ForegroundColor Yellow
    Write-Host " - Node.js v20.0.0 or higher"
    Write-Host " - PostgreSQL v14.0 or higher"
    Write-Host " - Git"
    Write-Host ""
    Write-Host "The script will:" -ForegroundColor Yellow
    Write-Host " 1. Check for required dependencies"
    Write-Host " 2. Set up the environment variables"
    Write-Host " 3. Install project dependencies"
    Write-Host " 4. Create and initialize the database"
    Write-Host " 5. Start the development server"
    Write-Host "=======================================================" -ForegroundColor Cyan
    Write-Host ""
}

function Test-Command {
    param (
        [string]$command
    )
    
    return (Get-Command $command -ErrorAction SilentlyContinue)
}

function Test-NodeVersion {
    $nodeVersion = node -v
    $versionMatch = $nodeVersion -match 'v(\d+)\.(\d+)\.(\d+)'
    
    if ($versionMatch) {
        $major = [int]$matches[1]
        return $major -ge 20
    }
    
    return $false
}

function Test-PostgreSQL {
    try {
        $result = & psql -V 2>&1
        return $true
    } catch {
        return $false
    }
}

function Initialize-Environment {
    # Check if .env exists
    if (-not (Test-Path ".env")) {
        if (Test-Path ".env.example") {
            Copy-Item ".env.example" ".env"
            Write-Host "[OK] Created .env file from template." -ForegroundColor Green
        } else {
            Write-Host "[WARNING] No .env.example found. Creating default .env file." -ForegroundColor Yellow
            @"
NODE_ENV=development
PORT=5000
SESSION_SECRET=tunemantra_dev_secret
ADMIN_REGISTRATION_CODE=tunemantra
DATABASE_URL=postgresql://postgres:postgres@localhost:5432/tunemantra
MAX_UPLOAD_SIZE=100000000
UPLOAD_DIR=./uploads
"@ | Out-File -FilePath ".env" -Encoding utf8
            Write-Host "[OK] Created default .env file." -ForegroundColor Green
        }
    } else {
        Write-Host "[OK] .env file already exists." -ForegroundColor Green
    }

    # Create uploads directory if needed
    if (-not (Test-Path "uploads")) {
        New-Item -Path "uploads" -ItemType Directory | Out-Null
        Write-Host "[OK] Created uploads directory." -ForegroundColor Green
    }

    # Get PostgreSQL information
    Write-Host ""
    $pgUser = Read-Host -Prompt "Enter PostgreSQL username [postgres]" 
    if ([string]::IsNullOrWhiteSpace($pgUser)) { $pgUser = "postgres" }
    
    $pgPassword = Read-Host -Prompt "Enter PostgreSQL password [postgres]" 
    if ([string]::IsNullOrWhiteSpace($pgPassword)) { $pgPassword = "postgres" }
    
    $pgHost = Read-Host -Prompt "Enter PostgreSQL host [localhost]" 
    if ([string]::IsNullOrWhiteSpace($pgHost)) { $pgHost = "localhost" }
    
    $pgPort = Read-Host -Prompt "Enter PostgreSQL port [5432]" 
    if ([string]::IsNullOrWhiteSpace($pgPort)) { $pgPort = "5432" }
    
    $pgDatabase = Read-Host -Prompt "Enter PostgreSQL database name [tunemantra]" 
    if ([string]::IsNullOrWhiteSpace($pgDatabase)) { $pgDatabase = "tunemantra" }

    # Update .env file
    $envContent = Get-Content ".env" -Raw
    $envContent = $envContent -replace 'DATABASE_URL=.*', "DATABASE_URL=postgresql://$pgUser`:$pgPassword@$pgHost`:$pgPort/$pgDatabase"
    $envContent | Set-Content ".env" -NoNewline

    Write-Host "[OK] Updated DATABASE_URL in .env file." -ForegroundColor Green
    
    return @{
        PgUser = $pgUser
        PgPassword = $pgPassword
        PgHost = $pgHost
        PgPort = $pgPort
        PgDatabase = $pgDatabase
    }
}

function Initialize-Database {
    param (
        [hashtable]$dbConfig
    )
    
    Write-Host ""
    Write-Host "[INFO] Creating and initializing database..." -ForegroundColor Cyan
    
    try {
        # Check if database exists
        $query = "SELECT 1 FROM pg_database WHERE datname='$($dbConfig.PgDatabase)';"
        $result = & psql -U $dbConfig.PgUser -h $dbConfig.PgHost -p $dbConfig.PgPort -t -c $query postgres 2>&1
        
        if ($result -match "1 row") {
            Write-Host "[OK] Database already exists." -ForegroundColor Green
        } else {
            Write-Host "[INFO] Creating database $($dbConfig.PgDatabase)..." -ForegroundColor Cyan
            $createResult = & psql -U $dbConfig.PgUser -h $dbConfig.PgHost -p $dbConfig.PgPort -c "CREATE DATABASE $($dbConfig.PgDatabase);" postgres 2>&1
            Write-Host "[OK] Database created." -ForegroundColor Green
        }

        # Run database migrations
        Write-Host "[INFO] Pushing schema to database..." -ForegroundColor Cyan
        npm run db:push
        if ($LASTEXITCODE -ne 0) {
            Write-Host "[ERROR] Failed to push schema to database." -ForegroundColor Red
            return $false
        }
        Write-Host "[OK] Database schema initialized." -ForegroundColor Green
        return $true
    } catch {
        Write-Host "[ERROR] Database initialization failed: $_" -ForegroundColor Red
        return $false
    }
}

# Main script execution
Clear-Host
Write-Header

if (-not $isAdmin) {
    Write-Host "[WARNING] This script is not running with administrator privileges." -ForegroundColor Yellow
    Write-Host "Some operations might fail. Consider running this script as administrator." -ForegroundColor Yellow
    Write-Host ""
    $continue = Read-Host -Prompt "Continue anyway? (y/n)"
    if ($continue -ne "y") {
        exit
    }
}

# Check dependencies
Write-Host "[INFO] Checking for required dependencies..." -ForegroundColor Cyan
Write-Host ""

# Check Node.js
if (-not (Test-Command "node")) {
    Write-Host "[ERROR] Node.js is not installed or not in PATH." -ForegroundColor Red
    Write-Host "Please install Node.js v20.0.0 or higher from https://nodejs.org/"
    pause
    exit
}

if (-not (Test-NodeVersion)) {
    Write-Host "[ERROR] Node.js version is below v20.0.0." -ForegroundColor Red
    Write-Host "Please upgrade Node.js to v20.0.0 or higher from https://nodejs.org/"
    pause
    exit
}
Write-Host "[OK] Node.js is installed and meets version requirements." -ForegroundColor Green

# Check npm
if (-not (Test-Command "npm")) {
    Write-Host "[ERROR] npm is not installed or not in PATH." -ForegroundColor Red
    Write-Host "Please reinstall Node.js from https://nodejs.org/"
    pause
    exit
}
Write-Host "[OK] npm is installed." -ForegroundColor Green

# Check Git
if (-not (Test-Command "git")) {
    Write-Host "[ERROR] Git is not installed or not in PATH." -ForegroundColor Red
    Write-Host "Please install Git from https://git-scm.com/download/win"
    pause
    exit
}
Write-Host "[OK] Git is installed." -ForegroundColor Green

# Check PostgreSQL
$pgInstalled = Test-PostgreSQL
if (-not $pgInstalled) {
    Write-Host "[WARNING] PostgreSQL is not found in PATH." -ForegroundColor Yellow
    Write-Host "If PostgreSQL is installed, make sure it's added to PATH."
    Write-Host "If not installed, please install PostgreSQL v14.0 or higher from https://www.postgresql.org/download/windows/"
    Write-Host ""
    
    $continue = Read-Host -Prompt "Continue anyway? (y/n)"
    if ($continue -ne "y") {
        exit
    }
} else {
    Write-Host "[OK] PostgreSQL is installed." -ForegroundColor Green
}

Write-Host ""
Write-Host "[INFO] All dependency checks completed." -ForegroundColor Cyan
Write-Host ""

# Check package.json exists
if (-not (Test-Path "package.json")) {
    Write-Host "[ERROR] package.json not found." -ForegroundColor Red
    Write-Host "Please run this script from the root directory of the TuneMantra project."
    pause
    exit
}

# Set up environment
$dbConfig = Initialize-Environment

# Install dependencies
Write-Host ""
Write-Host "[INFO] Installing project dependencies..." -ForegroundColor Cyan
npm install

if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] Failed to install project dependencies." -ForegroundColor Red
    pause
    exit
}
Write-Host "[OK] Project dependencies installed." -ForegroundColor Green

# Initialize database
$dbSuccess = Initialize-Database -dbConfig $dbConfig
if (-not $dbSuccess) {
    Write-Host "[ERROR] Database initialization failed." -ForegroundColor Red
    pause
    exit
}

# Success message
Write-Host ""
Write-Host "=======================================================" -ForegroundColor Green
Write-Host "TuneMantra setup completed successfully!" -ForegroundColor Green
Write-Host "=======================================================" -ForegroundColor Green
Write-Host ""
Write-Host "To start the development server, run:" -ForegroundColor Cyan
Write-Host "   npm run dev"
Write-Host ""
Write-Host "The application will be accessible at:" -ForegroundColor Cyan
Write-Host "   http://localhost:5000"
Write-Host ""
$adminCode = (Get-Content ".env" | Select-String "ADMIN_REGISTRATION_CODE").ToString().Split("=")[1]
Write-Host "Admin registration code: $adminCode" -ForegroundColor Yellow
Write-Host "(You can change this in the .env file)"
Write-Host "=======================================================" -ForegroundColor Green
Write-Host ""

$startServer = Read-Host -Prompt "Do you want to start the development server now? (y/n)"
if ($startServer -eq "y") {
    Write-Host "[INFO] Starting development server..." -ForegroundColor Cyan
    Start-Process -FilePath "cmd.exe" -ArgumentList "/k npm run dev"
    Write-Host "[OK] Development server started in a new window." -ForegroundColor Green
    Write-Host "The application will be accessible at http://localhost:5000"
}

Write-Host ""
pause