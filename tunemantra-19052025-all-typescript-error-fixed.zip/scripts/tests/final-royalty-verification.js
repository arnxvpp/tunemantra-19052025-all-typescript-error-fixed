/**
 * Final Royalty Verification Script
 * 
 * This script focuses specifically on verifying royalty calculation functionality
 * by testing different timeframes and platform-specific royalty rates.
 */

// Import required modules
import { db } from './server/db.ts';
import { sql } from 'drizzle-orm';
import { eq, and, desc } from 'drizzle-orm';
import { royaltyCalculations } from './shared/schema.ts';
import { PLATFORM_RATES } from './shared/constants.ts';

/**
 * Test timeframe SQL function directly
 */
async function testTimeframeFunction() {
  try {
    console.log('Testing timeframe SQL function...');
    
    // Test the function with different timeframe types
    const timeframes = ['day', 'week', 'month', 'quarter', 'year'];
    
    for (const timeframe of timeframes) {
      const result = await db.execute(sql`
        SELECT * FROM get_date_range_from_timeframe(${timeframe})
      `);
      
      console.log(`Timeframe "${timeframe}":`);
      console.log(`  Start: ${result.rows[0].start_date}`);
      console.log(`  End: ${result.rows[0].end_date}`);
    }
    
    // Test custom date range
    const customResult = await db.execute(sql`
      SELECT * FROM get_date_range_from_timeframe('custom', '2025-01-01', '2025-03-31')
    `);
    
    console.log(`Custom timeframe:`);
    console.log(`  Start: ${customResult.rows[0].start_date}`);
    console.log(`  End: ${customResult.rows[0].end_date}`);
    
    console.log('Timeframe SQL function test completed');
    return true;
  } catch (error) {
    console.error('Error testing timeframe function:', error);
    return false;
  }
}

/**
 * Test platform-specific royalty calculations
 */
async function testPlatformRoyaltyCalculations() {
  try {
    console.log('Testing platform-specific royalty calculations...');
    
    // Get all the platform rates
    console.log('Platform rates:');
    for (const [platformId, rate] of Object.entries(PLATFORM_RATES)) {
      console.log(`Platform ${platformId}: $${rate} per stream`);
    }
    
    // Get royalty calculations by platform
    const platformQuery = await db.execute(sql`
      SELECT 
        platform_id,
        COUNT(*) as calculation_count,
        SUM(stream_count) as total_streams,
        SUM(amount) as total_amount
      FROM royalty_calculations
      GROUP BY platform_id
      ORDER BY platform_id
    `);
    
    console.log('\nRoyalty calculations by platform:');
    let successCount = 0;
    let totalChecks = 0;
    
    for (const row of platformQuery.rows) {
      const platformId = row.platform_id;
      const totalStreams = parseInt(row.total_streams);
      const totalAmount = parseFloat(row.total_amount);
      
      // Get the platform rate
      const platformRate = PLATFORM_RATES[platformId] || 0.003; // Default rate if not found
      
      // Calculate expected amount
      const expectedAmount = parseFloat((totalStreams * platformRate).toFixed(2));
      const actualAmount = parseFloat(totalAmount.toFixed(2));
      
      // Check if the calculation is reasonably close
      // Allow for aggregation differences due to rounding at individual record level
      const difference = Math.abs(expectedAmount - actualAmount);
      const percentDifference = totalAmount > 0 ? (difference / totalAmount) * 100 : 100;
      const isReasonable = percentDifference < 5; // Allow 5% variance
      
      console.log(`Platform ${platformId}:`);
      console.log(`  Rate: $${platformRate} per stream`);
      console.log(`  Calculation count: ${row.calculation_count}`);
      console.log(`  Total streams: ${totalStreams}`);
      console.log(`  Expected amount: $${expectedAmount.toFixed(2)}`);
      console.log(`  Actual amount: $${actualAmount.toFixed(2)}`);
      console.log(`  Difference: $${difference.toFixed(2)} (${percentDifference.toFixed(2)}%)`);
      console.log(`  Status: ${isReasonable ? 'PASSED' : 'FAILED'}`);
      
      if (isReasonable) {
        successCount++;
      }
      totalChecks++;
    }
    
    // Check specific platform calculations at the record level
    console.log('\nSample record-level verifications:');
    
    const sampleRecords = await db.select()
      .from(royaltyCalculations)
      .limit(5);
    
    for (const record of sampleRecords) {
      const platformId = record.platformId;
      const streamCount = record.streamCount;
      const actualAmount = parseFloat(record.amount);
      
      // Get the platform rate
      const platformRate = PLATFORM_RATES[platformId] || 0.003; // Default rate if not found
      
      // Calculate expected amount
      const expectedAmount = parseFloat((streamCount * platformRate).toFixed(2));
      const difference = Math.abs(expectedAmount - actualAmount);
      const isCorrect = difference < 0.01; // Allow for small rounding differences
      
      console.log(`Record ID ${record.id}:`);
      console.log(`  Platform ID: ${platformId}`);
      console.log(`  Stream count: ${streamCount}`);
      console.log(`  Platform rate: $${platformRate}`);
      console.log(`  Expected amount: $${expectedAmount.toFixed(2)}`);
      console.log(`  Actual amount: $${actualAmount.toFixed(2)}`);
      console.log(`  Status: ${isCorrect ? 'PASSED' : 'FAILED'}`);
      
      if (isCorrect) {
        successCount++;
      }
      totalChecks++;
    }
    
    // Calculate success rate
    const successRate = (successCount / totalChecks) * 100;
    console.log(`\nPlatform royalty tests: ${successCount}/${totalChecks} passed (${successRate.toFixed(2)}%)`);
    
    return successRate >= 90; // 90% success rate is acceptable
  } catch (error) {
    console.error('Error testing platform royalty calculations:', error);
    return false;
  }
}

/**
 * Run all tests
 */
async function runTests() {
  try {
    console.log('Starting royalty verification tests...');
    
    // Track test results
    const results = {
      timeframeFunction: await testTimeframeFunction(),
      platformRoyaltyCalculations: await testPlatformRoyaltyCalculations()
    };
    
    // Calculate overall success rate
    const totalTests = Object.keys(results).length;
    const passedTests = Object.values(results).filter(result => result).length;
    const successRate = (passedTests / totalTests) * 100;
    
    console.log('\n--- Test Summary ---');
    for (const [test, result] of Object.entries(results)) {
      console.log(`${test}: ${result ? 'PASSED' : 'FAILED'}`);
    }
    
    console.log(`\nOverall: ${passedTests}/${totalTests} tests passed (${successRate.toFixed(2)}%)`);
    
    if (successRate === 100) {
      console.log('\nAll royalty verification tests passed successfully!');
      console.log('The royalty calculation system is working correctly.');
    } else {
      console.log('\nSome royalty verification tests failed.');
      console.log('Review the test output above to identify and fix the remaining issues.');
    }
    
    // Close the database connection
    await db.end?.();
  } catch (error) {
    console.error('Error running royalty verification tests:', error);
    // Close the database connection even if there's an error
    await db.end?.();
  }
}

// Run all tests
runTests();