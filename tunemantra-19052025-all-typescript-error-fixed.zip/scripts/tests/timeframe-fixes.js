/**
 * Timeframe Fixes Script
 * 
 * This script tests and applies fixes for timeframe-related issues in the platform.
 * It focuses on ensuring consistent handling of timeframes across the codebase,
 * particularly in royalty calculations and analytics.
 */

// Import required modules
import { db } from './server/db.ts';
import { sql } from 'drizzle-orm';

/**
 * Test PostgreSQL JSON handling with proper syntax
 */
async function testPostgresJsonHandling() {
  try {
    console.log('Testing PostgreSQL JSON handling...');
    
    // Create a test function to safely check JSON syntax
    await db.execute(sql`
      CREATE OR REPLACE FUNCTION test_json_query() 
      RETURNS TABLE(field_exists boolean) AS $$
      BEGIN
        RETURN QUERY 
        SELECT EXISTS (
          SELECT 1 
          FROM information_schema.columns 
          WHERE table_name = 'royalty_calculations' 
            AND column_name = 'timeframe'
        );
      END;
      $$ LANGUAGE plpgsql;
    `);
    
    // Check if timeframe field exists
    const timeframeCheckResult = await db.execute(sql`SELECT test_json_query()`);
    console.log('Timeframe field exists:', timeframeCheckResult.rows[0].test_json_query);
    
    // If field exists, test querying timeframe data with proper PostgreSQL JSON syntax
    if (timeframeCheckResult.rows[0].test_json_query) {
      // Test a query that extracts startDate from timeframe JSON
      const testQuery = await db.execute(sql`
        SELECT 
          id, 
          timeframe->'startDate' as start_date,
          timeframe->'endDate' as end_date
        FROM royalty_calculations
        LIMIT 5
      `);
      
      console.log('JSON extraction test results:');
      console.log(testQuery.rows);
      
      // Count records with NULL timeframe->startDate
      const nullTimeframeTest = await db.execute(sql`
        SELECT COUNT(*) 
        FROM royalty_calculations 
        WHERE timeframe->>'startDate' IS NULL
      `);
      
      console.log('Records with NULL timeframe.startDate:', nullTimeframeTest.rows[0].count);
    }
    
    console.log('PostgreSQL JSON handling test completed successfully');
  } catch (error) {
    console.error('Error testing PostgreSQL JSON handling:', error);
  }
}

/**
 * Create SQL function for timeframe handling
 */
async function createTimeframeFunction() {
  try {
    console.log('Creating timeframe SQL function...');
    
    // Create a SQL function to handle timeframe calculations consistently
    await db.execute(sql`
      CREATE OR REPLACE FUNCTION get_date_range_from_timeframe(timeframe_type text, custom_start_date text DEFAULT NULL, custom_end_date text DEFAULT NULL)
      RETURNS TABLE(start_date timestamp, end_date timestamp) AS $$
      DECLARE
        now_date timestamp := current_date;
      BEGIN
        IF timeframe_type = 'custom' AND custom_start_date IS NOT NULL AND custom_end_date IS NOT NULL THEN
          RETURN QUERY SELECT 
            custom_start_date::timestamp, 
            custom_end_date::timestamp + interval '1 day - 1 second';
        ELSIF timeframe_type = 'day' THEN
          RETURN QUERY SELECT 
            date_trunc('day', now_date)::timestamp, 
            (date_trunc('day', now_date) + interval '1 day - 1 second')::timestamp;
        ELSIF timeframe_type = 'week' THEN
          RETURN QUERY SELECT 
            (date_trunc('day', now_date) - interval '6 days')::timestamp, 
            (date_trunc('day', now_date) + interval '1 day - 1 second')::timestamp;
        ELSIF timeframe_type = 'month' THEN
          RETURN QUERY SELECT 
            date_trunc('month', now_date)::timestamp, 
            (date_trunc('month', now_date) + interval '1 month - 1 second')::timestamp;
        ELSIF timeframe_type = 'quarter' THEN
          RETURN QUERY SELECT 
            date_trunc('quarter', now_date)::timestamp, 
            (date_trunc('quarter', now_date) + interval '3 months - 1 second')::timestamp;
        ELSIF timeframe_type = 'year' THEN
          RETURN QUERY SELECT 
            date_trunc('year', now_date)::timestamp, 
            (date_trunc('year', now_date) + interval '1 year - 1 second')::timestamp;
        ELSE
          -- Default to last 30 days if invalid timeframe
          RETURN QUERY SELECT 
            (now_date - interval '30 days')::timestamp, 
            (now_date + interval '1 day - 1 second')::timestamp;
        END IF;
      END;
      $$ LANGUAGE plpgsql;
    `);
    
    // Test the function
    const testResult = await db.execute(sql`
      SELECT * FROM get_date_range_from_timeframe('month')
    `);
    
    console.log('Timeframe function test result:');
    console.log(testResult.rows);
    
    console.log('Timeframe SQL function created successfully');
  } catch (error) {
    console.error('Error creating timeframe SQL function:', error);
  }
}

/**
 * Apply timeframe fixes to ensure consistent handling
 */
async function applyTimeframeFixes() {
  try {
    console.log('Applying timeframe fixes...');
    
    // First test JSON handling
    await testPostgresJsonHandling();
    
    // Then create the timeframe function
    await createTimeframeFunction();
    
    // Close the database connection when done
    await db.end?.();
    
    console.log('Timeframe fixes applied successfully');
  } catch (error) {
    console.error('Error applying timeframe fixes:', error);
    // Close the database connection even if there's an error
    await db.end?.();
  }
}

// Run the fix script
applyTimeframeFixes();