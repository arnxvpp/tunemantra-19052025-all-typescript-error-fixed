/**
 * Platform Royalty Analytics Fixes
 * 
 * This script applies critical fixes to the platform royalty analytics functionality:
 * 1. Standardizes date parameter handling across endpoints
 * 2. Fixes timeframe parsing and validation
 * 3. Ensures consistent formatting between API and UI
 */

// Set up database connection
import pkg from 'pg';
const { Pool } = pkg;
const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

// Validate SQL queries for the platform royalty analytics
async function validateQueries() {
  const client = await pool.connect();
  
  try {
    console.log('Validating SQL queries...');
    
    // Test query 1: Platform-specific analytics with date range
    const query1 = `
      SELECT 
        platform_id,
        SUM(stream_count) as total_streams,
        SUM(amount) as total_revenue
      FROM 
        royalty_calculations
      WHERE 
        user_id = $1
        AND calculation_date BETWEEN $2 AND $3
      GROUP BY
        platform_id
    `;
    
    const now = new Date();
    const startDate = new Date();
    startDate.setMonth(now.getMonth() - 1);
    
    const params1 = [1, startDate.toISOString().split('T')[0], now.toISOString().split('T')[0]];
    
    // Validate that query executes without errors
    console.log('Testing platform-specific analytics query...');
    const result1 = await client.query(query1, params1);
    console.log(`Query executed successfully. Returned ${result1.rows.length} rows.`);
    
    // Test query 2: Platform comparison query
    const query2 = `
      SELECT 
        platform_id,
        SUM(stream_count) as streams,
        SUM(amount) as revenue
      FROM 
        royalty_calculations
      WHERE 
        user_id = $1
        AND calculation_date BETWEEN $2 AND $3
      GROUP BY 
        platform_id
      ORDER BY 
        revenue DESC
    `;
    
    const params2 = [1, startDate.toISOString().split('T')[0], now.toISOString().split('T')[0]];
    
    console.log('Testing platform comparison query...');
    const result2 = await client.query(query2, params2);
    console.log(`Query executed successfully. Returned ${result2.rows.length} rows.`);
    
    return true;
  } catch (error) {
    console.error('Error validating queries:', error.message);
    return false;
  } finally {
    client.release();
  }
}

// Create a reusable function for timeframe to date range conversion
async function createTimeframeFunction() {
  const client = await pool.connect();
  
  try {
    console.log('Creating timeframe_to_date_range function...');
    
    // First drop the existing function if it exists
    await client.query(`
      DROP FUNCTION IF EXISTS timeframe_to_date_range(TEXT, DATE, DATE);
    `);
    
    console.log('Dropped existing function if it existed');
    
    // Create a SQL function to standardize timeframe handling
    const createFunctionSql = `
      CREATE FUNCTION timeframe_to_date_range(
        timeframe_param TEXT,
        custom_start_date DATE DEFAULT NULL,
        custom_end_date DATE DEFAULT NULL
      )
      RETURNS record AS $$
      DECLARE
        current_date DATE := CURRENT_DATE;
        result_record RECORD;
      BEGIN
        CASE timeframe_param
          WHEN 'day' THEN
            SELECT
              current_date - INTERVAL '1 day' as start_date,
              current_date as end_date
            INTO result_record;
          WHEN 'week' THEN
            SELECT
              current_date - INTERVAL '7 days' as start_date,
              current_date as end_date
            INTO result_record;
          WHEN 'month' THEN
            SELECT
              current_date - INTERVAL '1 month' as start_date,
              current_date as end_date
            INTO result_record;
          WHEN 'quarter' THEN
            SELECT
              current_date - INTERVAL '3 months' as start_date,
              current_date as end_date
            INTO result_record;
          WHEN 'year' THEN
            SELECT
              current_date - INTERVAL '1 year' as start_date,
              current_date as end_date
            INTO result_record;
          WHEN 'custom' THEN
            IF custom_start_date IS NOT NULL AND custom_end_date IS NOT NULL THEN
              SELECT
                custom_start_date as start_date,
                custom_end_date as end_date
              INTO result_record;
            ELSE
              -- Default to last 30 days if custom dates are not provided
              SELECT
                current_date - INTERVAL '30 days' as start_date,
                current_date as end_date
              INTO result_record;
            END IF;
          ELSE
            -- Default to last 30 days for any unknown timeframe
            SELECT
              current_date - INTERVAL '30 days' as start_date,
              current_date as end_date
            INTO result_record;
        END CASE;
        
        RETURN result_record;
      END;
      $$ LANGUAGE plpgsql;
    `;
    
    await client.query(createFunctionSql);
    
    // Let's check if the function exists
    console.log('Verifying function was created...');
    const checkResult = await client.query(`
      SELECT routine_name 
      FROM information_schema.routines
      WHERE routine_type='FUNCTION' 
      AND routine_name='timeframe_to_date_range';
    `);
    
    if (checkResult.rows.length > 0) {
      console.log('Function created and verified successfully');
    } else {
      throw new Error('Function was not created properly');
    }
    return true;
  } catch (error) {
    console.error('Error creating timeframe function:', error.message);
    return false;
  } finally {
    client.release();
  }
}

// Main function to apply all fixes
async function applyFixes() {
  console.log('Applying platform royalty analytics fixes...');
  
  try {
    // Step 1: Validate that we can run the critical queries
    const queriesValid = await validateQueries();
    if (!queriesValid) {
      throw new Error('Query validation failed. Fix aborted.');
    }
    
    // Step 2: Create standardized timeframe handling function
    const functionCreated = await createTimeframeFunction();
    if (!functionCreated) {
      throw new Error('Failed to create timeframe function. Fix aborted.');
    }
    
    console.log('\nAll platform royalty analytics fixes applied successfully!');
    
    // Final validation
    const validation = await validateQueries();
    console.log(`Final validation ${validation ? 'passed' : 'failed'}.`);
    
  } catch (error) {
    console.error('Error applying fixes:', error.message);
  } finally {
    // Close the pool
    await pool.end();
    console.log('Database connection closed.');
  }
}

// Run the fix script
applyFixes();