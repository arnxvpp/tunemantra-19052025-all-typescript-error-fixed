/**
 * Test Timeframe Fixes
 * 
 * This script tests timeframe parsing and date range calculations
 * to ensure consistent behavior across the platform.
 */

/**
 * Parse a timeframe string into a standardized format
 * 
 * @param {string} timeframe - Timeframe identifier (day, week, month, quarter, year) or ISO date range (start~end)
 * @returns {string} Standardized timeframe value
 */
function parseTimeframe(timeframe) {
  // Validate input
  if (!timeframe) {
    return 'month'; // Default to month if not specified
  }
  
  // Check if it's a standard timeframe
  const validTimeframes = ['day', 'week', 'month', 'quarter', 'year'];
  if (validTimeframes.includes(timeframe.toLowerCase())) {
    return timeframe.toLowerCase();
  }
  
  // Check if it's a date range in format "YYYY-MM-DD~YYYY-MM-DD"
  if (timeframe.includes('~')) {
    const [startDate, endDate] = timeframe.split('~');
    
    // Validate dates
    if (validateDate(startDate) && validateDate(endDate)) {
      return `custom:${startDate}~${endDate}`;
    }
  }
  
  // Return default if invalid
  console.warn(`Invalid timeframe: "${timeframe}", using default: "month"`);
  return 'month';
}

/**
 * Get date range from timeframe
 * 
 * @param {string} timeframe - Timeframe identifier or custom date range
 * @returns {Object} Object with startDate and endDate properties
 */
function getDateRangeFromTimeframe(timeframe) {
  const parsedTimeframe = parseTimeframe(timeframe);
  const now = new Date();
  const result = {
    startDate: new Date(now),
    endDate: new Date(now)
  };
  
  // Reset time to start of day for start date and end of day for end date
  result.startDate.setHours(0, 0, 0, 0);
  result.endDate.setHours(23, 59, 59, 999);
  
  // Handle custom date range
  if (parsedTimeframe.startsWith('custom:')) {
    const [startDate, endDate] = parsedTimeframe.substring(7).split('~');
    result.startDate = new Date(startDate);
    result.startDate.setHours(0, 0, 0, 0);
    
    result.endDate = new Date(endDate);
    result.endDate.setHours(23, 59, 59, 999);
    
    return result;
  }
  
  // Handle standard timeframes
  switch (parsedTimeframe) {
    case 'day':
      // Start and end are the same day, already set
      break;
      
    case 'week':
      // Last 7 days
      result.startDate.setDate(result.startDate.getDate() - 6);
      break;
      
    case 'month':
      // Start of current month
      result.startDate.setDate(1);
      // End of current month
      result.endDate = new Date(result.startDate.getFullYear(), result.startDate.getMonth() + 1, 0, 23, 59, 59, 999);
      break;
      
    case 'quarter':
      // Start of current quarter
      const quarter = Math.floor(now.getMonth() / 3);
      result.startDate = new Date(now.getFullYear(), quarter * 3, 1);
      result.startDate.setHours(0, 0, 0, 0);
      
      // End of current quarter
      result.endDate = new Date(now.getFullYear(), (quarter + 1) * 3, 0, 23, 59, 59, 999);
      break;
      
    case 'year':
      // Start of current year
      result.startDate = new Date(now.getFullYear(), 0, 1);
      result.startDate.setHours(0, 0, 0, 0);
      
      // End of current year
      result.endDate = new Date(now.getFullYear(), 11, 31, 23, 59, 59, 999);
      break;
      
    default:
      // Default to month (should not happen due to parseTimeframe validation)
      result.startDate.setDate(1);
      result.endDate = new Date(result.startDate.getFullYear(), result.startDate.getMonth() + 1, 0, 23, 59, 59, 999);
  }
  
  return result;
}

/**
 * Format a date to ISO string with timezone handling
 * This ensures consistent date formatting across the platform
 * 
 * @param {Date} date - Date to format
 * @returns {string} ISO formatted date string
 */
function formatDateToISOString(date) {
  if (!(date instanceof Date)) {
    throw new Error('Invalid date object');
  }
  
  // Format as YYYY-MM-DD
  return date.toISOString().split('T')[0];
}

/**
 * Validate a date string in YYYY-MM-DD format
 * 
 * @param {string} date - Date string to validate
 * @returns {boolean} True if valid, false otherwise
 */
function validateDate(date) {
  // Basic format validation
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    return false;
  }
  
  // Create a date object to validate the date
  const parts = date.split('-');
  const year = parseInt(parts[0], 10);
  const month = parseInt(parts[1], 10) - 1; // Months are 0-based
  const day = parseInt(parts[2], 10);
  
  const dateObj = new Date(year, month, day);
  
  // Check if the date is valid
  return dateObj.getFullYear() === year &&
         dateObj.getMonth() === month &&
         dateObj.getDate() === day;
}

/**
 * Test timeframe parsing
 */
function testTimeframeParsing() {
  console.log('\n--- Testing Timeframe Parsing ---');
  const testCases = [
    'day',
    'week',
    'MONTH', // Test case-insensitivity
    'quarter',
    'year',
    '2025-01-01~2025-02-01', // Custom date range
    'invalid', // Invalid timeframe
    '' // Empty timeframe
  ];
  
  testCases.forEach(testCase => {
    console.log(`Input: "${testCase}" => Result: "${parseTimeframe(testCase)}"`);
  });
}

/**
 * Test date range calculation
 */
function testDateRangeCalculation() {
  console.log('\n--- Testing Date Range Calculation ---');
  const testCases = [
    'day',
    'week',
    'month',
    'quarter',
    'year',
    '2025-01-01~2025-02-01' // Custom date range
  ];
  
  testCases.forEach(testCase => {
    const dateRange = getDateRangeFromTimeframe(testCase);
    console.log(`Timeframe: "${testCase}"`);
    console.log(`  Start: ${formatDateToISOString(dateRange.startDate)}`);
    console.log(`  End: ${formatDateToISOString(dateRange.endDate)}`);
  });
}

/**
 * Test date formatting
 */
function testDateFormatting() {
  console.log('\n--- Testing Date Formatting ---');
  const testDates = [
    new Date(2025, 0, 1), // January 1, 2025
    new Date(2025, 11, 31), // December 31, 2025
    new Date() // Today
  ];
  
  testDates.forEach(date => {
    console.log(`Date: ${date.toDateString()} => ISO: ${formatDateToISOString(date)}`);
  });
}

/**
 * Run all tests
 */
function runTests() {
  console.log('Starting timeframe tests...');
  
  testTimeframeParsing();
  testDateRangeCalculation();
  testDateFormatting();
  
  console.log('\nAll timeframe tests completed successfully!');
}

// Run the tests
runTests();