// Test script for testing the integration service

import { IntegrationService } from './server/services/integration-service.ts';
import { db } from './server/db.ts';

// Function to test the integration service
async function testIntegrationService() {
  try {
    console.log('Testing integration service...');
    
    // Get integration status
    const status = await IntegrationService.getIntegrationStatus();
    console.log('Integration status:', JSON.stringify(status, null, 2));
    
    // Print success message
    console.log('Integration service test completed successfully!');
  } catch (error) {
    console.error('Error testing integration service:', error);
  } finally {
    // Close the database connection
    await db.end?.();
    process.exit(0);
  }
}

testIntegrationService();