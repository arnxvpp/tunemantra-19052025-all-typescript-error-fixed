/**
 * TuneMantra Platform Verification Script
 * 
 * This script performs a comprehensive verification of all key platform components:
 * 1. Timeframe handling
 * 2. Platform royalty calculation
 * 3. Distribution status tracking
 * 4. Analytics integration
 * 
 * The goal is to confirm that all components are working correctly together
 * after applying the platform-wide fixes.
 */

// Import required modules
import { db } from './server/db.ts';
import { sql } from 'drizzle-orm';
import { eq, and, not, desc, isNull } from 'drizzle-orm';
import { distributionRecords, royaltyCalculations } from './shared/schema.ts';
import { PLATFORM_RATES } from './shared/constants.ts';
import fetch from 'node-fetch';

// Base API URL for local testing
const API_BASE_URL = 'http://localhost:5000/api';

/**
 * Login to get session cookie
 */
async function login() {
  try {
    const response = await fetch(`${API_BASE_URL}/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        username: 'skyline',
        password: 'Skyline2024!'
      })
    });
    
    if (!response.ok) {
      throw new Error(`Login failed: ${response.statusText}`);
    }
    
    const cookieHeader = response.headers.get('set-cookie');
    return cookieHeader;
  } catch (error) {
    console.error('Error logging in:', error);
    return null;
  }
}

/**
 * Test timeframe functionality via direct database query
 */
async function testTimeframeDatabase() {
  try {
    console.log('Testing timeframe functionality in database...');
    
    // Test the timeframe SQL function
    const today = new Date();
    const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    const lastDayOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0);
    
    // Format dates to match SQL output
    const expectedStartDate = firstDayOfMonth.toISOString().split('T')[0] + ' 00:00:00';
    const expectedEndDate = lastDayOfMonth.toISOString().split('T')[0] + ' 23:59:59';
    
    const result = await db.execute(sql`
      SELECT * FROM get_date_range_from_timeframe('month')
    `);
    
    const actualStartDate = result.rows[0].start_date.toISOString().replace('T', ' ').substr(0, 19);
    const actualEndDate = result.rows[0].end_date.toISOString().replace('T', ' ').substr(0, 19);
    
    console.log('Monthly timeframe test:');
    console.log(`Expected start: ${expectedStartDate}`);
    console.log(`Actual start: ${actualStartDate}`);
    console.log(`Expected end: ${expectedEndDate}`);
    console.log(`Actual end: ${actualEndDate}`);
    
    const success = 
      expectedStartDate === actualStartDate.substr(0, expectedStartDate.length) &&
      expectedEndDate === actualEndDate.substr(0, expectedEndDate.length);
    
    console.log(`Timeframe database test ${success ? 'PASSED' : 'FAILED'}`);
    
    return success;
  } catch (error) {
    console.error('Error testing timeframe database:', error);
    return false;
  }
}

/**
 * Test platform royalty queries via direct database query
 */
async function testPlatformRoyalty() {
  try {
    console.log('Testing platform royalty calculation...');
    
    // Get a sample royalty calculation
    const royaltyResult = await db.select()
      .from(royaltyCalculations)
      .limit(1);
    
    if (royaltyResult.length === 0) {
      console.log('No royalty calculations found to test');
      return false;
    }
    
    const sampleCalculation = royaltyResult[0];
    
    // Verify that the amount is calculated correctly based on platform rate
    const platformId = sampleCalculation.platformId;
    const streamCount = sampleCalculation.streamCount;
    
    // Get the platform rate
    const platformRate = PLATFORM_RATES[platformId] || 0.003; // Default rate if not found
    
    // Calculate expected amount
    const expectedAmount = parseFloat((streamCount * platformRate).toFixed(2));
    const actualAmount = parseFloat(parseFloat(sampleCalculation.amount).toFixed(2));
    
    console.log(`Platform ID: ${platformId}`);
    console.log(`Stream count: ${streamCount}`);
    console.log(`Platform rate: ${platformRate}`);
    console.log(`Expected amount: ${expectedAmount}`);
    console.log(`Actual amount: ${actualAmount}`);
    
    // Check if the calculation appears correct
    // Allow for small rounding differences (within 0.01)
    const success = Math.abs(expectedAmount - actualAmount) < 0.01;
    
    console.log(`Platform royalty calculation test ${success ? 'PASSED' : 'FAILED'}`);
    
    return success;
  } catch (error) {
    console.error('Error testing platform royalty:', error);
    return false;
  }
}

/**
 * Test distribution status functionality
 */
async function testDistributionStatus(cookies) {
  try {
    console.log('Testing distribution status functionality via API...');
    
    if (!cookies) {
      console.log('No session cookies available, skipping API tests');
      return false;
    }
    
    // Get distribution statistics
    const statsResponse = await fetch(`${API_BASE_URL}/distribution/statistics`, {
      headers: {
        'Cookie': cookies
      }
    });
    
    if (!statsResponse.ok) {
      throw new Error(`Failed to get distribution statistics: ${statsResponse.statusText}`);
    }
    
    const statsData = await statsResponse.json();
    
    console.log('Distribution statistics:');
    console.log(JSON.stringify(statsData, null, 2));
    
    // Check if the response has the expected structure
    const success = statsData && 
                   statsData.success === true && 
                   statsData.data && 
                   typeof statsData.data.totalDistributions === 'number';
    
    console.log(`Distribution status API test ${success ? 'PASSED' : 'FAILED'}`);
    
    return success;
  } catch (error) {
    console.error('Error testing distribution status via API:', error);
    return false;
  }
}

/**
 * Test distribution status via direct database query
 */
async function testDistributionStatusDatabase() {
  try {
    console.log('Testing distribution status via database...');
    
    // Count distribution records by status
    const pendingCount = await db.select({ count: sql`count(*)` })
      .from(distributionRecords)
      .where(eq(distributionRecords.status, 'pending'));
    
    const processingCount = await db.select({ count: sql`count(*)` })
      .from(distributionRecords)
      .where(eq(distributionRecords.status, 'processing'));
    
    const distributedCount = await db.select({ count: sql`count(*)` })
      .from(distributionRecords)
      .where(eq(distributionRecords.status, 'distributed'));
    
    const failedCount = await db.select({ count: sql`count(*)` })
      .from(distributionRecords)
      .where(eq(distributionRecords.status, 'failed'));
    
    console.log('Distribution record counts:');
    console.log(`Pending: ${pendingCount[0].count}`);
    console.log(`Processing: ${processingCount[0].count}`);
    console.log(`Distributed: ${distributedCount[0].count}`);
    console.log(`Failed: ${failedCount[0].count}`);
    
    const totalCount = parseInt(pendingCount[0].count) + 
                      parseInt(processingCount[0].count) + 
                      parseInt(distributedCount[0].count) + 
                      parseInt(failedCount[0].count);
    
    console.log(`Total: ${totalCount}`);
    
    // Check for JSON access in status fields
    const jsonQuery = await db.execute(sql`
      SELECT 
        id, 
        status, 
        status_details->>'royaltyProcessed' as royalty_processed
      FROM distribution_records
      LIMIT 5
    `);
    
    console.log('JSON extraction test:');
    console.log(jsonQuery.rows);
    
    // Test is successful if we can get the counts and extract JSON fields
    const success = totalCount > 0 && jsonQuery.rows.length > 0;
    
    console.log(`Distribution status database test ${success ? 'PASSED' : 'FAILED'}`);
    
    return success;
  } catch (error) {
    console.error('Error testing distribution status via database:', error);
    return false;
  }
}

/**
 * Test analytics integration
 */
async function testAnalyticsIntegration(cookies) {
  try {
    console.log('Testing analytics integration via API...');
    
    if (!cookies) {
      console.log('No session cookies available, skipping API tests');
      return false;
    }
    
    // Get analytics data for a timeframe
    const analyticsResponse = await fetch(`${API_BASE_URL}/analytics/revenue?timeframe=month`, {
      headers: {
        'Cookie': cookies
      }
    });
    
    if (!analyticsResponse.ok) {
      throw new Error(`Failed to get analytics: ${analyticsResponse.statusText}`);
    }
    
    const analyticsData = await analyticsResponse.json();
    
    console.log('Analytics data:');
    console.log(JSON.stringify(analyticsData, null, 2));
    
    // Check if the response has the expected structure
    const success = analyticsData && 
                   analyticsData.success === true && 
                   analyticsData.data;
    
    console.log(`Analytics integration API test ${success ? 'PASSED' : 'FAILED'}`);
    
    return success;
  } catch (error) {
    console.error('Error testing analytics integration via API:', error);
    return false;
  }
}

/**
 * Test analytics via direct database query
 */
async function testAnalyticsDatabase() {
  try {
    console.log('Testing analytics via database...');
    
    // Test a complex analytics query using timeframes
    const analyticsQuery = await db.execute(sql`
      WITH date_range AS (
        SELECT * FROM get_date_range_from_timeframe('month')
      )
      SELECT 
        platform_id,
        SUM(amount) as total_amount,
        SUM(stream_count) as total_streams
      FROM royalty_calculations
      JOIN date_range d ON calculation_date BETWEEN d.start_date AND d.end_date
      GROUP BY platform_id
      ORDER BY total_amount DESC
      LIMIT 5
    `);
    
    console.log('Monthly platform analytics:');
    console.log(analyticsQuery.rows);
    
    // Test is successful if we can run the query
    const success = analyticsQuery.rows.length > 0;
    
    console.log(`Analytics database test ${success ? 'PASSED' : 'FAILED'}`);
    
    return success;
  } catch (error) {
    console.error('Error testing analytics via database:', error);
    return false;
  }
}

/**
 * Run all verification tests
 */
async function runTests() {
  try {
    console.log('Starting platform verification tests...');
    
    // Login to get cookies for API tests
    const cookies = await login();
    
    // Track test results
    const results = {
      timeframeDatabase: await testTimeframeDatabase(),
      platformRoyalty: await testPlatformRoyalty(),
      distributionStatus: await testDistributionStatus(cookies),
      distributionStatusDatabase: await testDistributionStatusDatabase(),
      analyticsIntegration: await testAnalyticsIntegration(cookies),
      analyticsDatabase: await testAnalyticsDatabase()
    };
    
    // Calculate overall success rate
    const totalTests = Object.keys(results).length;
    const passedTests = Object.values(results).filter(result => result).length;
    const successRate = (passedTests / totalTests) * 100;
    
    console.log('\n--- Test Summary ---');
    for (const [test, result] of Object.entries(results)) {
      console.log(`${test}: ${result ? 'PASSED' : 'FAILED'}`);
    }
    
    console.log(`\nOverall: ${passedTests}/${totalTests} tests passed (${successRate.toFixed(2)}%)`);
    
    if (successRate === 100) {
      console.log('\nAll verification tests passed successfully!');
      console.log('The platform fixes have been properly implemented and all components are working together correctly.');
    } else {
      console.log('\nSome verification tests failed.');
      console.log('Review the test output above to identify and fix the remaining issues.');
    }
    
    // Close the database connection
    await db.end?.();
  } catch (error) {
    console.error('Error running verification tests:', error);
    // Close the database connection even if there's an error
    await db.end?.();
  }
}

// Run all tests
runTests();