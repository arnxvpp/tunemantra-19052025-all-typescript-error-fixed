/**
 * Standalone Blockchain Test Script
 * 
 * This script tests the blockchain functionality with hardcoded values and no dependencies
 * on environment variables. It's designed to be self-contained and testable in any environment.
 * 
 * Usage: npx tsx scripts/standalone-blockchain-test.ts
 */

import { ethers } from 'ethers';
import colors from 'colors';

// Configure colors for terminal output
colors.enable();

// Hard-coded configuration for testing (simulated)
const TEST_CONFIG = {
  networkId: 'mumbai',
  chainId: 80001,
  networkName: 'Polygon Mumbai Testnet',
  rpcUrl: 'https://polygon-mumbai-bor.publicnode.com',
  contractAddress: '0x1234567890123456789012345678901234567890',
  privateKey: '0x1234567890123456789012345678901234567890123456789012345678901234',
  userAddress: '0x2345678901234567890123456789012345678901'
};

// Test data
const TEST_DATA = {
  assetId: `TRACK_${Date.now()}`,
  assetType: 'track',
  rightsType: 'master',
  ownerType: 'artist',
  percentOwnership: 100,
  startDate: new Date(),
  endDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000), // 1 year from now
  territories: ['global', 'US', 'IN']
};

// Simulated blockchain functionality
class BlockchainSimulator {
  private provider: ethers.JsonRpcProvider;
  private wallet: ethers.Wallet;
  private rightsRecords: Map<string, any> = new Map();
  private tokens: Map<string, any> = new Map();
  private transactionCount: number = 0;
  
  constructor(config: typeof TEST_CONFIG) {
    // Initialize provider
    console.log(`Creating provider for ${config.networkName} (${config.rpcUrl})`);
    this.provider = new ethers.JsonRpcProvider(config.rpcUrl);
    
    // Initialize wallet
    console.log(`Creating wallet for testing`);
    this.wallet = new ethers.Wallet(config.privateKey, this.provider);
    
    console.log(`BlockchainSimulator initialized`);
  }
  
  // Generate a transaction hash
  private generateTxHash(): string {
    this.transactionCount++;
    return `0x${Array(64).fill(0).map(() => 
      Math.floor(Math.random() * 16).toString(16)).join('')}`;
  }
  
  // Register rights in simulation
  async registerRights(data: typeof TEST_DATA, userAddress: string): Promise<any> {
    const rightsId = `RR-${Date.now()}-${this.transactionCount}`;
    const txHash = this.generateTxHash();
    
    // Simulate blockchain delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Store the rights record 
    this.rightsRecords.set(rightsId, {
      id: rightsId,
      assetId: data.assetId,
      assetType: data.assetType,
      rightsType: data.rightsType,
      ownerType: data.ownerType,
      ownerAddress: userAddress,
      percentage: data.percentOwnership,
      startDate: data.startDate.toISOString(),
      endDate: data.endDate.toISOString(),
      territories: data.territories,
      verified: false,
      blockchainId: this.transactionCount,
      transactionHash: txHash
    });
    
    return { 
      success: true, 
      rightsId, 
      transactionHash: txHash,
      message: "Rights registered successfully (simulation)"
    };
  }
  
  // Verify rights in simulation
  async verifyRights(
    rightsId: string, 
    verifierAddress: string, 
    signature: string
  ): Promise<any> {
    if (!this.rightsRecords.has(rightsId)) {
      return { 
        success: false, 
        message: `Rights record ${rightsId} not found` 
      };
    }
    
    // Simulate blockchain delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const txHash = this.generateTxHash();
    
    // Update rights record
    const record = this.rightsRecords.get(rightsId);
    record.verified = true;
    record.verifierAddress = verifierAddress;
    record.verificationHash = txHash;
    record.verificationDate = new Date().toISOString();
    record.signature = signature;
    
    this.rightsRecords.set(rightsId, record);
    
    return {
      success: true,
      transactionHash: txHash,
      message: "Rights verified successfully (simulation)"
    };
  }
  
  // Get rights info in simulation
  async getRightsInfo(rightsId: string): Promise<any> {
    if (!this.rightsRecords.has(rightsId)) {
      return { 
        success: false, 
        message: `Rights record ${rightsId} not found` 
      };
    }
    
    // Simulate blockchain delay
    await new Promise(resolve => setTimeout(resolve, 300));
    
    return {
      success: true,
      data: this.rightsRecords.get(rightsId),
      message: "Rights info retrieved successfully (simulation)"
    };
  }
  
  // Mint NFT in simulation
  async mintNFT(
    assetId: string,
    ownerAddress: string,
    metadata: any
  ): Promise<any> {
    const tokenId = `TM-${Date.now()}-${this.transactionCount}`;
    const txHash = this.generateTxHash();
    
    // Simulate blockchain delay
    await new Promise(resolve => setTimeout(resolve, 700));
    
    // Store token
    this.tokens.set(tokenId, {
      id: tokenId,
      assetId,
      ownerAddress,
      metadata,
      mintedAt: new Date().toISOString(),
      transactionHash: txHash
    });
    
    return {
      success: true,
      tokenId,
      transactionHash: txHash,
      message: "NFT minted successfully (simulation)"
    };
  }
  
  // Get token details
  async getTokenDetails(tokenId: string): Promise<any> {
    if (!this.tokens.has(tokenId)) {
      return { 
        success: false, 
        message: `Token ${tokenId} not found` 
      };
    }
    
    // Simulate blockchain delay
    await new Promise(resolve => setTimeout(resolve, 300));
    
    return {
      success: true,
      data: this.tokens.get(tokenId),
      message: "Token details retrieved successfully (simulation)"
    };
  }
}

// Helper to generate test signature
async function generateTestSignature(message: string): Promise<string> {
  const wallet = new ethers.Wallet(TEST_CONFIG.privateKey);
  return wallet.signMessage(message);
}

// Pretty print section header
function printSection(title: string) {
  console.log(`\n${'='.repeat(80)}`);
  console.log(`${title}`);
  console.log(`${'-'.repeat(80)}`);
}

// Main test function
async function runStandaloneTests() {
  console.log('\n🚀 Starting standalone blockchain test...');
  
  // Initialize simulator
  const simulator = new BlockchainSimulator(TEST_CONFIG);
  
  try {
    // Test 1: Register Rights
    printSection('Testing Rights Registration');
    const registerResult = await simulator.registerRights(
      TEST_DATA, 
      TEST_CONFIG.userAddress
    );
    
    console.log('Register rights result:');
    console.log(JSON.stringify(registerResult, null, 2));
    
    if (!registerResult.success) {
      throw new Error(`Rights registration failed: ${registerResult.message}`);
    }
    
    const rightsId = registerResult.rightsId;
    console.log(`✅ Rights registered with ID: ${rightsId}`);
    
    // Test 2: Get Rights Info
    printSection('Testing Rights Info Retrieval');
    const infoResult = await simulator.getRightsInfo(rightsId);
    
    console.log('Rights info result:');
    console.log(JSON.stringify(infoResult, null, 2));
    
    if (!infoResult.success) {
      throw new Error(`Rights info retrieval failed: ${infoResult.message}`);
    }
    
    console.log(`✅ Rights info retrieved successfully`);
    
    // Test 3: Verify Rights
    printSection('Testing Rights Verification');
    const message = `Verify rights record ${rightsId} for asset ${TEST_DATA.assetId}`;
    const signature = await generateTestSignature(message);
    
    console.log(`Generated signature for message: "${message}"`);
    
    const verifyResult = await simulator.verifyRights(
      rightsId,
      TEST_CONFIG.userAddress,
      signature
    );
    
    console.log('Verify rights result:');
    console.log(JSON.stringify(verifyResult, null, 2));
    
    if (!verifyResult.success) {
      throw new Error(`Rights verification failed: ${verifyResult.message}`);
    }
    
    console.log(`✅ Rights verified successfully`);
    
    // Test 4: Mint NFT
    printSection('Testing NFT Minting');
    const metadata = {
      name: `Track: ${TEST_DATA.assetId}`,
      description: 'Test track NFT for TuneMantra platform',
      image: 'https://tunemantra.com/placeholder-nft.jpg',
      attributes: [
        {
          trait_type: 'Asset Type',
          value: TEST_DATA.assetType
        },
        {
          trait_type: 'Rights Type',
          value: TEST_DATA.rightsType
        },
        {
          trait_type: 'Creation Date',
          value: new Date().toISOString().split('T')[0]
        }
      ]
    };
    
    const mintResult = await simulator.mintNFT(
      TEST_DATA.assetId,
      TEST_CONFIG.userAddress,
      metadata
    );
    
    console.log('Mint NFT result:');
    console.log(JSON.stringify(mintResult, null, 2));
    
    if (!mintResult.success) {
      throw new Error(`NFT minting failed: ${mintResult.message}`);
    }
    
    const tokenId = mintResult.tokenId;
    console.log(`✅ NFT minted with token ID: ${tokenId}`);
    
    // Test 5: Get Token Details
    printSection('Testing Token Details Retrieval');
    const tokenResult = await simulator.getTokenDetails(tokenId);
    
    console.log('Token details result:');
    console.log(JSON.stringify(tokenResult, null, 2));
    
    if (!tokenResult.success) {
      throw new Error(`Token details retrieval failed: ${tokenResult.message}`);
    }
    
    console.log(`✅ Token details retrieved successfully`);
    
    // All tests passed
    printSection('TEST SUMMARY');
    console.log(`All blockchain tests completed successfully!`);
    console.log(`
Rights ID: ${rightsId}
Transaction Hash: ${registerResult.transactionHash}
Verification Hash: ${verifyResult.transactionHash}
Token ID: ${tokenId}
NFT Transaction Hash: ${mintResult.transactionHash}
    `);
    
    return true;
  } catch (error) {
    console.error(`❌ Test failed:`, error);
    return false;
  }
}

// Run the tests
runStandaloneTests()
  .then(success => {
    console.log(success 
      ? '\n✅ All blockchain tests passed!'.green.bold 
      : '\n❌ Blockchain tests failed!'.red.bold);
    process.exit(success ? 0 : 1);
  })
  .catch(error => {
    console.error(`Unhandled error in test suite:`, error);
    process.exit(1);
  });