import { rightsManagementService } from '../server/services/rights-management-service';

async function testRightsVerification() {
  console.log('Testing rights verification...');
  
  // Verify rights ownership
  const verificationResult = await rightsManagementService.verifyRightsOwnership(
    '11',
    'performance',
    12
  );
  
  console.log('Rights verification result:', JSON.stringify(verificationResult, null, 2));
}

testRightsVerification().catch(error => {
  console.error('Error testing rights verification:', error);
});
