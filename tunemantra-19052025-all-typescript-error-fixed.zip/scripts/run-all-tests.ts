/**
 * Run All Tests Script
 * 
 * This script runs all the test scripts in sequence to validate
 * the integrated functionality of TuneMantra.
 * 
 * Usage: npx tsx scripts/run-all-tests.ts
 */

import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

/**
 * Setup scripts to run first to prepare the database
 */
const SETUP_SCRIPTS = [
  'scripts/setup-missing-tables.ts'
];

/**
 * Test scripts to run after setup
 */
const TEST_SCRIPTS = [
  // Simulator scripts that don't need database access
  'scripts/blockchain-simulator.ts',
  'scripts/rights-management-simulator.ts',
  'scripts/royalty-calculation-simulator.ts',
  
  // Database-dependent test scripts
  'scripts/test-blockchain-connector.ts',
  'scripts/test-rights-management.ts',
  'scripts/test-royalty-calculation.ts',
  
  // Verification scripts
  'scripts/verify-database.ts'
];

/**
 * Run a test script
 */
async function runScript(scriptPath: string): Promise<void> {
  console.log(`\n${'='.repeat(50)}`);
  console.log(`Running: ${scriptPath}`);
  console.log(`${'='.repeat(50)}\n`);
  
  try {
    const { stdout, stderr } = await execAsync(`npx tsx ${scriptPath}`);
    
    if (stdout) {
      console.log(stdout);
    }
    
    if (stderr) {
      console.error('STDERR:', stderr);
    }
    
    console.log(`\n${'='.repeat(50)}`);
    console.log(`Completed: ${scriptPath}`);
    console.log(`${'='.repeat(50)}\n`);
  } catch (error) {
    console.error(`Error running ${scriptPath}:`, error.message);
    if (error.stdout) console.log(error.stdout);
    if (error.stderr) console.error(error.stderr);
  }
}

/**
 * Run all test scripts in sequence
 */
async function runAllTests(): Promise<void> {
  console.log(`\n${'#'.repeat(70)}`);
  console.log(`Starting TuneMantra Integration Tests at ${new Date().toLocaleString()}`);
  console.log(`${'#'.repeat(70)}\n`);
  
  // First run setup scripts
  console.log(`\nRunning setup scripts...\n`);
  for (const script of SETUP_SCRIPTS) {
    await runScript(script);
    
    // Add a small delay to ensure connections are properly closed
    console.log(`\nWaiting 2 seconds before continuing...\n`);
    await new Promise(resolve => setTimeout(resolve, 2000));
  }
  
  // Then run test scripts
  console.log(`\nRunning test scripts...\n`);
  for (const script of TEST_SCRIPTS) {
    await runScript(script);
    
    // Add a small delay to ensure connections are properly closed
    console.log(`\nWaiting 2 seconds before running next test...\n`);
    await new Promise(resolve => setTimeout(resolve, 2000));
  }
  
  console.log(`\n${'#'.repeat(70)}`);
  console.log(`All tests completed at ${new Date().toLocaleString()}`);
  console.log(`${'#'.repeat(70)}\n`);
}

// Run all tests
runAllTests();