import fetch from 'node-fetch';

async function login() {
  const response = await fetch('http://localhost:5000/api/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'lunar_echo', password: 'testPassword123' })
  });
  
  const cookie = response.headers.get('set-cookie');
  return cookie;
}

async function getDistributionStatistics(cookie) {
  const response = await fetch('http://localhost:5000/api/distribution-status/statistics', {
    headers: { Cookie: cookie }
  });
  
  const data = await response.json();
  return data;
}

async function main() {
  try {
    const cookie = await login();
    console.log('Authentication successful');
    
    // Get distribution statistics
    const statistics = await getDistributionStatistics(cookie);
    console.log(JSON.stringify(statistics, null, 2));
    
  } catch (error) {
    console.error('Error:', error.message);
  }
}

main();