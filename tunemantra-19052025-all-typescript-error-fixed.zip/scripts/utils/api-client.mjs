/**
 * TuneMantra API Client
 * 
 * A unified API client for interacting with the TuneMantra platform.
 * This client provides consistent error handling, validation, and business logic
 * for all API interactions.
 */

import fs from 'fs';
import { exec } from 'child_process';
import util from 'util';

const execAsync = util.promisify(exec);
const SERVER_URL = 'http://localhost:5000';

/**
 * Execute a curl command and return the response
 * 
 * @param {string} command - The curl command to execute
 * @returns {Promise<string>} The response from the command
 */
async function executeCurl(command) {
  try {
    const { stdout, stderr } = await execAsync(command);
    return stdout;
  } catch (error) {
    console.error(`Error executing curl: ${error.message}`);
    throw error;
  }
}

/**
 * Parse a JSON response from a verbose curl output
 * 
 * @param {string} response - The verbose curl response
 * @returns {Object|null} The parsed JSON object or null if parsing failed
 */
function parseJsonFromCurlResponse(response) {
  if (!response) {
    console.error('Empty response received');
    return null;
  }
  
  // First, try to parse the entire response as JSON directly
  try {
    return JSON.parse(response);
  } catch (error) {
    // If that fails, try to extract JSON from verbose output
    
    // Check for JSON in a more robust manner with multiple patterns
    // Look for JSON object pattern
    const objectPattern = /\{[\s\S]*\}/;
    const objectMatch = response.match(objectPattern);
    
    // Look for JSON array pattern
    const arrayPattern = /\[[\s\S]*\]/;
    const arrayMatch = response.match(arrayPattern);
    
    // Try to use the matched JSON
    let jsonPart = null;
    if (objectMatch) {
      jsonPart = objectMatch[0];
    } else if (arrayMatch) {
      jsonPart = arrayMatch[0];
    }
    
    if (jsonPart) {
      try {
        return JSON.parse(jsonPart);
      } catch (parseError) {
        console.error('Found JSON-like data but parsing failed:', parseError.message);
      }
    }
    
    // Handle various other response formats as a last resort
    if (response.includes('true') || response.includes('false')) {
      // Simple boolean response
      if (response.includes('true')) return { success: true };
      if (response.includes('false')) return { success: false };
    }
    
    console.error('Could not find valid JSON data in response');
    console.log('Raw response excerpt:', response.substring(0, 300) + (response.length > 300 ? '...' : ''));
    return null;
  }
}

/**
 * Extract session cookie from a curl response
 * 
 * @param {string} response - The verbose curl response
 * @returns {string|null} The session cookie or null if not found
 */
function extractSessionCookie(response) {
  // Try to extract cookie from response headers
  const setCookieMatch = response.match(/< Set-Cookie: (connect\.sid=[^;]+)/i);
  if (setCookieMatch && setCookieMatch[1]) {
    return setCookieMatch[1];
  }
  return null;
}

/**
 * Read cookie from disk
 * 
 * @returns {string|null} The session cookie or null if not found
 */
function getStoredCookie() {
  if (fs.existsSync('session.txt')) {
    const cookie = fs.readFileSync('session.txt', 'utf8').trim();
    if (cookie) {
      return cookie;
    }
  }
  
  // Try to extract from cookies.txt as fallback
  if (fs.existsSync('cookies.txt')) {
    const cookieContent = fs.readFileSync('cookies.txt', 'utf8');
    const cookieMatch = cookieContent.match(/connect\.sid\s+([^\s]+)/);
    if (cookieMatch && cookieMatch[1]) {
      const sessionId = cookieMatch[1];
      const cookie = `connect.sid=${sessionId}`;
      // Save it for future use
      fs.writeFileSync('session.txt', cookie, 'utf8');
      return cookie;
    }
  }
  
  return null;
}

/**
 * Save session cookie to disk
 * 
 * @param {string} cookie - The session cookie to save
 */
function saveSessionCookie(cookie) {
  if (cookie) {
    fs.writeFileSync('session.txt', cookie, 'utf8');
    console.log('Session cookie saved to session.txt');
  }
}

/**
 * TuneMantra API Client class
 */
class TuneMantraClient {
  constructor() {
    this.baseUrl = SERVER_URL;
    this.sessionCookie = getStoredCookie();
  }
  
  /**
   * Login to the TuneMantra API
   * 
   * @param {string} username - The username to login with
   * @param {string} password - The password to login with
   * @returns {Promise<boolean>} Whether login was successful
   */
  async login(username, password) {
    console.log(`Attempting login as ${username}...`);
    
    // Clear existing cookies
    if (fs.existsSync('cookies.txt')) {
      fs.writeFileSync('cookies.txt', '', 'utf8');
    }
    if (fs.existsSync('session.txt')) {
      fs.writeFileSync('session.txt', '', 'utf8');  
    }
    
    try {
      // Simpler login approach using just application/json
      const simpleLoginCommand = `curl -X POST -c cookies.txt -H "Content-Type: application/json" -d '{"username":"${username}","password":"${password}"}' ${this.baseUrl}/api/login`;
      const simpleResponse = await executeCurl(simpleLoginCommand);
      
      console.log('Login response received, checking for success...');
      
      // Check for cookies in the cookies.txt file
      if (fs.existsSync('cookies.txt')) {
        const cookieContent = fs.readFileSync('cookies.txt', 'utf8');
        if (cookieContent.includes('connect.sid')) {
          console.log('Found session cookie in cookies.txt');
          const cookieMatch = cookieContent.match(/connect\.sid\s+([^\s]+)/);
          if (cookieMatch && cookieMatch[1]) {
            const sessionId = cookieMatch[1];
            const cookie = `connect.sid=${sessionId}`;
            this.sessionCookie = cookie;
            saveSessionCookie(cookie);
            console.log('Login successful (cookie obtained from cookies.txt)');
            
            // Test the cookie with a simple API call to verify it works
            const testCommand = `curl -s -H "Cookie: ${cookie}" ${this.baseUrl}/api/user`;
            const testResponse = await executeCurl(testCommand);
            
            if (testResponse && (testResponse.includes('"isAuthenticated":true') || testResponse.includes('"id":'))) {
              console.log('Session cookie verified as working!');
              return true;
            } else {
              console.log('Cookie obtained but authentication check failed');
            }
            
            // Still return true since we have a cookie
            return true;
          }
        }
      }
      
      // No cookie found, check if the response itself indicates success
      if (simpleResponse) {
        try {
          // Try to parse JSON directly from response
          const jsonResponse = JSON.parse(simpleResponse);
          if (jsonResponse && (jsonResponse.id || jsonResponse.success || jsonResponse.isAuthenticated)) {
            console.log('Login successful based on JSON response');
            return true;
          }
        } catch (parseError) {
          console.log('Response is not valid JSON');
        }
      }
      
      // Fallback method: Try with form data approach
      console.log('Simple login failed, trying with form data...');
      const formLoginCommand = `curl -X POST -c cookies.txt -d "username=${username}&password=${password}" ${this.baseUrl}/api/login`;
      await executeCurl(formLoginCommand);
      
      // Check cookies again
      if (fs.existsSync('cookies.txt')) {
        const cookieContent = fs.readFileSync('cookies.txt', 'utf8');
        if (cookieContent.includes('connect.sid')) {
          const cookieMatch = cookieContent.match(/connect\.sid\s+([^\s]+)/);
          if (cookieMatch && cookieMatch[1]) {
            const sessionId = cookieMatch[1];
            const cookie = `connect.sid=${sessionId}`;
            this.sessionCookie = cookie;
            saveSessionCookie(cookie);
            console.log('Login successful with form approach');
            return true;
          }
        }
      }
      
      console.error('All login attempts failed: No valid session cookie obtained');
      return false;
    } catch (error) {
      console.error(`Login failed with error: ${error.message}`);
      return false;
    }
  }
  
  /**
   * Get cookie header for API requests
   * 
   * @returns {string} The cookie header
   */
  getCookieHeader() {
    // Check if we need to reload the cookie
    if (!this.sessionCookie) {
      this.sessionCookie = getStoredCookie();
    }
    
    if (this.sessionCookie) {
      return `-H "Cookie: ${this.sessionCookie}"`;
    } else if (fs.existsSync('cookies.txt')) {
      return `-b cookies.txt`;
    } else {
      console.warn('Warning: No session cookie found!');
      return '';
    }
  }
  
  /**
   * Execute an API GET request
   * 
   * @param {string} endpoint - The API endpoint to call
   * @returns {Promise<Object|null>} The response or null on error
   */
  async get(endpoint) {
    const cookieHeader = this.getCookieHeader();
    const command = `curl -X GET -H "Content-Type: application/json" ${cookieHeader} ${this.baseUrl}${endpoint} -v`;
    
    try {
      const response = await executeCurl(command);
      console.log(`GET ${endpoint} response received`);
      return parseJsonFromCurlResponse(response);
    } catch (error) {
      console.error(`GET ${endpoint} failed: ${error.message}`);
      return null;
    }
  }
  
  /**
   * Execute an API POST request
   * 
   * @param {string} endpoint - The API endpoint to call
   * @param {Object} data - The data to send
   * @returns {Promise<Object|null>} The response or null on error
   */
  async post(endpoint, data) {
    const cookieHeader = this.getCookieHeader();
    const dataString = JSON.stringify(data);
    const command = `curl -X POST -H "Content-Type: application/json" ${cookieHeader} -d '${dataString}' ${this.baseUrl}${endpoint} -v`;
    
    try {
      const response = await executeCurl(command);
      console.log(`POST ${endpoint} response received`);
      return parseJsonFromCurlResponse(response);
    } catch (error) {
      console.error(`POST ${endpoint} failed: ${error.message}`);
      return null;
    }
  }
  
  /**
   * Get platform royalty rates
   * 
   * @returns {Promise<Object|null>} The platform rates or null on error
   */
  async getPlatformRates() {
    console.log('Getting platform royalty rates...');
    return this.get('/api/royalties/platform-rates');
  }
  
  /**
   * Calculate batch royalties for tracks
   * 
   * @param {number[]} trackIds - Track IDs to calculate royalties for
   * @param {Object} options - Additional options
   * @param {boolean} options.storeResults - Whether to store the results
   * @param {boolean} options.forceRecalculation - Whether to force recalculation
   * @returns {Promise<Object|null>} The calculation results or null on error
   */
  async calculateBatchRoyaltiesForTracks(trackIds, options = { storeResults: false, forceRecalculation: true }) {
    console.log(`Calculating batch royalties for tracks: ${trackIds.join(', ')}`);
    return this.post('/api/royalties/batch-calculations', {
      trackIds,
      storeResults: options.storeResults,
      forceRecalculation: options.forceRecalculation
    });
  }
  
  /**
   * Calculate batch royalties for a release
   * 
   * @param {number} releaseId - Release ID to calculate royalties for
   * @param {Object} options - Additional options
   * @param {boolean} options.storeResults - Whether to store the results
   * @param {boolean} options.forceRecalculation - Whether to force recalculation
   * @returns {Promise<Object|null>} The calculation results or null on error
   */
  async calculateBatchRoyaltiesForRelease(releaseId, options = { storeResults: false, forceRecalculation: true }) {
    console.log(`Calculating batch royalties for release: ${releaseId}`);
    return this.post('/api/royalties/batch-calculations', {
      releaseId,
      storeResults: options.storeResults,
      forceRecalculation: options.forceRecalculation
    });
  }
  
  /**
   * Process integration between distribution and royalty systems
   * 
   * @param {number} distributionRecordId - Distribution record ID to process
   * @returns {Promise<Object|null>} The processing results or null on error
   */
  async processDistributionIntegration(distributionRecordId) {
    console.log(`Processing integration for distribution record: ${distributionRecordId}`);
    return this.post(`/api/integration/trigger/${distributionRecordId}`, {
      forceRecalculation: true
    });
  }
  
  /**
   * Process batch integration for multiple distribution records
   * 
   * @param {Object} options - Processing options
   * @param {number[]} options.distributionRecordIds - Optional specific distribution record IDs
   * @param {string} options.startDate - Optional start date for filtering
   * @param {string} options.endDate - Optional end date for filtering
   * @param {number} options.limit - Optional maximum number of records to process
   * @returns {Promise<Object|null>} The processing results or null on error
   */
  async processBatchIntegration(options = {}) {
    console.log('Processing batch integration');
    return this.post('/api/integration/batch-royalty-integration', options);
  }
  
  /**
   * Get platform-specific royalty analytics
   * 
   * @param {string} timeframe - The timeframe to get analytics for (e.g., 'last30days', 'last3months')
   * @param {number} platformId - Optional platform ID to filter by
   * @returns {Promise<Object|null>} The analytics data or null on error
   */
  async getPlatformRoyaltyAnalytics(timeframe = 'last30days', platformId = null) {
    let endpoint = `/api/royalties/platform-analytics?timeframe=${timeframe}`;
    if (platformId) {
      endpoint += `&platformId=${platformId}`;
    }
    return this.get(endpoint);
  }
}

// Create and export a singleton instance
const client = new TuneMantraClient();
export default client;