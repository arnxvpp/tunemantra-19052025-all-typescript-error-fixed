/**
 * Script to update a user's password for testing
 * 
 * This script allows us to set a known password for an existing user,
 * which is useful for API testing.
 */
import { scrypt, randomBytes } from 'crypto';
import { promisify } from 'util';
import { eq } from 'drizzle-orm';
import pkg from 'pg';
const { Pool } = pkg;
import { drizzle } from 'drizzle-orm/pg-server';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Create a database connection pool
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// Import the schema - using CommonJS require since we're having import issues
import { createRequire } from 'module';
const require = createRequire(import.meta.url);
const schema = require('./shared/schema');
const users = schema.users;

// Initialize Drizzle ORM
const db = drizzle(pool);

// Convert scrypt to Promise-based function
const scryptAsync = promisify(scrypt);

/**
 * Hash a password with scrypt and random salt
 */
async function hashPassword(password) {
  // Generate a random 16-byte salt and convert to hex string
  const salt = randomBytes(16).toString('hex');
  
  // Hash the password with the salt (64-byte output)
  const buf = await scryptAsync(password, salt, 64);
  
  // Combine hash and salt with a period separator
  return `${buf.toString('hex')}.${salt}`;
}

/**
 * Update a user's password
 */
async function updateUserPassword(username, newPassword) {
  try {
    console.log(`Updating password for user: ${username}`);
    
    // First check if the user exists
    const user = await db.select().from(users).where(eq(users.username, username));
    
    if (!user || user.length === 0) {
      console.error(`User not found: ${username}`);
      return false;
    }
    
    // Hash the new password
    const hashedPassword = await hashPassword(newPassword);
    
    // Update the user's password
    await db.update(users)
      .set({ password: hashedPassword })
      .where(eq(users.username, username));
    
    console.log(`Password updated successfully for user: ${username}`);
    return true;
  } catch (error) {
    console.error('Error updating password:', error);
    return false;
  }
}

// Usage
const username = 'skyline';
const newPassword = 'Skyline2024!';

updateUserPassword(username, newPassword)
  .then(success => {
    if (success) {
      console.log(`Password for ${username} has been set to "${newPassword}"`);
    } else {
      console.log('Password update failed');
    }
    process.exit(0);
  })
  .catch(error => {
    console.error('Unhandled error:', error);
    process.exit(1);
  });