#!/usr/bin/env ts-node

/**
 * TuneMantra Code Watermarking Tool
 * 
 * This script automatically applies various watermarking techniques to
 * source code files, creating uniquely identifiable versions for different
 * developers or teams.
 * 
 * Usage: 
 *   npx ts-node scripts/utils/watermark_code.ts --developer-id DEV123 --output-dir ./watermarked-code
 * 
 * Note: This script should be run on a separate copy of the codebase, not
 * directly on your main development repository.
 */

import * as fs from 'fs';
import * as path from 'path';
import * as crypto from 'crypto';
import { program } from 'commander';

// Configure command-line options
program
  .requiredOption('-d, --developer-id <id>', 'Unique identifier for the developer receiving the code')
  .requiredOption('-o, --output-dir <dir>', 'Output directory for watermarked code')
  .option('-s, --source-dir <dir>', 'Source code directory', '.')
  .option('-p, --patterns <patterns>', 'Comma-separated list of watermarking patterns to apply', 'all')
  .option('-e, --extensions <extensions>', 'Comma-separated list of file extensions to process', '.ts,.tsx,.js,.jsx')
  .option('-i, --ignore <patterns>', 'Comma-separated list of directories or files to ignore', 'node_modules,dist,build,.git')
  .option('-v, --verbose', 'Show verbose output', false);

program.parse(process.argv);
const options = program.opts();

// Setup variables
const developerId = options.developerId;
const sourceDir = path.resolve(options.sourceDir);
const outputDir = path.resolve(options.outputDir);
const extensions = options.extensions.split(',');
const ignorePatterns = options.ignorePatterns ? options.ignorePatterns.split(',') : [];
const watermarkPatterns = options.patterns === 'all' ? ['comments', 'whitespace', 'variables', 'strings'] : options.patterns.split(',');
const verbose = options.verbose;

// Ensure developer ID is hashed for security
const developerHash = crypto.createHash('sha256').update(developerId).digest('hex').substring(0, 8);

// Track files processed and patterns applied
const stats = {
  filesProcessed: 0,
  commentWatermarks: 0,
  whitespaceWatermarks: 0,
  variableWatermarks: 0,
  stringWatermarks: 0
};

/**
 * Generate a unique watermark signature based on developer ID
 */
function generateWatermarkSignature(developerIdentifier: string, fileRelativePath: string): string {
  const combined = `${developerIdentifier}:${fileRelativePath}`;
  return crypto.createHash('md5').update(combined).digest('hex').substring(0, 6);
}

/**
 * Apply comment watermarks to source code
 */
function applyCommentWatermarks(content: string, filePath: string): string {
  // Generate a unique signature for this file and developer
  const signature = generateWatermarkSignature(developerId, filePath);
  
  // Add a TuneMantra comment with developer signature
  const watermarkComment = `// TM-${developerHash}-${signature}`;
  
  // Insert at random positions in the file
  const lines = content.split('\n');
  
  // Choose a few positions to insert watermarks (based on file size)
  const positions = [];
  const numWatermarks = Math.max(1, Math.floor(lines.length / 200)); // One watermark per ~200 lines
  
  for (let i = 0; i < numWatermarks; i++) {
    // Choose positions that are likely to be in code sections
    const position = Math.floor(Math.random() * (lines.length - 20)) + 10;
    positions.push(position);
  }
  
  // Sort positions in descending order to avoid affecting subsequent line numbers
  positions.sort((a, b) => b - a);
  
  // Insert watermarks
  for (const position of positions) {
    lines.splice(position, 0, watermarkComment);
    stats.commentWatermarks++;
  }
  
  return lines.join('\n');
}

/**
 * Apply whitespace pattern watermarks
 */
function applyWhitespaceWatermarks(content: string, filePath: string): string {
  const signature = generateWatermarkSignature(developerId, filePath);
  const lines = content.split('\n');
  
  // Create a deterministic but developer-specific whitespace pattern
  // Extract bits from signature to determine indentation style
  const signatureBits = parseInt(signature, 16);
  
  // Use 2 spaces for some developers, 4 for others based on signature
  const indentStyle = (signatureBits % 2 === 0) ? '  ' : '    ';
  
  // Select a few places to apply the pattern
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    // Only apply to indented lines that aren't comments
    if (line.startsWith('  ') && !line.trimStart().startsWith('//') && !line.trimStart().startsWith('/*')) {
      // Apply the developer-specific indentation style
      const leadingSpaces = line.search(/\S/); // Count leading spaces
      if (leadingSpaces > 0) {
        const content = line.trimStart();
        const newIndent = indentStyle.repeat(Math.floor(leadingSpaces / 2));
        lines[i] = newIndent + content;
        stats.whitespaceWatermarks++;
        
        // Only apply to some lines based on signature to avoid changing too much
        if ((i % parseInt(signature.substring(0, 2), 16)) !== 0) {
          break;
        }
      }
    }
  }
  
  return lines.join('\n');
}

/**
 * Apply variable name watermarking
 * Modifies non-essential variable names with developer-specific variants
 */
function applyVariableWatermarks(content: string, filePath: string): string {
  // This is a simplified implementation
  // In production, you would use a TypeScript parser to safely modify variable names
  
  // Define a list of common variable name patterns to look for
  const commonVariables = [
    { pattern: /const (\w+Result) =/g, replacement: `const $1_${developerHash.substring(0, 3)} =` },
    { pattern: /const (\w+Response) =/g, replacement: `const $1_${developerHash.substring(0, 3)} =` },
    { pattern: /const (\w+Config) =/g, replacement: `const $1_${developerHash.substring(0, 3)} =` }
  ];
  
  let modifiedContent = content;
  
  // Apply variable name modifications
  for (const varPattern of commonVariables) {
    const matches = content.match(varPattern.pattern);
    if (matches && matches.length > 0) {
      modifiedContent = modifiedContent.replace(varPattern.pattern, varPattern.replacement);
      stats.variableWatermarks += matches.length;
    }
  }
  
  return modifiedContent;
}

/**
 * Apply string constant watermarking
 */
function applyStringWatermarks(content: string, filePath: string): string {
  // Safety: Avoid modifying sensitive strings
  if (
    filePath.includes('auth') || 
    filePath.includes('password') || 
    filePath.includes('security') ||
    filePath.includes('credentials')
  ) {
    return content;
  }
  
  // Target error messages and logging strings
  const errorPattern = /(["'])(Error|Failed|Unable to|Could not)([^"']*)(["'])/g;
  const logPattern = /(console\.log\(["'])(.*?)(["'])/g;
  
  let modifiedContent = content;
  
  // Add subtle watermarks to error messages
  modifiedContent = modifiedContent.replace(errorPattern, (match, quote1, prefix, message, quote2) => {
    // Add a hidden marker to the error message
    stats.stringWatermarks++;
    return `${quote1}${prefix}${message} [${developerHash.substring(0, 4)}]${quote2}`;
  });
  
  // Add subtle watermarks to log messages
  modifiedContent = modifiedContent.replace(logPattern, (match, prefix, message, suffix) => {
    // Only add to some log messages based on content
    if (message.length > 10 && !message.includes('${')) {
      stats.stringWatermarks++;
      return `${prefix}${message} [${developerHash.substring(0, 4)}]${suffix}`;
    }
    return match;
  });
  
  return modifiedContent;
}

/**
 * Process a single file to apply watermarks
 */
function processFile(filePath: string, relativeFilePath: string): void {
  if (verbose) {
    console.log(`Processing: ${relativeFilePath}`);
  }
  
  // Read the source file
  let content: string;
  try {
    content = fs.readFileSync(filePath, 'utf-8');
  } catch (err) {
    console.error(`Error reading file ${filePath}:`, err);
    return;
  }
  
  // Apply selected watermarking techniques
  let watermarkedContent = content;
  
  if (watermarkPatterns.includes('comments')) {
    watermarkedContent = applyCommentWatermarks(watermarkedContent, relativeFilePath);
  }
  
  if (watermarkPatterns.includes('whitespace')) {
    watermarkedContent = applyWhitespaceWatermarks(watermarkedContent, relativeFilePath);
  }
  
  if (watermarkPatterns.includes('variables')) {
    watermarkedContent = applyVariableWatermarks(watermarkedContent, relativeFilePath);
  }
  
  if (watermarkPatterns.includes('strings')) {
    watermarkedContent = applyStringWatermarks(watermarkedContent, relativeFilePath);
  }
  
  // Create the output directory if it doesn't exist
  const outputFilePath = path.join(outputDir, relativeFilePath);
  const outputFileDir = path.dirname(outputFilePath);
  
  fs.mkdirSync(outputFileDir, { recursive: true });
  
  // Write the watermarked file
  try {
    fs.writeFileSync(outputFilePath, watermarkedContent);
    stats.filesProcessed++;
  } catch (err) {
    console.error(`Error writing file ${outputFilePath}:`, err);
  }
}

/**
 * Process files recursively in a directory
 */
function processDirectory(directory: string, baseDir: string = directory): void {
  const entries = fs.readdirSync(directory, { withFileTypes: true });
  
  for (const entry of entries) {
    const entryPath = path.join(directory, entry.name);
    const relativeToBase = path.relative(baseDir, entryPath);
    
    // Skip ignored paths
    if (ignorePatterns.some(pattern => entryPath.includes(pattern))) {
      continue;
    }
    
    if (entry.isDirectory()) {
      processDirectory(entryPath, baseDir);
    } else if (entry.isFile()) {
      const fileExtension = path.extname(entry.name);
      
      // Process only files with target extensions
      if (extensions.includes(fileExtension)) {
        processFile(entryPath, relativeToBase);
      } else {
        // Copy non-source files as-is
        const outputFilePath = path.join(outputDir, relativeToBase);
        const outputFileDir = path.dirname(outputFilePath);
        
        fs.mkdirSync(outputFileDir, { recursive: true });
        fs.copyFileSync(entryPath, outputFilePath);
      }
    }
  }
}

/**
 * Generate a detailed watermark report
 */
function generateReport(): void {
  const reportPath = path.join(outputDir, 'watermark-report.json');
  const report = {
    timestamp: new Date().toISOString(),
    developerId,
    developerHash,
    stats,
    options: {
      patterns: watermarkPatterns,
      extensions,
      ignorePatterns
    }
  };
  
  // Write report to output directory (but keep it private)
  fs.writeFileSync(reportPath, JSON.stringify(report, null, 2));
  
  // Print summary to console
  console.log('\nWatermark Application Complete');
  console.log('-----------------------------');
  console.log(`Developer ID: ${developerId} (Hash: ${developerHash})`);
  console.log(`Files Processed: ${stats.filesProcessed}`);
  console.log(`Watermarks Applied:`);
  console.log(`  - Comments: ${stats.commentWatermarks}`);
  console.log(`  - Whitespace: ${stats.whitespaceWatermarks}`);
  console.log(`  - Variables: ${stats.variableWatermarks}`);
  console.log(`  - Strings: ${stats.stringWatermarks}`);
  console.log(`\nWatermarked code saved to: ${outputDir}`);
  console.log('');
}

/**
 * Main execution
 */
async function main(): Promise<void> {
  console.log(`Starting code watermarking for developer: ${developerId}`);
  console.log(`Watermark signature: ${developerHash}`);
  
  // Ensure the output directory exists
  fs.mkdirSync(outputDir, { recursive: true });
  
  // Process the source directory
  processDirectory(sourceDir);
  
  // Generate report
  generateReport();
}

// Run the program
main().catch(err => {
  console.error('Error during watermarking process:', err);
  process.exit(1);
});