import fetch from 'node-fetch';

async function login() {
  const response = await fetch('http://localhost:5000/api/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'lunar_echo', password: 'testPassword123' })
  });
  
  const cookie = response.headers.get('set-cookie');
  return cookie;
}

async function updateDistributionStatus(cookie, recordId, statusInfo) {
  const response = await fetch(`http://localhost:5000/api/distribution-status/update/${recordId}`, {
    method: 'POST',
    headers: { 
      'Content-Type': 'application/json',
      'Cookie': cookie 
    },
    body: JSON.stringify(statusInfo)
  });
  
  const data = await response.json();
  return data;
}

async function main() {
  try {
    const cookie = await login();
    console.log('Authentication successful');
    
    // Update status for distribution record #8
    const statusInfo = {
      status: 'live',  // Change from "published with issues" to "live"
      message: 'All content is now fully live on platform',
      platformReleaseId: 'YT23456789',
      liveDate: new Date().toISOString(),
      availableStores: ['YouTube Music', 'Spotify', 'Apple Music'],
      streamingLinks: {
        'youtube_music': 'https://music.youtube.com/playlist?list=PLY23456789',
        'spotify': 'https://open.spotify.com/album/12345',
        'apple_music': 'https://music.apple.com/album/67890'
      }
    };
    
    const result = await updateDistributionStatus(cookie, 8, statusInfo);
    console.log(JSON.stringify(result, null, 2));
    
  } catch (error) {
    console.error('Error:', error.message);
  }
}

main();