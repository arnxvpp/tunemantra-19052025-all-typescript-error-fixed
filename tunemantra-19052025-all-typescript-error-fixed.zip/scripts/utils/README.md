# TuneMantra Utility Scripts

This directory contains utility scripts for managing and maintaining the TuneMantra platform.

## Documentation Utilities

### [split_documentation.js](./split_documentation.js)

A Node.js script that splits the large comprehensive documentation file (8.9MB) into smaller, more manageable section files to improve browser performance and prevent crashes when viewing the documentation.

**Usage:**
```
node scripts/utils/split_documentation.js
```

**Features:**
- Splits documentation at top-level section headers (# N. Section Title)
- Creates a separate Introduction file for content before the first section
- Generates consistent filenames based on section numbers and titles
- Creates a README.md index file listing all sections
- Preserves all formatting and content from the original file

**Output:**
- Individual section files in the documentation/sections/ directory
- README.md index file in the same directory

This script was created on March 30, 2025 to address performance issues with the oversized comprehensive documentation file.

## Other Utilities

Additional utility scripts in this directory are used for various maintenance and operational tasks. Each script includes inline documentation describing its purpose and usage.