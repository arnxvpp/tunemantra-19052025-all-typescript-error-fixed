import fetch from 'node-fetch';

async function login() {
  const response = await fetch('http://localhost:5000/api/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'lunar_echo', password: 'testPassword123' })
  });
  
  const cookie = response.headers.get('set-cookie');
  return cookie;
}

async function getDistributionDetails(cookie, recordId) {
  const response = await fetch(`http://localhost:5000/api/distribution-status/records/${recordId}`, {
    headers: { Cookie: cookie }
  });
  
  const data = await response.json();
  return data;
}

async function main() {
  try {
    const cookie = await login();
    console.log('Authentication successful');
    
    // Get detailed info for distribution record #8
    const record = await getDistributionDetails(cookie, 8);
    console.log(JSON.stringify(record, null, 2));
    
  } catch (error) {
    console.error('Error:', error.message);
  }
}

main();