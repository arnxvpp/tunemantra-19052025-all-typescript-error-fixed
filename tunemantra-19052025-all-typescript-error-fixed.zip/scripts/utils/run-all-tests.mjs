#!/usr/bin/env node

/**
 * Comprehensive Testing Suite for TuneMantra
 * 
 * This script runs all verification and testing scripts in sequence,
 * providing a consolidated report of the platform's status.
 */

import { execSync } from 'child_process';
import { writeFileSync } from 'fs';

// ANSI color codes for output formatting
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  dim: '\x1b[2m',
  underscore: '\x1b[4m',
  blink: '\x1b[5m',
  reverse: '\x1b[7m',
  hidden: '\x1b[8m',
  
  black: '\x1b[30m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
  white: '\x1b[37m',
  
  bgBlack: '\x1b[40m',
  bgRed: '\x1b[41m',
  bgGreen: '\x1b[42m',
  bgYellow: '\x1b[43m',
  bgBlue: '\x1b[44m',
  bgMagenta: '\x1b[45m',
  bgCyan: '\x1b[46m',
  bgWhite: '\x1b[47m'
};

// List of all test scripts to run in sequence
const testScripts = [
  { name: 'Timeframe Function Tests', script: 'node test-timeframe-fixes.js' },
  { name: 'Timeframe Variable Fixes', script: 'npx tsx timeframe-variable-fixes.js' },
  { name: 'Platform Royalty Verification', script: 'npx tsx final-royalty-verification.js' },
  { name: 'Full Platform Verification', script: 'npx tsx final-verification.js' }
];

// Store test results
const results = [];
let allPassed = true;

// Run each test script
console.log(`${colors.cyan}${colors.bright}===== TUNEMANTRA PLATFORM VERIFICATION =====${colors.reset}\n`);

for (const test of testScripts) {
  console.log(`${colors.yellow}Running ${test.name}...${colors.reset}`);
  
  try {
    // Execute the test script and capture output
    const output = execSync(test.script, { stdio: 'pipe' }).toString();
    
    // Check if the test passed based on output
    const passed = 
      !output.includes('Error') && 
      !output.includes('FAILED') && 
      !output.includes('failed');
      
    // Store the result
    results.push({
      name: test.name,
      passed,
      output
    });
    
    // Print result
    if (passed) {
      console.log(`${colors.green}✓ ${test.name} - PASSED${colors.reset}`);
    } else {
      console.log(`${colors.red}✗ ${test.name} - FAILED${colors.reset}`);
      allPassed = false;
    }
    
  } catch (error) {
    // Store the failed result
    results.push({
      name: test.name,
      passed: false,
      output: error.toString()
    });
    
    console.log(`${colors.red}✗ ${test.name} - ERROR${colors.reset}`);
    console.log(`${colors.red}${error.toString()}${colors.reset}`);
    allPassed = false;
  }
  
  console.log(); // Add a blank line between tests
}

// Print summary
console.log(`${colors.cyan}${colors.bright}===== VERIFICATION SUMMARY =====${colors.reset}\n`);

let passCount = 0;
for (const result of results) {
  const status = result.passed ? 
    `${colors.green}PASSED${colors.reset}` : 
    `${colors.red}FAILED${colors.reset}`;
  
  console.log(`${result.name}: ${status}`);
  
  if (result.passed) {
    passCount++;
  }
}

// Calculate success rate
const successRate = (passCount / results.length) * 100;
const rateColor = successRate === 100 ? colors.green : 
                  successRate >= 70 ? colors.yellow : 
                  colors.red;

console.log(`\n${colors.bright}Success Rate: ${rateColor}${successRate.toFixed(2)}%${colors.reset}`);

// Generate verification summary file
const summary = `# TuneMantra Platform Verification Summary

Date: ${new Date().toLocaleString()}

## Tests Run
${results.map(r => `- ${r.name}: ${r.passed ? 'PASSED' : 'FAILED'}`).join('\n')}

## Success Rate
${successRate.toFixed(2)}%

## Detailed Test Information

${results.map(r => {
  return `### ${r.name}\n\n**Status**: ${r.passed ? 'PASSED' : 'FAILED'}\n\nKey outputs:
\`\`\`
${r.output.split('\n').slice(0, 20).join('\n')}
${r.output.split('\n').length > 20 ? '\n[... output truncated ...]' : ''}
\`\`\`
`;
}).join('\n\n')}
`;

// Write the summary to a file
writeFileSync('VERIFICATION_SUMMARY.md', summary);

console.log(`\n${colors.blue}Verification summary saved to VERIFICATION_SUMMARY.md${colors.reset}`);

// Exit with appropriate status code
process.exit(allPassed ? 0 : 1);