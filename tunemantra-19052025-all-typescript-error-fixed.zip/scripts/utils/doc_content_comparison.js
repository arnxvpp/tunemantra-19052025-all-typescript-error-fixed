/**
 * Documentation Content Comparison Tool
 * 
 * This script helps identify unique content that exists in either the directory-based
 * documentation or the comprehensive documentation file but not in both.
 * 
 * Usage: node scripts/utils/doc_content_comparison.js
 */

import { readFileSync, writeFileSync, readdirSync, statSync, mkdirSync, existsSync } from 'fs';
import { join, extname } from 'path';

// Configuration
const COMPREHENSIVE_DOC_PATH = 'TuneMantra_Comprehensive_Documentation.md';
const DOCUMENTATION_DIR_PATH = 'documentation';
const OUTPUT_DIR = 'temp/documentation_analysis';
const EXTENSIONS_TO_CHECK = ['.md'];

// Create output directory if it doesn't exist
if (!existsSync(OUTPUT_DIR)) {
  mkdirSync(OUTPUT_DIR, { recursive: true });
}

/**
 * Read the comprehensive documentation file
 */
function readComprehensiveDoc() {
  try {
    return readFileSync(COMPREHENSIVE_DOC_PATH, 'utf8');
  } catch (error) {
    console.error(`Error reading comprehensive documentation: ${error.message}`);
    return '';
  }
}

/**
 * Read all documentation files in the documentation directory
 */
function readDocumentationFiles(dirPath = DOCUMENTATION_DIR_PATH, fileList = []) {
  const files = readdirSync(dirPath);
  
  files.forEach(file => {
    const filePath = join(dirPath, file);
    const stat = statSync(filePath);
    
    if (stat.isDirectory()) {
      readDocumentationFiles(filePath, fileList);
    } else {
      const ext = extname(file);
      if (EXTENSIONS_TO_CHECK.includes(ext)) {
        const content = readFileSync(filePath, 'utf8');
        fileList.push({
          path: filePath,
          content
        });
      }
    }
  });
  
  return fileList;
}

/**
 * Extract sections from the comprehensive documentation
 */
function extractSections(content) {
  const sections = [];
  const sectionRegex = /^#+\s+(.*?)$/gm;
  let match;
  
  while ((match = sectionRegex.exec(content)) !== null) {
    const start = match.index;
    const title = match[0];
    const level = title.match(/^#+/)[0].length;
    
    sections.push({
      title: match[1],
      level,
      start
    });
  }
  
  // Add end positions
  for (let i = 0; i < sections.length - 1; i++) {
    sections[i].end = sections[i + 1].start;
  }
  
  // Add end position for the last section
  if (sections.length > 0) {
    sections[sections.length - 1].end = content.length;
  }
  
  // Extract content for each section
  for (const section of sections) {
    section.content = content.substring(section.start, section.end);
  }
  
  return sections;
}

/**
 * Find content in comprehensive doc that doesn't exist in directory docs
 */
function findUniqueComprehensiveContent(comprehensiveContent, directoryFiles) {
  const sections = extractSections(comprehensiveContent);
  const uniqueSections = [];
  
  // Build a combined string of all directory content
  const allDirectoryContent = directoryFiles.map(file => file.content).join('\n');
  
  for (const section of sections) {
    // Skip very small sections as they're likely to be headers only
    if (section.content.length < 100) continue;
    
    // Check if section content appears in directory content
    const contentWithoutHeader = section.content.substring(section.title.length).trim();
    // Take a significant sample of the content to check (200 chars)
    const contentSample = contentWithoutHeader.substring(0, 200).trim();
    
    if (contentSample.length > 50 && !allDirectoryContent.includes(contentSample)) {
      uniqueSections.push(section);
    }
  }
  
  return uniqueSections;
}

/**
 * Find content in directory docs that doesn't exist in comprehensive doc
 */
function findUniqueDirectoryContent(comprehensiveContent, directoryFiles) {
  const uniqueFiles = [];
  
  for (const file of directoryFiles) {
    // Skip very small files
    if (file.content.length < 100) continue;
    
    // Take a significant sample of the content to check (200 chars)
    const contentSample = file.content.substring(0, 200).trim();
    
    if (contentSample.length > 50 && !comprehensiveContent.includes(contentSample)) {
      uniqueFiles.push(file);
    }
  }
  
  return uniqueFiles;
}

/**
 * Write results to output files
 */
function writeResults(uniqueComprehensiveSections, uniqueDirectoryFiles) {
  // Write unique comprehensive sections
  const comprehensiveOutput = uniqueComprehensiveSections.map(section => {
    return `## ${section.title} (Level ${section.level})\n\n${section.content}\n\n---\n\n`;
  }).join('');
  
  writeFileSync(
    join(OUTPUT_DIR, 'unique_comprehensive_content.md'),
    `# Unique Content in Comprehensive Documentation\n\nThe following sections appear in the comprehensive documentation but not in the directory-based documentation:\n\n${comprehensiveOutput}`
  );
  
  // Write unique directory files
  const directoryOutput = uniqueDirectoryFiles.map(file => {
    return `## ${file.path}\n\n${file.content}\n\n---\n\n`;
  }).join('');
  
  writeFileSync(
    join(OUTPUT_DIR, 'unique_directory_content.md'),
    `# Unique Content in Directory Documentation\n\nThe following files appear in the directory-based documentation but not in the comprehensive documentation:\n\n${directoryOutput}`
  );
  
  // Write summary
  writeFileSync(
    join(OUTPUT_DIR, 'content_comparison_summary.md'),
    `# Documentation Content Comparison Summary\n\n` +
    `Analysis completed at: ${new Date().toISOString()}\n\n` +
    `## Summary Statistics\n\n` +
    `- **Unique sections in comprehensive documentation**: ${uniqueComprehensiveSections.length}\n` +
    `- **Unique files in directory documentation**: ${uniqueDirectoryFiles.length}\n\n` +
    `## Recommendations\n\n` +
    `1. Review the unique content in the comprehensive documentation to determine if it should be added to the directory-based documentation.\n` +
    `2. Consider updating the comprehensive documentation to include unique content from the directory-based documentation.\n` +
    `3. Use the Master Index to help users navigate between both documentation sources.\n`
  );
}

/**
 * Main function to run the comparison
 */
function runComparison() {
  console.log('Reading comprehensive documentation...');
  const comprehensiveContent = readComprehensiveDoc();
  
  console.log('Reading directory-based documentation...');
  const directoryFiles = readDocumentationFiles();
  
  console.log(`Found ${directoryFiles.length} files in directory documentation`);
  
  console.log('Finding unique content in comprehensive documentation...');
  const uniqueComprehensiveSections = findUniqueComprehensiveContent(comprehensiveContent, directoryFiles);
  
  console.log('Finding unique content in directory documentation...');
  const uniqueDirectoryFiles = findUniqueDirectoryContent(comprehensiveContent, directoryFiles);
  
  console.log(`Found ${uniqueComprehensiveSections.length} unique sections in comprehensive documentation`);
  console.log(`Found ${uniqueDirectoryFiles.length} unique files in directory documentation`);
  
  console.log('Writing results...');
  writeResults(uniqueComprehensiveSections, uniqueDirectoryFiles);
  
  console.log(`Analysis complete. Results written to ${OUTPUT_DIR}`);
}

// Run the comparison
runComparison();