#!/usr/bin/env ts-node

/**
 * TuneMantra Watermark Detection Tool
 * 
 * This script scans source code to identify watermarks and determine
 * which developer's version it might be, helping to trace potential
 * code leaks.
 * 
 * Usage: 
 *   npx ts-node scripts/utils/detect_watermarks.ts --source-dir ./suspect-code
 */

import * as fs from 'fs';
import * as path from 'path';
import * as crypto from 'crypto';
import { program } from 'commander';

// Configure command-line options
program
  .requiredOption('-s, --source-dir <dir>', 'Directory containing the code to analyze')
  .option('-d, --developer-db <file>', 'JSON file with developer IDs and hashes', './developer-watermarks.json')
  .option('-e, --extensions <extensions>', 'Comma-separated list of file extensions to process', '.ts,.tsx,.js,.jsx')
  .option('-i, --ignore <patterns>', 'Comma-separated list of directories or files to ignore', 'node_modules,dist,build,.git')
  .option('-v, --verbose', 'Show verbose output', false)
  .option('-t, --threshold <number>', 'Confidence threshold (percentage) for watermark detection', '70');

program.parse(process.argv);
const options = program.opts();

// Setup variables
const sourceDir = path.resolve(options.sourceDir);
const developerDbPath = path.resolve(options.developerDb);
const extensions = options.extensions.split(',');
const ignorePatterns = options.ignorePatterns ? options.ignorePatterns.split(',') : [];
const verbose = options.verbose;
const confidenceThreshold = parseInt(options.threshold);

// Developer database structure
interface Developer {
  id: string;
  hash: string;
  name?: string;
  email?: string;
}

// Load developer database or create empty one if file doesn't exist
let developers: Developer[] = [];
try {
  if (fs.existsSync(developerDbPath)) {
    developers = JSON.parse(fs.readFileSync(developerDbPath, 'utf-8'));
  } else {
    console.warn(`Developer database file not found: ${developerDbPath}`);
    console.warn('Creating a new empty database');
    developers = [];
  }
} catch (err) {
  console.error('Error loading developer database:', err);
  process.exit(1);
}

// Data structure to store detection results
interface WatermarkMatch {
  filePath: string;
  developerHash: string;
  confidence: number;
  matches: {
    comments: number;
    whitespace: number;
    variables: number;
    strings: number;
  };
}

const results: WatermarkMatch[] = [];

/**
 * Detect comment watermarks in the code
 */
function detectCommentWatermarks(content: string): { matches: {[hash: string]: number} } {
  const matches: {[hash: string]: number} = {};
  
  // Look for TuneMantra watermark comments: // TM-[hash]-[signature]
  const watermarkRegex = /\/\/\s*TM-([a-f0-9]{8})-([a-f0-9]{6})/g;
  let match;
  
  while ((match = watermarkRegex.exec(content)) !== null) {
    const developerHash = match[1];
    
    if (!matches[developerHash]) {
      matches[developerHash] = 0;
    }
    
    matches[developerHash]++;
  }
  
  return { matches };
}

/**
 * Detect whitespace pattern watermarks
 */
function detectWhitespaceWatermarks(content: string): { matches: {[hash: string]: number} } {
  const matches: {[hash: string]: number} = {};
  
  // Count indentation styles (2-space vs 4-space)
  let twoSpaceCount = 0;
  let fourSpaceCount = 0;
  
  const lines = content.split('\n');
  for (const line of lines) {
    if (line.startsWith('  ') && !line.startsWith('    ')) {
      twoSpaceCount++;
    } else if (line.startsWith('    ')) {
      fourSpaceCount++;
    }
  }
  
  // Check against developer patterns
  for (const developer of developers) {
    // Determine expected pattern (this logic needs to match the watermarking logic)
    const signatureBits = parseInt(developer.hash.substring(0, 2), 16);
    const expectedPattern = (signatureBits % 2 === 0) ? 'two-space' : 'four-space';
    
    // Calculate a rough confidence based on indentation style prevalence
    if (expectedPattern === 'two-space' && twoSpaceCount > fourSpaceCount) {
      const confidence = Math.min(100, Math.floor((twoSpaceCount / (twoSpaceCount + fourSpaceCount)) * 100));
      matches[developer.hash] = confidence;
    } else if (expectedPattern === 'four-space' && fourSpaceCount > twoSpaceCount) {
      const confidence = Math.min(100, Math.floor((fourSpaceCount / (twoSpaceCount + fourSpaceCount)) * 100));
      matches[developer.hash] = confidence;
    }
  }
  
  return { matches };
}

/**
 * Detect variable name watermarks
 */
function detectVariableWatermarks(content: string): { matches: {[hash: string]: number} } {
  const matches: {[hash: string]: number} = {};
  
  // Check for developer-specific variable naming patterns
  for (const developer of developers) {
    const hashSuffix = developer.hash.substring(0, 3);
    const pattern = new RegExp(`\\w+_(${hashSuffix})\\s*=`, 'g');
    
    const occurrences = (content.match(pattern) || []).length;
    
    if (occurrences > 0) {
      matches[developer.hash] = occurrences;
    }
  }
  
  return { matches };
}

/**
 * Detect string constant watermarks
 */
function detectStringWatermarks(content: string): { matches: {[hash: string]: number} } {
  const matches: {[hash: string]: number} = {};
  
  // Check for patterns in error messages and log strings
  for (const developer of developers) {
    const hashMarker = developer.hash.substring(0, 4);
    const pattern = new RegExp(`\\[(${hashMarker})\\]`, 'g');
    
    const occurrences = (content.match(pattern) || []).length;
    
    if (occurrences > 0) {
      matches[developer.hash] = occurrences;
    }
  }
  
  return { matches };
}

/**
 * Process a single file to detect watermarks
 */
function processFile(filePath: string, relativeFilePath: string): void {
  if (verbose) {
    console.log(`Analyzing: ${relativeFilePath}`);
  }
  
  // Read the file
  let content: string;
  try {
    content = fs.readFileSync(filePath, 'utf-8');
  } catch (err) {
    console.error(`Error reading file ${filePath}:`, err);
    return;
  }
  
  // Run watermark detection methods
  const commentResults = detectCommentWatermarks(content);
  const whitespaceResults = detectWhitespaceWatermarks(content);
  const variableResults = detectVariableWatermarks(content);
  const stringResults = detectStringWatermarks(content);
  
  // Aggregate results for each developer
  const developerMatches: {[hash: string]: {comments: number, whitespace: number, variables: number, strings: number}} = {};
  
  // Process comment watermarks
  for (const [hash, count] of Object.entries(commentResults.matches)) {
    if (!developerMatches[hash]) {
      developerMatches[hash] = { comments: 0, whitespace: 0, variables: 0, strings: 0 };
    }
    developerMatches[hash].comments = count;
  }
  
  // Process whitespace watermarks
  for (const [hash, confidence] of Object.entries(whitespaceResults.matches)) {
    if (!developerMatches[hash]) {
      developerMatches[hash] = { comments: 0, whitespace: 0, variables: 0, strings: 0 };
    }
    developerMatches[hash].whitespace = confidence;
  }
  
  // Process variable name watermarks
  for (const [hash, count] of Object.entries(variableResults.matches)) {
    if (!developerMatches[hash]) {
      developerMatches[hash] = { comments: 0, whitespace: 0, variables: 0, strings: 0 };
    }
    developerMatches[hash].variables = count;
  }
  
  // Process string watermarks
  for (const [hash, count] of Object.entries(stringResults.matches)) {
    if (!developerMatches[hash]) {
      developerMatches[hash] = { comments: 0, whitespace: 0, variables: 0, strings: 0 };
    }
    developerMatches[hash].strings = count;
  }
  
  // Calculate confidence for each developer match
  for (const [hash, matches] of Object.entries(developerMatches)) {
    // Weight different watermark types
    const commentWeight = 0.4;  // Explicit comments are strong indicators
    const whitespaceWeight = 0.2;  // Whitespace patterns can be coincidental
    const variableWeight = 0.3;  // Variable naming is a good indicator
    const stringWeight = 0.1;  // String patterns could be common
    
    // Normalize counts to confidence values between 0-100
    const commentConfidence = matches.comments > 0 ? Math.min(100, matches.comments * 20) : 0;
    const whitespaceConfidence = matches.whitespace; // Already a percentage
    const variableConfidence = matches.variables > 0 ? Math.min(100, matches.variables * 25) : 0;
    const stringConfidence = matches.strings > 0 ? Math.min(100, matches.strings * 20) : 0;
    
    // Calculate weighted average confidence
    const overallConfidence = 
      (commentConfidence * commentWeight) +
      (whitespaceConfidence * whitespaceWeight) +
      (variableConfidence * variableWeight) +
      (stringConfidence * stringWeight);
    
    // Record results if confidence meets threshold
    if (overallConfidence >= confidenceThreshold) {
      results.push({
        filePath: relativeFilePath,
        developerHash: hash,
        confidence: Math.round(overallConfidence),
        matches: matches
      });
    }
  }
}

/**
 * Process files recursively in a directory
 */
function processDirectory(directory: string, baseDir: string = directory): void {
  const entries = fs.readdirSync(directory, { withFileTypes: true });
  
  for (const entry of entries) {
    const entryPath = path.join(directory, entry.name);
    const relativeToBase = path.relative(baseDir, entryPath);
    
    // Skip ignored paths
    if (ignorePatterns.some(pattern => entryPath.includes(pattern))) {
      continue;
    }
    
    if (entry.isDirectory()) {
      processDirectory(entryPath, baseDir);
    } else if (entry.isFile()) {
      const fileExtension = path.extname(entry.name);
      
      // Process only files with target extensions
      if (extensions.includes(fileExtension)) {
        processFile(entryPath, relativeToBase);
      }
    }
  }
}

/**
 * Generate a detection report
 */
function generateReport(): void {
  console.log('\nWatermark Detection Results');
  console.log('-------------------------');
  
  if (results.length === 0) {
    console.log('No watermarks detected with confidence above threshold.');
    return;
  }
  
  // Aggregate results by developer
  const developerResults: { [hash: string]: { files: string[], averageConfidence: number } } = {};
  
  for (const result of results) {
    if (!developerResults[result.developerHash]) {
      developerResults[result.developerHash] = { files: [], averageConfidence: 0 };
    }
    
    developerResults[result.developerHash].files.push(result.filePath);
    developerResults[result.developerHash].averageConfidence += result.confidence;
  }
  
  // Calculate average confidence
  for (const [hash, data] of Object.entries(developerResults)) {
    data.averageConfidence = Math.round(data.averageConfidence / data.files.length);
  }
  
  // Sort developers by confidence
  const sortedDevelopers = Object.entries(developerResults)
    .sort((a, b) => b[1].averageConfidence - a[1].averageConfidence);
  
  // Print results
  for (const [hash, data] of sortedDevelopers) {
    // Find developer info
    const developer = developers.find(d => d.hash === hash) || { id: 'Unknown', name: 'Unknown' };
    
    console.log(`\nDeveloper: ${developer.name || developer.id}`);
    console.log(`Developer ID: ${developer.id}`);
    console.log(`Confidence: ${data.averageConfidence}%`);
    console.log(`Files with watermarks: ${data.files.length}`);
    
    if (verbose) {
      console.log('Files:');
      data.files.slice(0, 10).forEach(file => console.log(`  - ${file}`));
      if (data.files.length > 10) {
        console.log(`  - ... and ${data.files.length - 10} more files`);
      }
    }
  }
  
  // Summary
  console.log('\nSummary:');
  console.log(`Analyzed source code in: ${sourceDir}`);
  console.log(`Most likely source: ${sortedDevelopers[0][0]} (${sortedDevelopers[0][1].averageConfidence}% confidence)`);
  
  // Save detailed report to file
  const reportPath = path.join(process.cwd(), 'watermark-detection-report.json');
  const report = {
    timestamp: new Date().toISOString(),
    sourceDirectory: sourceDir,
    confidenceThreshold,
    results: sortedDevelopers.map(([hash, data]) => {
      const developer = developers.find(d => d.hash === hash) || { id: 'Unknown' };
      return {
        developerHash: hash,
        developerId: developer.id,
        developerName: developer.name,
        confidence: data.averageConfidence,
        fileCount: data.files.length,
        files: data.files
      };
    })
  };
  
  fs.writeFileSync(reportPath, JSON.stringify(report, null, 2));
  console.log(`\nDetailed report saved to: ${reportPath}`);
}

/**
 * Main execution
 */
async function main(): Promise<void> {
  console.log(`Starting watermark detection in: ${sourceDir}`);
  console.log(`Developer database: ${developerDbPath} (${developers.length} developers)`);
  console.log(`Confidence threshold: ${confidenceThreshold}%`);
  
  // Process the source directory
  processDirectory(sourceDir);
  
  // Generate report
  generateReport();
}

// Run the program
main().catch(err => {
  console.error('Error during watermark detection:', err);
  process.exit(1);
});