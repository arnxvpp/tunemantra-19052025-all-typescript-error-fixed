/**
 * Documentation Splitter
 * 
 * This script splits the large comprehensive documentation file (8.9MB) into
 * smaller, more manageable section files to improve browser performance and
 * prevent crashes when viewing the documentation.
 * 
 * Usage:
 *   node scripts/utils/split_documentation.js
 * 
 * Features:
 * - Splits documentation at top-level section headers (# N. Section Title)
 * - Creates a separate Introduction file for content before the first section
 * - Generates consistent filenames based on section numbers and titles
 * - Creates a README.md index file listing all sections
 * - Preserves all formatting and content from the original file
 * 
 * Output:
 * - Individual section files in the documentation/sections/ directory
 * - README.md index file in the same directory
 * 
 * This script helps solve browser performance issues caused by the very large
 * comprehensive documentation file (8.9MB) by breaking it into manageable chunks
 * without losing any content or context.
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const SOURCE_FILE = 'documentation/TuneMantra_Comprehensive_Documentation.md';
const OUTPUT_DIR = 'documentation/sections';
const INDEX_FILE = 'documentation/sections/README.md';

// Create output directory if it doesn't exist
if (!fs.existsSync(OUTPUT_DIR)) {
  fs.mkdirSync(OUTPUT_DIR, { recursive: true });
}

// Read the source file
const content = fs.readFileSync(SOURCE_FILE, 'utf8');

// Define a regex to find section headers (top level headers)
const sectionHeaderRegex = /^# (\d+)\. (.+)$/gm;

// Find all section headers
let sections = [];
let match;
const matches = [...content.matchAll(sectionHeaderRegex)];

// Create an array to store section information
for (let i = 0; i < matches.length; i++) {
  const match = matches[i];
  const sectionNum = match[1];
  const sectionTitle = match[2];
  const sectionStart = match.index;
  const sectionEnd = i < matches.length - 1 ? matches[i + 1].index : content.length;
  
  sections.push({
    num: sectionNum,
    title: sectionTitle,
    filename: `${sectionNum.padStart(2, '0')}_${sectionTitle.replace(/[^a-zA-Z0-9]/g, '_')}.md`,
    content: content.substring(sectionStart, sectionEnd)
  });
}

// Handle the introduction (content before the first section)
if (matches.length > 0) {
  const introEnd = matches[0].index;
  const introContent = content.substring(0, introEnd);
  
  sections.unshift({
    num: '0',
    title: 'Introduction',
    filename: '00_Introduction.md',
    content: introContent
  });
}

// Write each section to a separate file
let indexContent = '# TuneMantra Documentation Sections\n\n';
indexContent += 'This directory contains the TuneMantra comprehensive documentation split into manageable sections.\n\n';
indexContent += '## Sections\n\n';

sections.forEach(section => {
  const outputPath = path.join(OUTPUT_DIR, section.filename);
  fs.writeFileSync(outputPath, section.content);
  console.log(`Written section ${section.num}: ${section.title} to ${outputPath}`);
  
  // Add to index
  indexContent += `- [${section.num ? `${section.num}. ` : ''}${section.title}](./${section.filename})\n`;
});

// Write the index file
fs.writeFileSync(INDEX_FILE, indexContent);
console.log(`Written index to ${INDEX_FILE}`);

console.log('Documentation split complete!');