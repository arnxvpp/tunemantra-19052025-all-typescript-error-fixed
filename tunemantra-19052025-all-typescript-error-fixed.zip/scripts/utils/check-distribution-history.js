import fetch from 'node-fetch';

async function login() {
  const response = await fetch('http://localhost:5000/api/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'lunar_echo', password: 'testPassword123' })
  });
  
  const cookie = response.headers.get('set-cookie');
  return cookie;
}

async function getDistributionHistory(cookie, recordId) {
  const response = await fetch(`http://localhost:5000/api/distribution-status/history/${recordId}`, {
    headers: { Cookie: cookie }
  });
  
  const data = await response.json();
  return data;
}

async function main() {
  try {
    const cookie = await login();
    console.log('Authentication successful');
    
    // Get history for distribution record #8
    const history = await getDistributionHistory(cookie, 8);
    console.log(JSON.stringify(history, null, 2));
    
  } catch (error) {
    console.error('Error:', error.message);
  }
}

main();