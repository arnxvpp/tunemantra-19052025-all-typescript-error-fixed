/**
 * Royalty Calculation Simulation Test Script
 * 
 * This script simulates the royalty calculation functionality without requiring actual database access.
 * It tests the core logic of calculating royalties based on territorial splits, streamings, and rights ownership.
 * 
 * Usage: npx tsx scripts/royalty-calculation-simulator.ts
 */

// Types representing the royalty data structures
interface RightsRecord {
  id: number;
  assetId: string;
  userId: number;
  rightsType: string;
  territory: string[];
  percentage: number;
  startDate: Date;
  endDate: Date | null;
  status: 'active' | 'pending' | 'expired' | 'transferred' | 'disputed';
  verificationStatus: 'verified' | 'unverified' | 'blockchain_verified';
  createdAt: Date;
  updatedAt: Date;
}

interface StreamingPlatform {
  id: string;
  name: string;
  ratePerStream: number; // in USD
  distributionFee: number; // percentage
}

interface RevenueEvent {
  id: string;
  assetId: string;
  platformId: string;
  territory: string;
  streams: number;
  revenue: number;
  date: Date;
}

interface RoyaltyCalculation {
  eventId: string;
  assetId: string;
  userId: number;
  amount: number;
  percentage: number;
  rightsType: string;
  territory: string;
  platformId: string;
  status: 'pending' | 'paid';
  calculatedAt: Date;
}

/**
 * Royalty Calculation Simulation class
 */
class RoyaltyCalculatorSimulator {
  private rights: RightsRecord[] = [];
  private platforms: Record<string, StreamingPlatform> = {};
  private revenueEvents: RevenueEvent[] = [];
  private royaltyCalculations: RoyaltyCalculation[] = [];
  
  constructor() {
    console.log('Royalty calculator simulator initialized');
    
    // Initialize streaming platforms
    this.platforms = {
      spotify: {
        id: 'spotify',
        name: 'Spotify',
        ratePerStream: 0.0033,
        distributionFee: 15
      },
      apple: {
        id: 'apple',
        name: 'Apple Music',
        ratePerStream: 0.0056,
        distributionFee: 15
      },
      youtube: {
        id: 'youtube',
        name: 'YouTube Music',
        ratePerStream: 0.0018,
        distributionFee: 15
      }
    };
  }
  
  /**
   * Initialize with test data
   */
  initializeTestData(): void {
    const now = new Date();
    const startDate = new Date('2024-01-01');
    const endDate = new Date('2029-12-31');
    
    // Add test rights
    this.rights = [
      {
        id: 1,
        assetId: 'track-123',
        userId: 101,
        rightsType: 'master',
        territory: ['GLOBAL'],
        percentage: 100,
        startDate,
        endDate,
        status: 'active',
        verificationStatus: 'verified',
        createdAt: now,
        updatedAt: now
      },
      {
        id: 2,
        assetId: 'track-456',
        userId: 102,
        rightsType: 'master',
        territory: ['US', 'CA'],
        percentage: 80,
        startDate,
        endDate,
        status: 'active',
        verificationStatus: 'verified',
        createdAt: now,
        updatedAt: now
      },
      {
        id: 3,
        assetId: 'track-456',
        userId: 103,
        rightsType: 'master',
        territory: ['US', 'CA'],
        percentage: 20,
        startDate,
        endDate,
        status: 'active',
        verificationStatus: 'unverified',
        createdAt: now,
        updatedAt: now
      },
      {
        id: 4,
        assetId: 'track-456',
        userId: 102,
        rightsType: 'master',
        territory: ['EU'],
        percentage: 100,
        startDate,
        endDate,
        status: 'active',
        verificationStatus: 'verified',
        createdAt: now,
        updatedAt: now
      },
      {
        id: 5,
        assetId: 'track-789',
        userId: 101,
        rightsType: 'master',
        territory: ['US'],
        percentage: 50,
        startDate,
        endDate: null,
        status: 'active',
        verificationStatus: 'blockchain_verified',
        createdAt: now,
        updatedAt: now
      },
      {
        id: 6,
        assetId: 'track-789',
        userId: 102,
        rightsType: 'master',
        territory: ['US'],
        percentage: 50,
        startDate,
        endDate: null,
        status: 'active',
        verificationStatus: 'blockchain_verified',
        createdAt: now,
        updatedAt: now
      }
    ];
    
    // Add test revenue events
    this.revenueEvents = [
      {
        id: 'event-1',
        assetId: 'track-123',
        platformId: 'spotify',
        territory: 'US',
        streams: 10000,
        revenue: 33.00,
        date: new Date('2025-01-15')
      },
      {
        id: 'event-2',
        assetId: 'track-456',
        platformId: 'apple',
        territory: 'US',
        streams: 5000,
        revenue: 28.00,
        date: new Date('2025-01-20')
      },
      {
        id: 'event-3',
        assetId: 'track-456',
        platformId: 'youtube',
        territory: 'EU',
        streams: 20000,
        revenue: 36.00,
        date: new Date('2025-01-25')
      },
      {
        id: 'event-4',
        assetId: 'track-789',
        platformId: 'spotify',
        territory: 'US',
        streams: 15000,
        revenue: 49.50,
        date: new Date('2025-02-01')
      }
    ];
    
    console.log(`Initialized test data with ${this.rights.length} rights records and ${this.revenueEvents.length} revenue events`);
  }
  
  /**
   * Calculate royalties for a single revenue event
   */
  async calculateRoyalties(eventId: string): Promise<RoyaltyCalculation[]> {
    console.log(`Calculating royalties for event ${eventId}`);
    
    // Find the revenue event
    const event = this.revenueEvents.find(e => e.id === eventId);
    if (!event) {
      throw new Error(`Revenue event ${eventId} not found`);
    }
    
    const platform = this.platforms[event.platformId];
    if (!platform) {
      throw new Error(`Platform ${event.platformId} not found`);
    }
    
    // Find applicable rights for this asset and territory
    const applicableRights = this.rights.filter(r => {
      return (
        r.assetId === event.assetId &&
        r.status === 'active' &&
        (r.territory.includes('GLOBAL') || r.territory.includes(event.territory))
      );
    });
    
    if (applicableRights.length === 0) {
      console.log(`No applicable rights found for asset ${event.assetId} in territory ${event.territory}`);
      return [];
    }
    
    // Calculate platform fee
    const platformFee = event.revenue * (platform.distributionFee / 100);
    const netRevenue = event.revenue - platformFee;
    
    console.log(`Revenue: $${event.revenue.toFixed(2)}, Platform fee: $${platformFee.toFixed(2)}, Net: $${netRevenue.toFixed(2)}`);
    
    // Calculate royalties for each rights holder
    const calculations: RoyaltyCalculation[] = [];
    
    for (const rights of applicableRights) {
      // Calculate this user's share based on percentage
      const royaltyAmount = netRevenue * (rights.percentage / 100);
      
      // Create royalty calculation record
      const calculation: RoyaltyCalculation = {
        eventId,
        assetId: event.assetId,
        userId: rights.userId,
        amount: royaltyAmount,
        percentage: rights.percentage,
        rightsType: rights.rightsType,
        territory: event.territory,
        platformId: event.platformId,
        status: 'pending',
        calculatedAt: new Date()
      };
      
      calculations.push(calculation);
      this.royaltyCalculations.push(calculation);
      
      console.log(`User ${rights.userId} earned $${royaltyAmount.toFixed(2)} (${rights.percentage}% of net revenue)`);
    }
    
    return calculations;
  }
  
  /**
   * Calculate royalties for all revenue events
   */
  async calculateAllRoyalties(): Promise<{
    totalRevenue: number;
    totalRoyalties: number;
    calculations: RoyaltyCalculation[];
  }> {
    let totalRevenue = 0;
    let totalRoyalties = 0;
    const allCalculations: RoyaltyCalculation[] = [];
    
    // Process each revenue event
    for (const event of this.revenueEvents) {
      const calculations = await this.calculateRoyalties(event.id);
      allCalculations.push(...calculations);
      
      totalRevenue += event.revenue;
      totalRoyalties += calculations.reduce((sum, calc) => sum + calc.amount, 0);
    }
    
    return {
      totalRevenue,
      totalRoyalties,
      calculations: allCalculations
    };
  }
  
  /**
   * Get royalties earned by a specific user
   */
  async getUserRoyalties(userId: number): Promise<{
    total: number;
    byPlatform: Record<string, number>;
    byTerritory: Record<string, number>;
    royalties: RoyaltyCalculation[];
  }> {
    // Filter royalties for this user
    const userRoyalties = this.royaltyCalculations.filter(r => r.userId === userId);
    
    // Calculate totals
    const total = userRoyalties.reduce((sum, r) => sum + r.amount, 0);
    
    // Group by platform
    const byPlatform: Record<string, number> = {};
    for (const royalty of userRoyalties) {
      byPlatform[royalty.platformId] = (byPlatform[royalty.platformId] || 0) + royalty.amount;
    }
    
    // Group by territory
    const byTerritory: Record<string, number> = {};
    for (const royalty of userRoyalties) {
      byTerritory[royalty.territory] = (byTerritory[royalty.territory] || 0) + royalty.amount;
    }
    
    return {
      total,
      byPlatform,
      byTerritory,
      royalties: userRoyalties
    };
  }
  
  /**
   * Get revenue statistics for an asset
   */
  async getAssetRevenue(assetId: string): Promise<{
    totalStreams: number;
    totalRevenue: number;
    byPlatform: Record<string, { streams: number; revenue: number }>;
    byTerritory: Record<string, { streams: number; revenue: number }>;
  }> {
    // Filter events for this asset
    const assetEvents = this.revenueEvents.filter(e => e.assetId === assetId);
    
    // Calculate totals
    const totalStreams = assetEvents.reduce((sum, e) => sum + e.streams, 0);
    const totalRevenue = assetEvents.reduce((sum, e) => sum + e.revenue, 0);
    
    // Group by platform
    const byPlatform: Record<string, { streams: number; revenue: number }> = {};
    for (const event of assetEvents) {
      if (!byPlatform[event.platformId]) {
        byPlatform[event.platformId] = { streams: 0, revenue: 0 };
      }
      byPlatform[event.platformId].streams += event.streams;
      byPlatform[event.platformId].revenue += event.revenue;
    }
    
    // Group by territory
    const byTerritory: Record<string, { streams: number; revenue: number }> = {};
    for (const event of assetEvents) {
      if (!byTerritory[event.territory]) {
        byTerritory[event.territory] = { streams: 0, revenue: 0 };
      }
      byTerritory[event.territory].streams += event.streams;
      byTerritory[event.territory].revenue += event.revenue;
    }
    
    return {
      totalStreams,
      totalRevenue,
      byPlatform,
      byTerritory
    };
  }
}

/**
 * Main test function to simulate royalty calculations
 */
async function simulateRoyaltyCalculations(): Promise<void> {
  console.log('Starting royalty calculation simulation tests...');
  
  const simulator = new RoyaltyCalculatorSimulator();
  simulator.initializeTestData();
  
  // Test 1: Calculate all royalties
  console.log('\n--- Testing Full Royalty Calculation ---');
  const allResult = await simulator.calculateAllRoyalties();
  console.log(`Total revenue: $${allResult.totalRevenue.toFixed(2)}`);
  console.log(`Total royalties distributed: $${allResult.totalRoyalties.toFixed(2)}`);
  console.log(`Platform fees: $${(allResult.totalRevenue - allResult.totalRoyalties).toFixed(2)}`);
  console.log(`Number of royalty calculations: ${allResult.calculations.length}`);
  
  // Test 2: Get user royalties
  console.log('\n--- Testing User Royalty Retrieval ---');
  const user102Royalties = await simulator.getUserRoyalties(102);
  console.log(`User 102 earned a total of $${user102Royalties.total.toFixed(2)}`);
  
  console.log('Breakdown by platform:');
  for (const [platform, amount] of Object.entries(user102Royalties.byPlatform)) {
    console.log(`- ${platform}: $${amount.toFixed(2)}`);
  }
  
  console.log('Breakdown by territory:');
  for (const [territory, amount] of Object.entries(user102Royalties.byTerritory)) {
    console.log(`- ${territory}: $${amount.toFixed(2)}`);
  }
  
  // Test 3: Get asset revenue statistics
  console.log('\n--- Testing Asset Revenue Statistics ---');
  const track456Stats = await simulator.getAssetRevenue('track-456');
  console.log(`Track 456 statistics:`);
  console.log(`- Total streams: ${track456Stats.totalStreams}`);
  console.log(`- Total revenue: $${track456Stats.totalRevenue.toFixed(2)}`);
  
  console.log('Breakdown by platform:');
  for (const [platform, data] of Object.entries(track456Stats.byPlatform)) {
    console.log(`- ${platform}: ${data.streams} streams, $${data.revenue.toFixed(2)}`);
  }
  
  console.log('Breakdown by territory:');
  for (const [territory, data] of Object.entries(track456Stats.byTerritory)) {
    console.log(`- ${territory}: ${data.streams} streams, $${data.revenue.toFixed(2)}`);
  }
  
  console.log('\nAll simulation tests completed successfully.');
}

// Run simulation
simulateRoyaltyCalculations();