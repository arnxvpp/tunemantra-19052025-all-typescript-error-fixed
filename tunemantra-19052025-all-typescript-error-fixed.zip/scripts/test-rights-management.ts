/**
 * Rights Management Test Suite
 * 
 * This script tests the rights management functionality of the TuneMantra platform,
 * focusing on database operations and service methods.
 * 
 * USAGE: npx tsx scripts/test-rights-management.ts
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import colors from 'colors';

// Configure colors for terminal output
colors.enable();

// Setup environment for testing
process.env.NODE_ENV = 'development';

// Get current file and directory path
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');
const devEnvPath = path.join(rootDir, '.env.development');

// Check and load environment variables
console.log(`\n${'='.repeat(80)}`.cyan);
console.log(`RIGHTS MANAGEMENT TEST SUITE - TuneMantra Platform`.cyan.bold);
console.log(`${'='.repeat(80)}\n`.cyan);

console.log(`🔍 Looking for environment file at: ${devEnvPath}`);
if (fs.existsSync(devEnvPath)) {
  console.log(`✅ Environment file found`.green);
  dotenv.config({ path: devEnvPath });
} else {
  console.log(`⚠️  Environment file not found, using default values`.yellow);
}

// Import required modules
import { db } from '../server/db';
import { createRightsRecord, updateRightsVerificationStatus, getRightsRecordById, getRightsRecordsByAssetId } from '../server/services/db-helpers';
import { assetTypeEnum, rightsTypeEnum, ownerTypeEnum, blockchainNetworkEnum } from '../shared/schema';
import { eq } from 'drizzle-orm';

// Test data
const TEST_DATA = {
  assetId: `TRACK_${Date.now()}`,
  assetType: 'track',
  ownerAddress: '0x1234567890123456789012345678901234567890',
  verifierAddress: '0x9876543210987654321098765432109876543210',
  rightsType: 'master',
  ownerType: 'artist',
  percentage: 75,
  startDate: new Date(),
  endDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000), // 1 year from now
  territories: ['global', 'US', 'EU', 'JP'],
  blockchainNetworkId: 'mumbai',
};

// Helper for test output formatting
function logSection(title: string) {
  console.log(`\n${'='.repeat(80)}`.cyan);
  console.log(`${title}`.cyan.bold);
  console.log(`${'-'.repeat(80)}`.cyan);
}

function logSubSection(title: string) {
  console.log(`\n${'-'.repeat(40)}`.yellow);
  console.log(`${title}`.yellow);
  console.log(`${'-'.repeat(40)}`.yellow);
}

// Test functions
async function testDatabaseSchema() {
  logSection('DATABASE SCHEMA TEST');
  
  try {
    // Check rights_records table
    const tableInfo = await db.execute(
      `SELECT column_name, data_type, is_nullable 
       FROM information_schema.columns 
       WHERE table_name = 'rights_records' 
       ORDER BY ordinal_position`
    );
    
    if (tableInfo.rows && tableInfo.rows.length > 0) {
      console.log(`✅ rights_records table exists with ${tableInfo.rows.length} columns`.green);
      console.table(tableInfo.rows);
      
      // Check for essential columns
      const columns = tableInfo.rows.map((row: any) => row.column_name);
      const requiredColumns = [
        'id', 'asset_id', 'asset_type', 'rights_type', 'owner_type', 
        'owner_id', 'owner_address', 'percentage', 'start_date', 'end_date',
        'verification_status', 'blockchain_network_id'
      ];
      
      const missingColumns = requiredColumns.filter(col => !columns.includes(col));
      
      if (missingColumns.length > 0) {
        console.error(`❌ Missing required columns in rights_records table:`.red, missingColumns);
        return false;
      }
      
      console.log(`✅ All required columns are present`.green);
    } else {
      console.error(`❌ Could not retrieve rights_records table structure`.red);
      return false;
    }
    
    // Check blockchain_transactions table
    const txTableInfo = await db.execute(
      `SELECT column_name, data_type, is_nullable 
       FROM information_schema.columns 
       WHERE table_name = 'blockchain_transactions' 
       ORDER BY ordinal_position`
    );
    
    if (txTableInfo.rows && txTableInfo.rows.length > 0) {
      console.log(`\n✅ blockchain_transactions table exists with ${txTableInfo.rows.length} columns`.green);
      console.table(txTableInfo.rows);
    } else {
      console.error(`❌ Could not retrieve blockchain_transactions table structure`.red);
      return false;
    }
    
    // Check territories table
    const territoriesTableInfo = await db.execute(
      `SELECT column_name, data_type, is_nullable 
       FROM information_schema.columns 
       WHERE table_name = 'territories' 
       ORDER BY ordinal_position`
    );
    
    if (territoriesTableInfo.rows && territoriesTableInfo.rows.length > 0) {
      console.log(`\n✅ territories table exists with ${territoriesTableInfo.rows.length} columns`.green);
      console.table(territoriesTableInfo.rows);
    } else {
      console.error(`⚠️ territories table structure not found - this may be okay if territories are stored differently`.yellow);
    }
    
    // Check enum values
    logSubSection('Enum Values');
    console.log("- Asset Types:", Object.values(assetTypeEnum.enumValues));
    console.log("- Rights Types:", Object.values(rightsTypeEnum.enumValues));
    console.log("- Owner Types:", Object.values(ownerTypeEnum.enumValues));
    console.log("- Blockchain Networks:", Object.values(blockchainNetworkEnum.enumValues));
    
    return true;
  } catch (error) {
    console.error(`❌ Database schema test failed:`.red, error);
    return false;
  }
}

async function testRightsRecordCreation() {
  logSection('RIGHTS RECORD CREATION TEST');
  
  try {
    console.log('Creating test rights record...');
    console.log('Test data:', TEST_DATA);
    
    const result = await createRightsRecord({
      assetId: TEST_DATA.assetId,
      assetType: TEST_DATA.assetType,
      rightsType: TEST_DATA.rightsType,
      ownerType: TEST_DATA.ownerType,
      ownerId: 1,
      ownerAddress: TEST_DATA.ownerAddress,
      percentage: TEST_DATA.percentage,
      startDate: TEST_DATA.startDate,
      endDate: TEST_DATA.endDate,
      territories: TEST_DATA.territories,
      blockchainNetworkId: TEST_DATA.blockchainNetworkId,
      verificationStatus: 'pending'
    });
    
    console.log(`✅ Rights record created with ID: ${result.id}`.green);
    console.log('Record details:', result);
    
    return result;
  } catch (error) {
    console.error(`❌ Rights record creation test failed:`.red, error);
    if (error instanceof Error) {
      console.error(`   Message: ${error.message}`);
      console.error(`   Stack: ${error.stack}`);
    } else {
      console.error(error);
    }
    return null;
  }
}

async function testRightsRecordRetrieval(id: number) {
  logSection('RIGHTS RECORD RETRIEVAL TEST');
  
  try {
    console.log(`Retrieving rights record with ID: ${id}...`);
    const record = await getRightsRecordById(id);
    
    if (!record) {
      console.error(`❌ Failed to retrieve rights record with ID: ${id}`.red);
      return false;
    }
    
    console.log(`✅ Rights record retrieved successfully`.green);
    console.log('Record details:', record);
    
    // Test retrieval by asset ID
    console.log(`\nRetrieving rights records by asset ID: ${record.assetId}...`);
    const records = await getRightsRecordsByAssetId(record.assetId);
    
    if (!records || records.length === 0) {
      console.error(`❌ Failed to retrieve rights records by asset ID: ${record.assetId}`.red);
      return false;
    }
    
    console.log(`✅ Retrieved ${records.length} rights records for asset ID: ${record.assetId}`.green);
    
    return true;
  } catch (error) {
    console.error(`❌ Rights record retrieval test failed:`.red, error);
    return false;
  }
}

async function testRightsVerificationUpdate(id: number) {
  logSection('RIGHTS VERIFICATION UPDATE TEST');
  
  try {
    console.log(`Updating verification status for rights record with ID: ${id}...`);
    
    const transactionHash = '0x' + Array(64).fill(0).map(() => Math.floor(Math.random() * 16).toString(16)).join('');
    const updateResult = await updateRightsVerificationStatus(
      id,
      'verified',
      1, // verifierId
      new Date(),
      transactionHash
    );
    
    if (!updateResult) {
      console.error(`❌ Failed to update verification status for rights record with ID: ${id}`.red);
      return false;
    }
    
    console.log(`✅ Verification status updated successfully`.green);
    
    // Verify the update
    const updatedRecord = await getRightsRecordById(id);
    
    if (!updatedRecord || updatedRecord.verificationStatus !== 'verified') {
      console.error(`❌ Verification status update did not persist correctly`.red);
      console.log('Updated record:', updatedRecord);
      return false;
    }
    
    console.log(`✅ Verification status persisted correctly: ${updatedRecord.verificationStatus}`.green);
    console.log('Updated record:', updatedRecord);
    
    return true;
  } catch (error) {
    console.error(`❌ Rights verification update test failed:`.red, error);
    return false;
  }
}

async function testRightsRecordTransactions(id: number) {
  logSection('RIGHTS RECORD TRANSACTIONS TEST');
  
  try {
    // This test assumes that createRightsRecord also creates a transaction record
    // If that's not the case in your implementation, you should add direct transaction creation code here
    
    console.log(`Checking transactions for rights record with ID: ${id}...`);
    
    const transactions = await db.execute(
      `SELECT * FROM blockchain_transactions 
       WHERE record_id = $1 AND record_type = 'rights'`,
      [id]
    );
    
    if (!transactions.rows || transactions.rows.length === 0) {
      console.log(`⚠️  No transaction records found for rights record with ID: ${id}`.yellow);
      console.log(`This may be normal if transaction records are created elsewhere`.yellow);
      return true;
    }
    
    console.log(`✅ Found ${transactions.rows.length} transaction records`.green);
    console.table(transactions.rows);
    
    return true;
  } catch (error) {
    console.error(`❌ Rights record transactions test failed:`.red, error);
    return false;
  }
}

// Main test runner
async function runTests() {
  try {
    // Test database schema
    const schemaValid = await testDatabaseSchema();
    if (!schemaValid) {
      throw new Error('Database schema test failed');
    }
    
    // Test rights record creation
    const rightsRecord = await testRightsRecordCreation();
    if (!rightsRecord) {
      throw new Error('Rights record creation test failed');
    }
    
    const recordId = rightsRecord.id;
    
    // Test rights record retrieval
    const retrievalSuccess = await testRightsRecordRetrieval(recordId);
    if (!retrievalSuccess) {
      throw new Error('Rights record retrieval test failed');
    }
    
    // Test rights verification update
    const updateSuccess = await testRightsVerificationUpdate(recordId);
    if (!updateSuccess) {
      throw new Error('Rights verification update test failed');
    }
    
    // Test rights record transactions
    await testRightsRecordTransactions(recordId);
    
    // All tests passed
    logSection('TEST RESULTS');
    console.log(`✅ All rights management tests completed successfully!\n`.green.bold);
    
    return true;
  } catch (error) {
    logSection('TEST RESULTS');
    console.error(`❌ Rights management tests failed:`.red.bold, error);
    return false;
  }
}

// Run the tests
runTests()
  .then((success) => {
    if (!success) {
      process.exit(1);
    }
  })
  .catch((error) => {
    console.error(`Unhandled error in test suite:`.red.bold, error);
    process.exit(1);
  });