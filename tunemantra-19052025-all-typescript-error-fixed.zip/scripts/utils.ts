/**
 * Utility functions for TuneMantra testing framework
 */

import * as crypto from 'crypto';

/**
 * Generate a random string of specified length
 * @param length Length of the random string to generate
 * @returns Random string
 */
export function generateRandomString(length: number = 10): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  
  return result;
}

/**
 * Generate a random Ethereum address
 * @returns Random Ethereum address
 */
export function generateRandomEthereumAddress(): string {
  return '0x' + crypto.randomBytes(20).toString('hex');
}

/**
 * Generate a random transaction hash
 * @returns Random transaction hash
 */
export function generateRandomTransactionHash(): string {
  return '0x' + crypto.randomBytes(32).toString('hex');
}

/**
 * Generate a random NFT token ID
 * @returns Random token ID
 */
export function generateRandomTokenId(): string {
  return Math.floor(Math.random() * 1000000).toString();
}

/**
 * Sleep for specified milliseconds
 * @param ms Milliseconds to sleep
 * @returns Promise that resolves after the specified time
 */
export function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Format duration in milliseconds to a human-readable string
 * @param ms Duration in milliseconds
 * @returns Formatted duration string
 */
export function formatDuration(ms: number): string {
  if (ms < 1000) {
    return `${ms}ms`;
  }
  
  const seconds = ms / 1000;
  if (seconds < 60) {
    return `${seconds.toFixed(2)}s`;
  }
  
  const minutes = seconds / 60;
  if (minutes < 60) {
    const remainingSeconds = seconds % 60;
    return `${Math.floor(minutes)}m ${remainingSeconds.toFixed(0)}s`;
  }
  
  const hours = minutes / 60;
  const remainingMinutes = minutes % 60;
  return `${Math.floor(hours)}h ${Math.floor(remainingMinutes)}m`;
}

/**
 * Generate a valid mock blockchain signature
 * @param message Message to sign
 * @param privateKey Private key to use for signing (optional)
 * @returns Mock signature
 */
export function generateMockSignature(message: string, privateKey?: string): string {
  // In a real implementation, this would use ethers.js to sign the message
  // For testing purposes, we just return a mock signature
  return 'mock_signature_' + crypto.createHash('sha256').update(message).digest('hex').substring(0, 10);
}

/**
 * Parse boolean environment variable
 * @param value Environment variable value
 * @param defaultValue Default value if environment variable is not set
 * @returns Parsed boolean value
 */
export function parseEnvBoolean(value: string | undefined, defaultValue: boolean = false): boolean {
  if (value === undefined) {
    return defaultValue;
  }
  
  value = value.toLowerCase().trim();
  return value === 'true' || value === '1' || value === 'yes';
}

/**
 * Get current timestamp in ISO format
 * @returns Current timestamp in ISO format
 */
export function getCurrentTimestamp(): string {
  return new Date().toISOString();
}

/**
 * Generate a mock JSON Web Token (JWT)
 * @param userId User ID to include in the token
 * @param expiresIn Expiration time in seconds (default: 1 hour)
 * @returns Mock JWT
 */
export function generateMockJWT(userId: string | number, expiresIn: number = 3600): string {
  const header = {
    alg: 'HS256',
    typ: 'JWT'
  };
  
  const payload = {
    sub: String(userId),
    iat: Math.floor(Date.now() / 1000),
    exp: Math.floor(Date.now() / 1000) + expiresIn
  };
  
  const encodedHeader = Buffer.from(JSON.stringify(header)).toString('base64').replace(/=/g, '');
  const encodedPayload = Buffer.from(JSON.stringify(payload)).toString('base64').replace(/=/g, '');
  
  // In a real implementation, the signature would be calculated using a secret key
  // For testing purposes, we just use a mock signature
  const mockSignature = 'mock_jwt_signature';
  
  return `${encodedHeader}.${encodedPayload}.${mockSignature}`;
}

/**
 * Check if the current environment is a CI environment
 * @returns True if running in a CI environment
 */
export function isCI(): boolean {
  return parseEnvBoolean(process.env.CI) || Boolean(process.env.GITHUB_ACTIONS);
}

/**
 * Safely parse JSON with error handling
 * @param json JSON string to parse
 * @returns Parsed object or null if parsing failed
 */
export function safeJsonParse(json: string): any {
  try {
    return JSON.parse(json);
  } catch (error) {
    console.error('Error parsing JSON:', error);
    return null;
  }
}