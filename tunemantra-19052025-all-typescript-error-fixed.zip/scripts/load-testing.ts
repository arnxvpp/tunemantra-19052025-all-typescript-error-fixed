/**
 * Load Testing for TuneMantra Rights Management Platform
 * 
 * This script stress tests the platform under various load conditions:
 * - Concurrent rights registrations
 * - High-volume blockchain verifications
 * - Sustained API request patterns
 * - Database query performance under load
 * 
 * Usage: npx tsx scripts/load-testing.ts [--concurrency=100] [--duration=60]
 */

import { performance } from 'perf_hooks';
import { 
  runTestSuite, 
  assertEqual, 
  assertLessThan,
  runConcurrentRequests,
  TestReporter
} from './test-framework';

// Parse command-line arguments
const args = process.argv.slice(2);
const concurrencyArg = args.find(arg => arg.startsWith('--concurrency='));
const durationArg = args.find(arg => arg.startsWith('--duration='));

// Default values
const DEFAULT_CONCURRENCY = 50;
const DEFAULT_DURATION_SECONDS = 30;

// Extract values from arguments
const concurrency = concurrencyArg 
  ? parseInt(concurrencyArg.split('=')[1], 10) 
  : DEFAULT_CONCURRENCY;

const durationSeconds = durationArg
  ? parseInt(durationArg.split('=')[1], 10)
  : DEFAULT_DURATION_SECONDS;

// Configuration constants
const API_BASE_URL = process.env.API_BASE_URL || 'http://localhost:5000';
const TARGET_RPS = 50; // Target requests per second
const MAX_RESPONSE_TIME_MS = 2000; // Maximum acceptable response time (2 seconds)

// Mock fetch for testing
global.fetch = async (url: string, options: any = {}) => {
  // Add some artificial delay to simulate server processing
  const processingTime = Math.random() * 100 + 50; // 50-150ms
  await new Promise(resolve => setTimeout(resolve, processingTime));
  
  // Extract endpoint from URL
  const endpoint = url.split('?')[0];
  const method = options.method || 'GET';
  
  // Default success response
  return {
    ok: true,
    status: 200,
    statusText: 'OK',
    json: async () => ({ success: true, message: 'Mock response' }),
    text: async () => JSON.stringify({ success: true, message: 'Mock response' })
  } as Response;
};

/**
 * Test sustained load on the rights registration endpoint
 */
async function testRightsRegistrationLoad(): Promise<void> {
  const reporter = new TestReporter('load-test-results');
  reporter.startSuite('Rights Registration Load Test');
  
  console.log(`Starting rights registration load test with ${concurrency} concurrent users for ${durationSeconds} seconds`);
  
  const startTime = performance.now();
  const endTime = startTime + (durationSeconds * 1000);
  
  let totalRequests = 0;
  let successfulRequests = 0;
  let failedRequests = 0;
  const responseTimes: number[] = [];
  
  // Define test data for rights registration
  const requestBody = JSON.stringify({
    assetId: '12345',
    assetType: 'track',
    rightsType: 'master',
    ownerType: 'artist',
    percentage: 100,
    startDate: new Date().toISOString()
  });
  
  const requestOptions = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: requestBody
  };

  // Run the load test for the specified duration
  while (performance.now() < endTime) {
    const batchSize = Math.min(concurrency, 
      TARGET_RPS - Math.floor(totalRequests / ((performance.now() - startTime) / 1000)));
    
    if (batchSize <= 0) {
      // We're ahead of our target RPS, wait a bit
      await new Promise(resolve => setTimeout(resolve, 100));
      continue;
    }
    
    // Make the requests in parallel
    const batchStart = performance.now();
    const results = await runConcurrentRequests(
      '/api/rights-management/register',
      requestOptions,
      batchSize
    );
    
    totalRequests += batchSize;
    successfulRequests += results.successCount;
    failedRequests += results.failureCount;
    
    // Record metrics
    responseTimes.push(results.averageTime);
    
    // Throttle to maintain target RPS
    const batchDuration = performance.now() - batchStart;
    const targetBatchTime = (1000 * batchSize) / TARGET_RPS;
    
    if (batchDuration < targetBatchTime) {
      await new Promise(resolve => setTimeout(resolve, targetBatchTime - batchDuration));
    }
  }
  
  // Calculate summary metrics
  const totalDuration = performance.now() - startTime;
  const actualRPS = totalRequests / (totalDuration / 1000);
  const averageResponseTime = responseTimes.reduce((sum, time) => sum + time, 0) / responseTimes.length;
  const maxResponseTime = Math.max(...responseTimes);
  
  // Log test results
  reporter.recordTest({
    name: 'Sustained load on rights registration',
    passed: failedRequests === 0 && averageResponseTime < MAX_RESPONSE_TIME_MS,
    duration: totalDuration,
    details: {
      totalRequests,
      successfulRequests,
      failedRequests,
      targetRPS: TARGET_RPS,
      actualRPS,
      averageResponseTime,
      maxResponseTime,
      successRate: (successfulRequests / totalRequests) * 100
    }
  });
  
  reporter.endSuite();
  reporter.logSummary();
  
  console.log('\nRights Registration Load Test Results:');
  console.log(`- Total Requests: ${totalRequests}`);
  console.log(`- Successful Requests: ${successfulRequests}`);
  console.log(`- Failed Requests: ${failedRequests}`);
  console.log(`- Average Response Time: ${averageResponseTime.toFixed(2)}ms`);
  console.log(`- Max Response Time: ${maxResponseTime.toFixed(2)}ms`);
  console.log(`- Actual Requests Per Second: ${actualRPS.toFixed(2)}`);
  console.log(`- Success Rate: ${((successfulRequests / totalRequests) * 100).toFixed(2)}%`);
}

/**
 * Test blockchain verification under load
 */
async function testBlockchainVerificationLoad(): Promise<void> {
  const reporter = new TestReporter('load-test-results');
  reporter.startSuite('Blockchain Verification Load Test');
  
  console.log(`Starting blockchain verification load test with ${concurrency} concurrent users for ${durationSeconds} seconds`);
  
  const startTime = performance.now();
  const endTime = startTime + (durationSeconds * 1000);
  
  let totalRequests = 0;
  let successfulRequests = 0;
  let failedRequests = 0;
  const responseTimes: number[] = [];
  
  // Define test data for blockchain verification
  const requestBody = JSON.stringify({
    rightsId: 1,
    tokenId: '12345',
    signature: 'mock_signature',
    ownerAddress: '0x1234567890123456789012345678901234567890'
  });
  
  const requestOptions = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: requestBody
  };

  // Run the load test for the specified duration
  while (performance.now() < endTime) {
    const batchSize = Math.min(concurrency, 
      TARGET_RPS - Math.floor(totalRequests / ((performance.now() - startTime) / 1000)));
    
    if (batchSize <= 0) {
      // We're ahead of our target RPS, wait a bit
      await new Promise(resolve => setTimeout(resolve, 100));
      continue;
    }
    
    // Make the requests in parallel
    const batchStart = performance.now();
    const results = await runConcurrentRequests(
      '/api/blockchain/verify-rights',
      requestOptions,
      batchSize
    );
    
    totalRequests += batchSize;
    successfulRequests += results.successCount;
    failedRequests += results.failureCount;
    
    // Record metrics
    responseTimes.push(results.averageTime);
    
    // Throttle to maintain target RPS
    const batchDuration = performance.now() - batchStart;
    const targetBatchTime = (1000 * batchSize) / TARGET_RPS;
    
    if (batchDuration < targetBatchTime) {
      await new Promise(resolve => setTimeout(resolve, targetBatchTime - batchDuration));
    }
  }
  
  // Calculate summary metrics
  const totalDuration = performance.now() - startTime;
  const actualRPS = totalRequests / (totalDuration / 1000);
  const averageResponseTime = responseTimes.reduce((sum, time) => sum + time, 0) / responseTimes.length;
  const maxResponseTime = Math.max(...responseTimes);
  
  // Log test results
  reporter.recordTest({
    name: 'Sustained load on blockchain verification',
    passed: failedRequests === 0 && averageResponseTime < MAX_RESPONSE_TIME_MS,
    duration: totalDuration,
    details: {
      totalRequests,
      successfulRequests,
      failedRequests,
      targetRPS: TARGET_RPS,
      actualRPS,
      averageResponseTime,
      maxResponseTime,
      successRate: (successfulRequests / totalRequests) * 100
    }
  });
  
  reporter.endSuite();
  reporter.logSummary();
  
  console.log('\nBlockchain Verification Load Test Results:');
  console.log(`- Total Requests: ${totalRequests}`);
  console.log(`- Successful Requests: ${successfulRequests}`);
  console.log(`- Failed Requests: ${failedRequests}`);
  console.log(`- Average Response Time: ${averageResponseTime.toFixed(2)}ms`);
  console.log(`- Max Response Time: ${maxResponseTime.toFixed(2)}ms`);
  console.log(`- Actual Requests Per Second: ${actualRPS.toFixed(2)}`);
  console.log(`- Success Rate: ${((successfulRequests / totalRequests) * 100).toFixed(2)}%`);
}

/**
 * Test API performance under various request patterns
 */
async function testMixedLoadPatterns(): Promise<void> {
  const tests = [
    {
      name: 'Spike Test - 3x normal load for 5 seconds',
      fn: async () => {
        console.log('Running spike test (3x normal load for 5 seconds)...');
        
        const spikeLoad = concurrency * 3;
        const spikeDuration = 5000; // 5 seconds
        
        const startTime = performance.now();
        
        // Generate a spike of traffic
        const results = await runConcurrentRequests(
          '/api/rights-management/register',
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              assetId: '12345',
              assetType: 'track',
              rightsType: 'master',
              ownerType: 'artist',
              percentage: 100,
              startDate: new Date().toISOString()
            })
          },
          spikeLoad
        );
        
        const duration = performance.now() - startTime;
        
        // We expect higher latency but still want all requests to succeed
        return {
          successCount: results.successCount,
          failureCount: results.failureCount,
          averageResponseTime: results.averageTime,
          maxResponseTime: results.maxTime,
          successRate: (results.successCount / spikeLoad) * 100,
          // For spike tests, we accept higher latency but expect full success rate
          passed: results.failureCount === 0
        };
      }
    },
    {
      name: 'Endurance Test - Sustained modest load for 90% of test duration',
      fn: async () => {
        console.log('Running endurance test (sustained modest load)...');
        
        const enduranceLoad = Math.floor(concurrency * 0.7); // 70% of max concurrency
        const enduranceDuration = Math.floor(durationSeconds * 0.9) * 1000; // 90% of test duration
        
        const startTime = performance.now();
        const endTime = startTime + enduranceDuration;
        
        let totalRequests = 0;
        let successfulRequests = 0;
        let failedRequests = 0;
        const responseTimes: number[] = [];
        
        // Maintain a steady flow of requests for the duration
        while (performance.now() < endTime) {
          const batch = Math.min(10, enduranceLoad);
          
          const results = await runConcurrentRequests(
            '/api/blockchain/verify-rights',
            {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                rightsId: 1,
                tokenId: '12345',
                signature: 'mock_signature',
                ownerAddress: '0x1234567890123456789012345678901234567890'
              })
            },
            batch
          );
          
          totalRequests += batch;
          successfulRequests += results.successCount;
          failedRequests += results.failureCount;
          responseTimes.push(results.averageTime);
          
          // Short delay between batches to maintain steady load
          await new Promise(resolve => setTimeout(resolve, 500));
        }
        
        const duration = performance.now() - startTime;
        const averageResponseTime = responseTimes.reduce((sum, time) => sum + time, 0) / responseTimes.length;
        const maxResponseTime = Math.max(...responseTimes);
        
        return {
          totalRequests,
          successfulRequests,
          failedRequests,
          averageResponseTime,
          maxResponseTime,
          successRate: (successfulRequests / totalRequests) * 100,
          // For endurance test, we want >99% success rate and acceptable latency
          passed: (successfulRequests / totalRequests > 0.99) && (averageResponseTime < MAX_RESPONSE_TIME_MS)
        };
      }
    },
    {
      name: 'Mixed Traffic Pattern - Alternating read/write operations',
      fn: async () => {
        console.log('Running mixed traffic pattern test...');
        
        const mixedLoad = Math.floor(concurrency * 0.5); // 50% of max concurrency
        const iterations = 5;
        
        let totalRequests = 0;
        let successfulRequests = 0;
        let failedRequests = 0;
        const responseTimes: number[] = [];
        
        for (let i = 0; i < iterations; i++) {
          // First do a batch of write operations (register rights)
          const writeResults = await runConcurrentRequests(
            '/api/rights-management/register',
            {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                assetId: `mixed-${i}-${Date.now()}`,
                assetType: 'track',
                rightsType: 'master',
                ownerType: 'artist',
                percentage: 100,
                startDate: new Date().toISOString()
              })
            },
            mixedLoad
          );
          
          totalRequests += mixedLoad;
          successfulRequests += writeResults.successCount;
          failedRequests += writeResults.failureCount;
          responseTimes.push(writeResults.averageTime);
          
          // Then do a batch of read operations (verify rights)
          const readResults = await runConcurrentRequests(
            '/api/blockchain/verify-rights',
            {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                rightsId: 1,
                tokenId: '12345',
                signature: 'mock_signature',
                ownerAddress: '0x1234567890123456789012345678901234567890'
              })
            },
            mixedLoad
          );
          
          totalRequests += mixedLoad;
          successfulRequests += readResults.successCount;
          failedRequests += readResults.failureCount;
          responseTimes.push(readResults.averageTime);
        }
        
        const averageResponseTime = responseTimes.reduce((sum, time) => sum + time, 0) / responseTimes.length;
        const maxResponseTime = Math.max(...responseTimes);
        
        return {
          totalRequests,
          successfulRequests,
          failedRequests,
          averageResponseTime,
          maxResponseTime,
          successRate: (successfulRequests / totalRequests) * 100,
          // For mixed pattern test, we want >99% success rate
          passed: (successfulRequests / totalRequests > 0.99)
        };
      }
    }
  ];
  
  await runTestSuite('Mixed Load Pattern Tests', tests);
}

// Run all load tests
async function runAllLoadTests(): Promise<void> {
  console.log(`Running load tests with concurrency=${concurrency}, duration=${durationSeconds}s`);
  
  try {
    // Run the sustained load tests
    await testRightsRegistrationLoad();
    await testBlockchainVerificationLoad();
    
    // Run the mixed pattern tests
    await testMixedLoadPatterns();
    
    console.log('\n✅ All load tests completed!');
  } catch (error) {
    console.error('\n❌ Load test execution failed:', error);
    process.exit(1);
  }
}

// Execute load tests
runAllLoadTests();