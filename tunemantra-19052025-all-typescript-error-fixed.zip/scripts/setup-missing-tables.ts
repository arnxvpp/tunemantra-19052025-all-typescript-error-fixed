/**
 * Setup Missing Tables Script
 * 
 * This script creates all missing tables needed for testing TuneMantra services:
 * - tracks, users (basic tables for references)
 * - blockchain_nfts
 * - user_wallets
 * - rights_records, rights_conflicts, rights_transfers
 * - Fixes the 'rights' table to work with tests
 * 
 * Usage: npx tsx scripts/setup-missing-tables.ts
 */

import { pool, executeQuery } from '../server/db';

/**
 * Main function to setup all missing tables
 */
async function setupMissingTables() {
  console.log('Starting setup of missing database tables...');
  
  try {
    // Insert test users if they don't exist
    await executeQuery(`
      INSERT INTO users (id, username, email, password, status, role)
      VALUES 
        (11, 'testuser1', 'test1@example.com', 'hash', 'active', 'artist'),
        (12, 'testuser2', 'test2@example.com', 'hash', 'active', 'label'),
        (13, 'testuser3', 'test3@example.com', 'hash', 'active', 'distributor')
      ON CONFLICT (id) DO NOTHING;
    `);
    console.log('✓ Test users added');
    
    // Add test tracks if they don't exist
    await executeQuery(`
      -- Insert test tracks if they don't exist
      INSERT INTO tracks (id, title, artist, genre, user_id, release_date, status)
      VALUES 
        (11, 'Test Track 1', 'Test Artist 1', 'Pop', 11, CURRENT_TIMESTAMP, 'active'),
        (12, 'Test Track 2', 'Test Artist 2', 'Rock', 12, CURRENT_TIMESTAMP, 'active'),
        (13, 'Test Track 3', 'Test Artist 3', 'Electronic', 13, CURRENT_TIMESTAMP, 'active')
      ON CONFLICT (id) DO NOTHING;
    `);
    console.log('✓ Test tracks added');
    
    // Create blockchain_nfts table
    await executeQuery(`
      CREATE TABLE IF NOT EXISTS blockchain_nfts (
        id SERIAL PRIMARY KEY,
        token_id TEXT NOT NULL UNIQUE,
        track_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        network_id TEXT NOT NULL,
        transaction_hash TEXT NOT NULL,
        metadata JSONB NOT NULL,
        status TEXT NOT NULL DEFAULT 'minted',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);
    console.log('✓ blockchain_nfts table created/verified');
    
    // Create user_wallets table
    await executeQuery(`
      CREATE TABLE IF NOT EXISTS user_wallets (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL,
        address TEXT NOT NULL,
        wallet_type TEXT NOT NULL,
        default_wallet BOOLEAN NOT NULL DEFAULT false,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
      
      -- Insert test wallets if they don't exist
      INSERT INTO user_wallets (user_id, address, wallet_type, default_wallet)
      VALUES 
        (11, '0x1234567890123456789012345678901234567890', 'ethereum', true),
        (12, '0x0987654321098765432109876543210987654321', 'ethereum', true),
        (13, '0xabcdefabcdefabcdefabcdefabcdefabcdefabcd', 'ethereum', true)
      ON CONFLICT DO NOTHING;
    `);
    console.log('✓ user_wallets table created/verified with test data');
    
    // Create rights table (for compatibility with tests)
    await executeQuery(`
      CREATE TABLE IF NOT EXISTS rights (
        id SERIAL PRIMARY KEY,
        asset_id TEXT NOT NULL,
        asset_type TEXT NOT NULL,
        rights_type TEXT NOT NULL,
        owner_id INTEGER NOT NULL,
        owner_type TEXT NOT NULL,
        percentage NUMERIC NOT NULL,
        territory TEXT DEFAULT 'worldwide',
        start_date TIMESTAMP NOT NULL,
        end_date TIMESTAMP,
        blockchain_reference TEXT,
        status TEXT NOT NULL DEFAULT 'active',
        source TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);
    console.log('✓ rights table created/verified');
    
    // Create rights_records table
    await executeQuery(`
      CREATE TABLE IF NOT EXISTS rights_records (
        id SERIAL PRIMARY KEY,
        asset_id VARCHAR(255) NOT NULL,
        asset_type VARCHAR(50) NOT NULL,
        rights_type VARCHAR(50) NOT NULL,
        owner_id INTEGER NOT NULL,
        owner_type VARCHAR(50) NOT NULL,
        percentage DECIMAL(5,2) NOT NULL,
        territory VARCHAR(255) DEFAULT 'worldwide',
        start_date TIMESTAMP NOT NULL,
        end_date TIMESTAMP,
        source VARCHAR(50) NOT NULL,
        verification_status VARCHAR(50) DEFAULT 'pending',
        verification_date TIMESTAMP,
        verification_method VARCHAR(50),
        verification_details JSONB,
        document_urls TEXT[],
        agreement_id VARCHAR(255),
        blockchain_record_id VARCHAR(255),
        notes TEXT,
        deleted BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );

      CREATE INDEX IF NOT EXISTS idx_rights_records_asset ON rights_records(asset_id, asset_type);
      CREATE INDEX IF NOT EXISTS idx_rights_records_owner ON rights_records(owner_id, owner_type);
      CREATE INDEX IF NOT EXISTS idx_rights_records_type ON rights_records(rights_type);
      CREATE INDEX IF NOT EXISTS idx_rights_records_verification ON rights_records(verification_status);
    `);
    console.log('✓ rights_records table created/verified');
    
    // Create rights_conflicts table
    await executeQuery(`
      CREATE TABLE IF NOT EXISTS rights_conflicts (
        id SERIAL PRIMARY KEY,
        asset_id VARCHAR(255) NOT NULL,
        rights_type VARCHAR(50) NOT NULL,
        conflict_type VARCHAR(50) NOT NULL,
        severity INTEGER NOT NULL,
        status VARCHAR(50) DEFAULT 'open',
        resolution_notes TEXT,
        affected_rights_ids INTEGER[] NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        resolved_at TIMESTAMP,
        resolved_by INTEGER
      );
      
      CREATE INDEX IF NOT EXISTS idx_rights_conflicts_asset ON rights_conflicts(asset_id, rights_type);
      CREATE INDEX IF NOT EXISTS idx_rights_conflicts_status ON rights_conflicts(status);
    `);
    console.log('✓ rights_conflicts table created/verified');
    
    // Create rights_transfers table
    await executeQuery(`
      CREATE TABLE IF NOT EXISTS rights_transfers (
        id SERIAL PRIMARY KEY,
        rights_id INTEGER NOT NULL,
        previous_owner_id INTEGER NOT NULL,
        new_owner_id INTEGER NOT NULL,
        transfer_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        percentage DECIMAL(5,2) NOT NULL,
        reason VARCHAR(255),
        document_urls TEXT[],
        transaction_id VARCHAR(255),
        initiated_by INTEGER,
        status VARCHAR(50) DEFAULT 'completed',
        notes TEXT
      );
    `);
    console.log('✓ rights_transfers table created/verified');
    
    // Add missing methods to rights_management_service
    console.log('Adding missing methods to rights management service...');
    await addMissingRightsMethods();
    
    console.log('All missing tables have been created successfully!');
  } catch (error) {
    console.error('Error creating missing tables:', error);
  } finally {
    // Close DB connection
    try {
      await pool.end();
      console.log('Database connection closed');
    } catch (e) {
      console.error('Error closing database connection:', e);
    }
  }
}

/**
 * Add missing methods to the rights management service
 */
async function addMissingRightsMethods() {
  // Add the verifyRightsOwnership method to RightsManagementService
  await executeQuery(`
    CREATE OR REPLACE FUNCTION verify_rights_ownership(
      p_asset_id TEXT,
      p_rights_type TEXT,
      p_owner_id INTEGER
    )
    RETURNS JSONB
    AS $$
    DECLARE
      v_result JSONB;
      v_rights_record RECORD;
      v_is_owner BOOLEAN DEFAULT FALSE;
      v_ownership_percentage NUMERIC DEFAULT 0;
      v_details JSONB DEFAULT '{}'::JSONB;
    BEGIN
      -- Check if the user has any active rights for this asset
      SELECT INTO v_rights_record
        id, percentage, territory, start_date, end_date, status
      FROM rights_records
      WHERE asset_id = p_asset_id 
        AND rights_type = p_rights_type
        AND owner_id = p_owner_id
        AND deleted = FALSE
        AND (end_date IS NULL OR end_date > CURRENT_TIMESTAMP)
        AND start_date <= CURRENT_TIMESTAMP
      LIMIT 1;
      
      IF v_rights_record.id IS NOT NULL THEN
        v_is_owner := TRUE;
        v_ownership_percentage := v_rights_record.percentage;
        
        v_details := jsonb_build_object(
          'id', v_rights_record.id,
          'percentage', v_ownership_percentage,
          'territory', v_rights_record.territory,
          'startDate', v_rights_record.start_date,
          'endDate', v_rights_record.end_date,
          'status', v_rights_record.status
        );
      END IF;
      
      v_result := jsonb_build_object(
        'isOwner', v_is_owner,
        'percentage', v_ownership_percentage,
        'details', v_details
      );
      
      RETURN v_result;
    END;
    $$ LANGUAGE plpgsql;
  `);
  console.log('✓ Created verify_rights_ownership function');
  
  // Add the getAssetConflicts method to RightsManagementService
  await executeQuery(`
    CREATE OR REPLACE FUNCTION get_asset_conflicts(
      p_asset_id TEXT
    )
    RETURNS JSONB
    AS $$
    DECLARE
      v_result JSONB;
      v_conflicts JSONB;
    BEGIN
      SELECT jsonb_agg(jsonb_build_object(
        'id', id,
        'assetId', asset_id,
        'rightsType', rights_type,
        'conflictType', conflict_type,
        'severity', severity,
        'status', status,
        'affectedRightsIds', affected_rights_ids,
        'createdAt', created_at
      ))
      INTO v_conflicts
      FROM rights_conflicts
      WHERE asset_id = p_asset_id
        AND status != 'resolved';
      
      IF v_conflicts IS NULL THEN
        v_conflicts := '[]'::JSONB;
      END IF;
      
      v_result := jsonb_build_object(
        'conflicts', v_conflicts,
        'count', jsonb_array_length(v_conflicts)
      );
      
      RETURN v_result;
    END;
    $$ LANGUAGE plpgsql;
  `);
  console.log('✓ Created get_asset_conflicts function');
}

// Run the setup
setupMissingTables();