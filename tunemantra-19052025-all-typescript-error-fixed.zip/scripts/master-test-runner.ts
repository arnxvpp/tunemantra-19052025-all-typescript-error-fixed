/**
 * Master Test Runner for TuneMantra
 * 
 * This script runs all available tests for the TuneMantra platform and generates
 * a comprehensive test report. It orchestrates various test scripts and collects
 * their results.
 * 
 * USAGE: npx tsx scripts/master-test-runner.ts
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { spawn } from 'child_process';
import colors from 'colors';

// Configure colors for terminal output
colors.enable();

// Setup file paths
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');
const reportDirPath = path.join(rootDir, 'test-reports');

// Make sure the reports directory exists
if (!fs.existsSync(reportDirPath)) {
  fs.mkdirSync(reportDirPath, { recursive: true });
}

interface TestResult {
  name: string;
  script: string;
  passed: boolean;
  duration: number;
  output: string;
  error?: string;
}

// Define available test suites
const testSuites = [
  {
    name: 'Blockchain Core Tests',
    script: 'scripts/complete-blockchain-test-suite.ts',
    enabled: true,
    description: 'Tests the core blockchain functionality including rights registration, verification, and NFT minting.'
  },
  {
    name: 'Database Schema Tests',
    script: 'scripts/db-test.ts',
    enabled: true,
    description: 'Tests the database schema and basic CRUD operations.'
  },
  {
    name: 'Rights Management Tests',
    script: 'scripts/test-rights-management.ts',
    enabled: true,
    description: 'Tests the rights management service functionality.'
  },
  {
    name: 'Rights Verification Tests',
    script: 'scripts/test-rights-verification.ts',
    enabled: true,
    description: 'Tests the rights verification process.'
  },
  {
    name: 'Blockchain Simulation',
    script: 'scripts/blockchain-simulator.ts',
    enabled: true,
    description: 'Simulates blockchain operations without database dependencies.'
  },
  {
    name: 'Blockchain Connector Tests',
    script: 'scripts/test-blockchain-connector.ts',
    enabled: true,
    description: 'Tests the blockchain connector service.'
  },
  {
    name: 'Royalty Calculation Tests',
    script: 'scripts/test-royalty-calculation.ts',
    enabled: true,
    description: 'Tests the royalty calculation algorithms.'
  },
  {
    name: 'Edge Case Tests',
    script: 'scripts/edge-case-testing.ts',
    enabled: true,
    description: 'Tests edge cases and boundary conditions.'
  },
  {
    name: 'Security Tests',
    script: 'scripts/security-testing.ts',
    enabled: true,
    description: 'Tests security-related functionality and validations.'
  }
];

// Run a single test script and return the result
async function runTest(test: typeof testSuites[0]): Promise<TestResult> {
  return new Promise((resolve) => {
    console.log(`\n${'-'.repeat(40)}`.yellow);
    console.log(`Running test: ${test.name}`.yellow);
    console.log(`Script: ${test.script}`.yellow);
    console.log(`${'-'.repeat(40)}`.yellow);
    
    const startTime = Date.now();
    let output = '';
    let errorOutput = '';
    
    // Check if the script file exists
    const scriptPath = path.join(rootDir, test.script);
    if (!fs.existsSync(scriptPath)) {
      const result: TestResult = {
        name: test.name,
        script: test.script,
        passed: false,
        duration: 0,
        output: '',
        error: `Script file not found: ${scriptPath}`
      };
      
      console.error(`❌ ${result.error}`.red);
      resolve(result);
      return;
    }
    
    // Spawn the test process
    const child = spawn('npx', ['tsx', test.script], {
      cwd: rootDir,
      env: { ...process.env, NODE_ENV: 'development', BLOCKCHAIN_SIMULATION: 'true' }
    });
    
    child.stdout.on('data', (data) => {
      const chunk = data.toString();
      output += chunk;
      process.stdout.write(chunk);
    });
    
    child.stderr.on('data', (data) => {
      const chunk = data.toString();
      errorOutput += chunk;
      process.stderr.write(chunk);
    });
    
    child.on('close', (code) => {
      const endTime = Date.now();
      const duration = endTime - startTime;
      
      const result: TestResult = {
        name: test.name,
        script: test.script,
        passed: code === 0,
        duration,
        output,
        error: errorOutput || undefined
      };
      
      if (result.passed) {
        console.log(`\n✅ Test passed in ${duration}ms`.green);
      } else {
        console.error(`\n❌ Test failed with exit code ${code} in ${duration}ms`.red);
      }
      
      resolve(result);
    });
  });
}

// Run all enabled tests
async function runAllTests() {
  console.log(`\n${'='.repeat(80)}`.cyan);
  console.log(`MASTER TEST RUNNER - TuneMantra Platform`.cyan.bold);
  console.log(`${'='.repeat(80)}\n`.cyan);
  
  console.log(`Found ${testSuites.length} test suites, ${testSuites.filter(t => t.enabled).length} enabled.`);
  
  const results: TestResult[] = [];
  const startTime = Date.now();
  
  for (const test of testSuites) {
    if (test.enabled) {
      const result = await runTest(test);
      results.push(result);
    }
  }
  
  const endTime = Date.now();
  const totalDuration = endTime - startTime;
  
  // Generate report
  await generateReport(results, totalDuration);
  
  // Print summary
  printSummary(results, totalDuration);
  
  // Return exit code based on test results
  return results.every(r => r.passed) ? 0 : 1;
}

// Generate HTML test report
async function generateReport(results: TestResult[], totalDuration: number) {
  const timestamp = new Date().toISOString().replace(/:/g, '-').replace(/\..+/, '');
  const reportPath = path.join(reportDirPath, `test-report-${timestamp}.html`);
  
  const passedTests = results.filter(r => r.passed);
  const failedTests = results.filter(r => !r.passed);
  
  let html = `
  <!DOCTYPE html>
  <html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TuneMantra Test Report - ${timestamp}</title>
    <style>
      body {
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
        line-height: 1.6;
        color: #333;
        max-width: 1200px;
        margin: 0 auto;
        padding: 20px;
      }
      .header {
        text-align: center;
        margin-bottom: 30px;
      }
      .summary {
        display: flex;
        justify-content: space-around;
        margin-bottom: 30px;
        padding: 20px;
        background-color: #f8f9fa;
        border-radius: 5px;
      }
      .summary-item {
        text-align: center;
      }
      .summary-value {
        font-size: 24px;
        font-weight: bold;
      }
      .passed {
        color: #28a745;
      }
      .failed {
        color: #dc3545;
      }
      .test-results {
        margin-bottom: 30px;
      }
      .test-result {
        margin-bottom: 20px;
        padding: 15px;
        border-radius: 5px;
        border-left: 5px solid #ccc;
      }
      .test-result.passed {
        background-color: #f0fff4;
        border-left-color: #28a745;
      }
      .test-result.failed {
        background-color: #fff5f5;
        border-left-color: #dc3545;
      }
      .test-header {
        display: flex;
        justify-content: space-between;
        margin-bottom: 10px;
      }
      .test-name {
        font-weight: bold;
        font-size: 18px;
      }
      .test-details {
        margin-top: 15px;
        padding: 10px;
        background-color: #f8f9fa;
        border-radius: 3px;
        overflow: auto;
        max-height: 300px;
      }
      .test-details pre {
        margin: 0;
        white-space: pre-wrap;
        font-family: monospace;
      }
      .collapsible {
        cursor: pointer;
      }
      .content {
        display: none;
        overflow: hidden;
      }
      .expand-all {
        margin-bottom: 15px;
        padding: 8px 16px;
        background-color: #f8f9fa;
        border: none;
        border-radius: 4px;
        cursor: pointer;
      }
      .expand-all:hover {
        background-color: #e9ecef;
      }
    </style>
  </head>
  <body>
    <div class="header">
      <h1>TuneMantra Test Report</h1>
      <p>Generated at: ${new Date().toLocaleString()}</p>
    </div>
    
    <div class="summary">
      <div class="summary-item">
        <div class="summary-label">Total Tests</div>
        <div class="summary-value">${results.length}</div>
      </div>
      <div class="summary-item">
        <div class="summary-label">Passed</div>
        <div class="summary-value passed">${passedTests.length}</div>
      </div>
      <div class="summary-item">
        <div class="summary-label">Failed</div>
        <div class="summary-value failed">${failedTests.length}</div>
      </div>
      <div class="summary-item">
        <div class="summary-label">Total Duration</div>
        <div class="summary-value">${(totalDuration / 1000).toFixed(2)}s</div>
      </div>
    </div>
    
    <button class="expand-all" onclick="toggleAll()">Expand All</button>
    
    <div class="test-results">
      <h2>Failed Tests (${failedTests.length})</h2>
      ${failedTests.map((test, index) => `
        <div class="test-result failed">
          <div class="test-header">
            <div class="test-name">${test.name}</div>
            <div class="test-duration">${(test.duration / 1000).toFixed(2)}s</div>
          </div>
          <div class="test-script">${test.script}</div>
          <div class="collapsible" onclick="toggle('failed-${index}')">▶ Show Details</div>
          <div id="failed-${index}" class="content">
            <div class="test-details">
              <pre>${escapeHtml(test.output)}</pre>
              ${test.error ? `<pre style="color: red;">${escapeHtml(test.error)}</pre>` : ''}
            </div>
          </div>
        </div>
      `).join('')}
      
      <h2>Passed Tests (${passedTests.length})</h2>
      ${passedTests.map((test, index) => `
        <div class="test-result passed">
          <div class="test-header">
            <div class="test-name">${test.name}</div>
            <div class="test-duration">${(test.duration / 1000).toFixed(2)}s</div>
          </div>
          <div class="test-script">${test.script}</div>
          <div class="collapsible" onclick="toggle('passed-${index}')">▶ Show Details</div>
          <div id="passed-${index}" class="content">
            <div class="test-details">
              <pre>${escapeHtml(test.output)}</pre>
            </div>
          </div>
        </div>
      `).join('')}
    </div>
    
    <script>
      function toggle(id) {
        const content = document.getElementById(id);
        const collapsible = content.previousElementSibling;
        
        if (content.style.display === "block") {
          content.style.display = "none";
          collapsible.textContent = collapsible.textContent.replace("▼", "▶");
        } else {
          content.style.display = "block";
          collapsible.textContent = collapsible.textContent.replace("▶", "▼");
        }
      }
      
      function toggleAll() {
        const allContents = document.querySelectorAll('.content');
        const allCollapsibles = document.querySelectorAll('.collapsible');
        const expandAllButton = document.querySelector('.expand-all');
        
        const anyHidden = Array.from(allContents).some(el => el.style.display !== 'block');
        
        allContents.forEach(content => {
          content.style.display = anyHidden ? 'block' : 'none';
        });
        
        allCollapsibles.forEach(collapsible => {
          if (anyHidden) {
            collapsible.textContent = collapsible.textContent.replace("▶", "▼");
          } else {
            collapsible.textContent = collapsible.textContent.replace("▼", "▶");
          }
        });
        
        expandAllButton.textContent = anyHidden ? 'Collapse All' : 'Expand All';
      }
    </script>
  </body>
  </html>
  `;
  
  fs.writeFileSync(reportPath, html);
  console.log(`\nHTML report saved to: ${reportPath}`.cyan);
  
  return reportPath;
}

// Helper function to escape HTML
function escapeHtml(text: string) {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// Print summary to console
function printSummary(results: TestResult[], totalDuration: number) {
  console.log(`\n${'='.repeat(80)}`.cyan);
  console.log(`TEST SUMMARY`.cyan.bold);
  console.log(`${'='.repeat(80)}`.cyan);
  
  const passedTests = results.filter(r => r.passed);
  const failedTests = results.filter(r => !r.passed);
  
  console.log(`Total Tests: ${results.length}`);
  console.log(`Passed: ${passedTests.length}`.green);
  console.log(`Failed: ${failedTests.length}`.red);
  console.log(`Total Duration: ${(totalDuration / 1000).toFixed(2)}s`);
  
  if (failedTests.length > 0) {
    console.log(`\nFailed Tests:`.red);
    for (const test of failedTests) {
      console.log(`- ${test.name} (${test.script})`.red);
    }
  }
  
  if (passedTests.length === results.length) {
    console.log(`\n✅ All tests passed successfully!`.green.bold);
  } else {
    console.log(`\n❌ Some tests failed. Check the report for details.`.red.bold);
  }
}

// Run all tests and exit with appropriate code
runAllTests()
  .then(exitCode => {
    process.exit(exitCode);
  })
  .catch(error => {
    console.error(`Error running tests:`.red, error);
    process.exit(1);
  });