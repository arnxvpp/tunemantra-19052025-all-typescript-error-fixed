/**
 * Prepare Localhost Package Script
 * 
 * This script prepares the TuneMantra project for local development
 * by creating a zip file with all necessary files.
 * 
 * Run with: node scripts/prepare-localhost.js
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// Directories to exclude from the zip
const EXCLUDE_DIRS = [
  'node_modules',
  '.git',
  'dist',
  '.vscode',
  '.idea',
  'uploads',
  'tmp'
];

// Files to exclude from the zip
const EXCLUDE_FILES = [
  '.env',
  '.DS_Store',
  '.env.local',
  '.env.production',
  '*.zip',
  '*.log'
];

// Create exclude pattern for zip command
const excludePattern = [...EXCLUDE_DIRS.map(dir => `--exclude="*${dir}/*"`), 
                         ...EXCLUDE_FILES.map(file => `--exclude="${file}"`)].join(' ');

// Function to create the .env.example file with the correct structure
function createEnvExample() {
  console.log('Creating .env.example file...');
  
  const envExample = `# Database Connection
DATABASE_URL=postgresql://username:password@localhost:5432/tunemantra

# Authentication
JWT_SECRET=your_jwt_secret
ADMIN_REGISTRATION_CODE=your_admin_registration_code
SESSION_SECRET=your_session_secret

# Blockchain Configuration (Optional)
MUMBAI_RPC_URL=https://polygon-mumbai-bor.publicnode.com
MUMBAI_PRIVATE_KEY=your_private_key
MUMBAI_NFT_CONTRACT_ADDRESS=your_nft_contract_address
MUMBAI_RIGHTS_CONTRACT_ADDRESS=your_rights_contract_address

# Content Protection (Optional)
ACR_HOST=your_acr_host
ACR_ACCESS_KEY=your_acr_access_key
ACR_ACCESS_SECRET=your_acr_access_secret

# Security Settings
NODE_ENV=development
`;

  fs.writeFileSync(path.join(__dirname, '..', '.env.example'), envExample);
  console.log('✅ Created .env.example');
}

// Create the zip file
function createZipFile() {
  console.log('Creating zip file...');
  const zipName = `tunemantra-localhost-${new Date().toISOString().split('T')[0]}.zip`;
  
  try {
    execSync(`cd .. && zip -r ${zipName} tunemantra ${excludePattern}`, { 
      stdio: 'inherit',
      cwd: __dirname
    });
    console.log(`✅ Created ${zipName}`);
  } catch (error) {
    console.error('❌ Failed to create zip file:', error.message);
    console.log('You may need to manually zip the project excluding node_modules and other large directories.');
  }
}

// Function to create a README for the localhost package
function createReadme() {
  console.log('Ensuring README files are up to date...');
  
  // The README is created separately via the str_replace_editor
  console.log('✅ Setup documentation is already created');
}

// Main function
function main() {
  console.log('🚀 Preparing TuneMantra for localhost development...');
  
  createEnvExample();
  createReadme();
  createZipFile();
  
  console.log('✅ Done! Your localhost package is ready.');
  console.log('\nTo set up the project locally:');
  console.log('1. Extract the zip file');
  console.log('2. Follow the instructions in documentation/setup/LOCALHOST_SETUP.md');
}

main();