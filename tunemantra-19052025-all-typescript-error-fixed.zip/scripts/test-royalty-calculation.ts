/**
 * Royalty Calculation Test Script
 * 
 * This script tests the royalty calculation functionality,
 * verifying calculations, splits, and processing.
 * 
 * Usage: npx tsx scripts/test-royalty-calculation.ts
 */

import { db, pool } from '../server/db';
import { royaltyTypeEnum } from '../shared/schema';

/**
 * Test royalty calculation functionality
 */
async function testRoyaltyCalculation() {
  console.log('\n--- Testing Royalty Calculation ---');
  
  // Setup test data
  await setupTestData();
  
  // Get test IDs
  const track = (await db.execute('SELECT id FROM tracks LIMIT 1')).rows[0];
  const user = (await db.execute('SELECT id FROM users LIMIT 1')).rows[0];
  const distribution = (await db.execute('SELECT id FROM distribution_records LIMIT 1')).rows[0];
  const release = (await db.execute('SELECT id FROM releases LIMIT 1')).rows[0];
  
  if (!track || !user || !distribution || !release) {
    console.error('Error: Could not find or create test data');
    return;
  }
  
  const trackId = track.id;
  const userId = user.id;
  const distributionId = distribution.id;
  const releaseId = release.id;
  
  console.log(`Using test data: Track ID ${trackId}, User ID ${userId}, Distribution ID ${distributionId}, Release ID ${releaseId}`);
  
  // Create test royalty calculation
  const result = await createTestRoyaltyCalculation(trackId, userId, distributionId, releaseId);
  console.log('Royalty calculation created:', JSON.stringify(result, null, 2));
  
  // Query the created royalty calculation
  if (result.id) {
    const queryResult = await db.execute('SELECT * FROM royalty_calculations WHERE id = $1', [result.id]);
    console.log('Royalty calculation details:', JSON.stringify(queryResult.rows[0], null, 2));
  }
  
  return { calculationId: result.id, trackId, userId, distributionId, releaseId };
}

/**
 * Test royalty processing 
 */
async function testRoyaltyProcessing(testData) {
  console.log('\n--- Testing Royalty Processing ---');
  
  const { calculationId } = testData;
  
  if (!calculationId) {
    console.error('Error: No calculation ID for processing test');
    return;
  }
  
  // Mark as processed
  const processResult = await db.execute(
    'UPDATE royalty_calculations SET is_processed = true, processing_date = NOW() WHERE id = $1 RETURNING *',
    [calculationId]
  );
  
  console.log('Royalty marked as processed:', JSON.stringify(processResult.rows[0], null, 2));
  
  // Mark as paid
  const paymentResult = await db.execute(
    'UPDATE royalty_calculations SET is_paid = true, payment_date = NOW(), payment_reference = $1 WHERE id = $2 RETURNING *',
    ['TEST-PAYMENT-REF-' + Date.now(), calculationId]
  );
  
  console.log('Royalty marked as paid:', JSON.stringify(paymentResult.rows[0], null, 2));
}

/**
 * Create a test royalty calculation record
 */
async function createTestRoyaltyCalculation(trackId, userId, distributionId, releaseId) {
  try {
    const streamCount = 1000;
    const ratePerStream = 0.004;
    const amount = streamCount * ratePerStream;
    
    const result = await db.execute(`
      INSERT INTO royalty_calculations (
        distribution_record_id, release_id, track_id, user_id,
        amount, stream_count, rate_per_stream,
        timeframe, royalty_type, platform_id,
        split_percentage, recipient_id
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
      RETURNING *
    `, [
      distributionId,
      releaseId,
      trackId,
      userId,
      amount,
      streamCount,
      ratePerStream,
      JSON.stringify({ start: '2025-01-01', end: '2025-01-31' }),
      'performance',
      1, // platform ID
      100, // 100% to the artist
      userId // same as user_id for this test
    ]);
    
    return result.rows[0];
  } catch (error) {
    console.error('Error creating test royalty calculation:', error);
    return { error: error.message };
  }
}

/**
 * Setup test data if needed
 */
async function setupTestData() {
  // Create user if not exists
  if ((await db.execute('SELECT * FROM users LIMIT 1')).rows.length === 0) {
    await db.execute(`
      INSERT INTO users (username, email, password_hash, role, status)
      VALUES ('testuser', 'test@example.com', 'hash', 'artist', 'active')
    `);
  }
  
  // Create track if not exists
  if ((await db.execute('SELECT * FROM tracks LIMIT 1')).rows.length === 0) {
    await db.execute(`
      INSERT INTO tracks (
        title, artist, genre, release_date, cover_art_url, 
        isrc, duration, audio_url, status
      ) VALUES (
        'Test Track', 'Test Artist', 'Test Genre', 
        '2025-01-01', 'https://example.com/cover.jpg',
        'TEST123456789', 180, 'https://example.com/audio.mp3', 'active'
      )
    `);
  }
  
  // Create release if not exists
  if ((await db.execute('SELECT * FROM releases LIMIT 1')).rows.length === 0) {
    await db.execute(`
      INSERT INTO releases (
        title, artist, release_date, status
      ) VALUES (
        'Test Release', 'Test Artist', '2025-01-01', 'active'
      )
    `);
  }
  
  // Create distribution record if not exists
  if ((await db.execute('SELECT * FROM distribution_records LIMIT 1')).rows.length === 0) {
    await db.execute(`
      INSERT INTO distribution_records (
        release_id, platform_id, distribution_date, status
      ) VALUES (
        (SELECT id FROM releases LIMIT 1),
        1, -- platform ID
        '2025-01-01',
        'completed'
      )
    `);
  }
  
  // Create distribution platform if not exists
  if ((await db.execute('SELECT * FROM distribution_platforms LIMIT 1')).rows.length === 0) {
    await db.execute(`
      INSERT INTO distribution_platforms (
        name, api_endpoint, active
      ) VALUES (
        'Test Platform', 'https://api.example.com', true
      )
    `);
  }
}

/**
 * Main test function
 */
async function runTests() {
  console.log('Starting royalty calculation tests...');
  
  try {
    // Run calculation test and get test data
    const testData = await testRoyaltyCalculation();
    
    if (testData && testData.calculationId) {
      // Run processing test
      await testRoyaltyProcessing(testData);
    }
    
    console.log('\nAll tests completed.');
  } catch (error) {
    console.error('Test error:', error);
  } finally {
    // Close DB connection
    try {
      // Use the underlying pool to end the connection
      await pool.end();
    } catch (e) {
      console.error('Error closing database connection:', e);
    }
  }
}

// Run tests
runTests();