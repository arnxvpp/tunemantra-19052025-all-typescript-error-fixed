"use strict";
/**
 * Run All Tests Script
 *
 * This script runs all the test scripts in sequence to validate
 * the integrated functionality of TuneMantra.
 *
 * Usage: npx tsx scripts/run-all-tests.ts
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var child_process_1 = require("child_process");
var util_1 = require("util");
var execAsync = (0, util_1.promisify)(child_process_1.exec);
/**
 * Setup scripts to run first to prepare the database
 */
var SETUP_SCRIPTS = [
    'scripts/setup-missing-tables.ts'
];
/**
 * Test scripts to run after setup
 */
var TEST_SCRIPTS = [
    // Simulator scripts that don't need database access
    'scripts/blockchain-simulator.ts',
    'scripts/rights-management-simulator.ts',
    'scripts/royalty-calculation-simulator.ts',
    // Database-dependent test scripts
    'scripts/test-blockchain-connector.ts',
    'scripts/test-rights-management.ts',
    'scripts/test-royalty-calculation.ts',
    // Verification scripts
    'scripts/verify-database.ts'
];
/**
 * Run a test script
 */
function runScript(scriptPath) {
    return __awaiter(this, void 0, void 0, function () {
        var _a, stdout, stderr, error_1;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    console.log("\n".concat('='.repeat(50)));
                    console.log("Running: ".concat(scriptPath));
                    console.log("".concat('='.repeat(50), "\n"));
                    _b.label = 1;
                case 1:
                    _b.trys.push([1, 3, , 4]);
                    return [4 /*yield*/, execAsync("npx tsx ".concat(scriptPath))];
                case 2:
                    _a = _b.sent(), stdout = _a.stdout, stderr = _a.stderr;
                    if (stdout) {
                        console.log(stdout);
                    }
                    if (stderr) {
                        console.error('STDERR:', stderr);
                    }
                    console.log("\n".concat('='.repeat(50)));
                    console.log("Completed: ".concat(scriptPath));
                    console.log("".concat('='.repeat(50), "\n"));
                    return [3 /*break*/, 4];
                case 3:
                    error_1 = _b.sent();
                    console.error("Error running ".concat(scriptPath, ":"), error_1.message);
                    if (error_1.stdout)
                        console.log(error_1.stdout);
                    if (error_1.stderr)
                        console.error(error_1.stderr);
                    return [3 /*break*/, 4];
                case 4: return [2 /*return*/];
            }
        });
    });
}
/**
 * Run all test scripts in sequence
 */
function runAllTests() {
    return __awaiter(this, void 0, void 0, function () {
        var _i, SETUP_SCRIPTS_1, script, _a, TEST_SCRIPTS_1, script;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    console.log("\n".concat('#'.repeat(70)));
                    console.log("Starting TuneMantra Integration Tests at ".concat(new Date().toLocaleString()));
                    console.log("".concat('#'.repeat(70), "\n"));
                    // First run setup scripts
                    console.log("\nRunning setup scripts...\n");
                    _i = 0, SETUP_SCRIPTS_1 = SETUP_SCRIPTS;
                    _b.label = 1;
                case 1:
                    if (!(_i < SETUP_SCRIPTS_1.length)) return [3 /*break*/, 5];
                    script = SETUP_SCRIPTS_1[_i];
                    return [4 /*yield*/, runScript(script)];
                case 2:
                    _b.sent();
                    // Add a small delay to ensure connections are properly closed
                    console.log("\nWaiting 2 seconds before continuing...\n");
                    return [4 /*yield*/, new Promise(function (resolve) { return setTimeout(resolve, 2000); })];
                case 3:
                    _b.sent();
                    _b.label = 4;
                case 4:
                    _i++;
                    return [3 /*break*/, 1];
                case 5:
                    // Then run test scripts
                    console.log("\nRunning test scripts...\n");
                    _a = 0, TEST_SCRIPTS_1 = TEST_SCRIPTS;
                    _b.label = 6;
                case 6:
                    if (!(_a < TEST_SCRIPTS_1.length)) return [3 /*break*/, 10];
                    script = TEST_SCRIPTS_1[_a];
                    return [4 /*yield*/, runScript(script)];
                case 7:
                    _b.sent();
                    // Add a small delay to ensure connections are properly closed
                    console.log("\nWaiting 2 seconds before running next test...\n");
                    return [4 /*yield*/, new Promise(function (resolve) { return setTimeout(resolve, 2000); })];
                case 8:
                    _b.sent();
                    _b.label = 9;
                case 9:
                    _a++;
                    return [3 /*break*/, 6];
                case 10:
                    console.log("\n".concat('#'.repeat(70)));
                    console.log("All tests completed at ".concat(new Date().toLocaleString()));
                    console.log("".concat('#'.repeat(70), "\n"));
                    return [2 /*return*/];
            }
        });
    });
}
// Run all tests
runAllTests();
