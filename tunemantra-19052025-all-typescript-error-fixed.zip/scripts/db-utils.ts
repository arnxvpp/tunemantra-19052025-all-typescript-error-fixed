/**
 * Database Utilities
 * 
 * Common database utility functions for testing and validating TuneMantra services.
 * This provides a bridge between simulation-based testing and actual database interactions.
 */

import { executeQuery, pool } from '../server/db';

/**
 * Check if a table exists in the database
 * 
 * @param tableName - Name of the table to check
 * @returns Promise resolving to boolean (true if exists)
 */
export async function tableExists(tableName: string): Promise<boolean> {
  const result = await executeQuery(`
    SELECT EXISTS (
      SELECT FROM information_schema.tables 
      WHERE table_schema = 'public'
      AND table_name = $1
    );
  `, [tableName]);
  
  return result.rows[0].exists;
}

/**
 * Count records in a table
 * 
 * @param tableName - Name of the table
 * @param whereClause - Optional WHERE clause (without 'WHERE' keyword)
 * @param params - Optional parameters for the WHERE clause
 * @returns Promise resolving to number of records
 */
export async function countRecords(
  tableName: string, 
  whereClause?: string, 
  params?: any[]
): Promise<number> {
  let query = `SELECT COUNT(*) FROM ${tableName}`;
  
  if (whereClause) {
    query += ` WHERE ${whereClause}`;
  }
  
  const result = await executeQuery(query, params);
  return parseInt(result.rows[0].count);
}

/**
 * Insert a record into a table
 * 
 * @param tableName - Name of the table
 * @param record - Object with column names and values
 * @returns Promise resolving to the inserted record
 */
export async function insertRecord(
  tableName: string, 
  record: Record<string, any>
): Promise<any> {
  const columns = Object.keys(record);
  const values = Object.values(record);
  const placeholders = values.map((_, i) => `$${i + 1}`).join(', ');
  
  const query = `
    INSERT INTO ${tableName} (${columns.join(', ')})
    VALUES (${placeholders})
    RETURNING *;
  `;
  
  const result = await executeQuery(query, values);
  return result.rows[0];
}

/**
 * Retrieve a record from a table
 * 
 * @param tableName - Name of the table
 * @param idField - Name of the ID field (default: 'id')
 * @param idValue - Value of the ID
 * @returns Promise resolving to the retrieved record (or null)
 */
export async function getRecord(
  tableName: string,
  idField: string = 'id',
  idValue: string | number
): Promise<any | null> {
  const query = `
    SELECT * FROM ${tableName}
    WHERE ${idField} = $1
    LIMIT 1;
  `;
  
  const result = await executeQuery(query, [idValue]);
  return result.rows.length > 0 ? result.rows[0] : null;
}

/**
 * Update a record in a table
 * 
 * @param tableName - Name of the table
 * @param idField - Name of the ID field (default: 'id')
 * @param idValue - Value of the ID
 * @param updates - Object with column names and values to update
 * @returns Promise resolving to the updated record
 */
export async function updateRecord(
  tableName: string,
  idField: string = 'id',
  idValue: string | number,
  updates: Record<string, any>
): Promise<any> {
  const setClause = Object.keys(updates)
    .map((column, i) => `${column} = $${i + 2}`)
    .join(', ');
  
  const query = `
    UPDATE ${tableName}
    SET ${setClause}
    WHERE ${idField} = $1
    RETURNING *;
  `;
  
  const result = await executeQuery(
    query, 
    [idValue, ...Object.values(updates)]
  );
  
  return result.rows[0];
}

/**
 * Delete a record from a table
 * 
 * @param tableName - Name of the table
 * @param idField - Name of the ID field (default: 'id')
 * @param idValue - Value of the ID
 * @returns Promise resolving to boolean indicating success
 */
export async function deleteRecord(
  tableName: string,
  idField: string = 'id',
  idValue: string | number
): Promise<boolean> {
  const query = `
    DELETE FROM ${tableName}
    WHERE ${idField} = $1
    RETURNING ${idField};
  `;
  
  const result = await executeQuery(query, [idValue]);
  return result.rows.length > 0;
}

/**
 * Run a query with transaction support
 * 
 * @param callback - Async function that receives a client to execute queries
 * @returns Promise resolving to the result of the callback
 */
export async function withTransaction<T>(
  callback: (client: any) => Promise<T>
): Promise<T> {
  const client = await pool.connect();
  
  try {
    await client.query('BEGIN');
    const result = await callback(client);
    await client.query('COMMIT');
    return result;
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}

/**
 * Clean up database resources
 */
export async function closeDatabase(): Promise<void> {
  await pool.end();
}