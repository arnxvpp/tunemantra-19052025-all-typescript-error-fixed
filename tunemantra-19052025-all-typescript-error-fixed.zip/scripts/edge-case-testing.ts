/**
 * Edge Case Testing for Rights Management System
 * 
 * This test suite focuses on validating the system's behavior with:
 * - Extreme inputs
 * - Boundary conditions  
 * - Unusual parameter combinations
 * - Invalid inputs
 * - Unexpected states
 * 
 * Usage: npx tsx scripts/edge-case-testing.ts
 */

import { 
  runTestSuite, 
  assertEqual, 
  assertObjectContains,
  insertTestData,
  clearTestData,
  mockBlockchainTransaction
} from './test-framework';
import { apiRequest } from '../client/src/lib/queryClient';
import { MintParams, RegisterRightsParams, VerifyRightsParams } from '../client/src/web3/types';

// Mock fetch function for testing - can be replaced with actual API calls in non-testing environment
global.fetch = async (url: string, options: any = {}) => {
  // Mock implementation of fetch for testing
  const mockResponses: Record<string, any> = {
    '/api/blockchain/mint-track': {
      success: true,
      tokenId: '12345',
      message: 'Token minted successfully'
    },
    '/api/blockchain/register-rights': {
      success: true,
      tokenId: '12345',
      rightsId: 1,
      message: 'Rights registered successfully'
    },
    '/api/blockchain/verify-rights': {
      verified: true
    },
    '/api/rights-management/register': {
      success: true,
      rightsId: 1,
      tokenId: '12345',
      message: 'Rights registered successfully'
    }
  };

  // Extract endpoint from URL
  const endpoint = url.split('?')[0];
  const method = options.method || 'GET';
  
  // Get mock response for this endpoint
  const mockResponse = mockResponses[endpoint];
  
  if (!mockResponse) {
    return {
      ok: false,
      status: 404,
      statusText: 'Not Found',
      json: async () => ({ error: 'Endpoint not found' }),
      text: async () => 'Endpoint not found'
    } as Response;
  }
  
  return {
    ok: true,
    status: 200,
    statusText: 'OK',
    json: async () => mockResponse,
    text: async () => JSON.stringify(mockResponse)
  } as Response;
};

// Test suite for edge cases in rights registration
async function testRightsRegistrationEdgeCases(): Promise<void> {
  const tests = [
    {
      name: 'Register rights with minimum valid parameters',
      fn: async () => {
        const minimalParams: RegisterRightsParams = {
          assetId: '12345',
          assetType: 'track',
          rightsType: 'master',
          ownerType: 'artist',
          percentage: 100,
          startDate: new Date()
        };
        
        const result = await apiRequest('/api/rights-management/register', {
          method: 'POST',
          data: minimalParams
        });
        
        assertEqual(result.success, true);
        assertObjectContains(result, { 
          rightsId: 1,
          message: 'Rights registered successfully' 
        });
      }
    },
    {
      name: 'Register rights with extremely long asset ID',
      fn: async () => {
        // Generate a very long string for assetId
        const longAssetId = 'a'.repeat(10000);
        
        const params: RegisterRightsParams = {
          assetId: longAssetId,
          assetType: 'track',
          rightsType: 'master',
          ownerType: 'artist',
          percentage: 100,
          startDate: new Date()
        };
        
        try {
          await apiRequest('/api/rights-management/register', {
            method: 'POST',
            data: params
          });
          
          throw new Error('Expected to fail with extremely long asset ID');
        } catch (error) {
          // We expect this to fail due to the extremely long asset ID
          if (!(error instanceof Error)) {
            throw new Error('Expected an Error object');
          }
          
          // Success - we caught the expected error
          return { expectedError: true };
        }
      }
    },
    {
      name: 'Register rights with 0% ownership',
      fn: async () => {
        const params: RegisterRightsParams = {
          assetId: '12345',
          assetType: 'track',
          rightsType: 'master',
          ownerType: 'artist',
          percentage: 0,
          startDate: new Date()
        };
        
        try {
          await apiRequest('/api/rights-management/register', {
            method: 'POST',
            data: params
          });
          
          throw new Error('Expected to fail with 0% ownership');
        } catch (error) {
          // We expect this to fail due to the 0% ownership
          if (!(error instanceof Error)) {
            throw new Error('Expected an Error object');
          }
          
          // Success - we caught the expected error
          return { expectedError: true };
        }
      }
    },
    {
      name: 'Register rights with 100.1% ownership',
      fn: async () => {
        const params: RegisterRightsParams = {
          assetId: '12345',
          assetType: 'track',
          rightsType: 'master',
          ownerType: 'artist',
          percentage: 100.1,
          startDate: new Date()
        };
        
        try {
          await apiRequest('/api/rights-management/register', {
            method: 'POST',
            data: params
          });
          
          throw new Error('Expected to fail with ownership > 100%');
        } catch (error) {
          // We expect this to fail due to the ownership > 100%
          if (!(error instanceof Error)) {
            throw new Error('Expected an Error object');
          }
          
          // Success - we caught the expected error
          return { expectedError: true };
        }
      }
    },
    {
      name: 'Register rights with end date before start date',
      fn: async () => {
        const startDate = new Date();
        const endDate = new Date(startDate);
        endDate.setDate(startDate.getDate() - 1); // One day before start date
        
        const params: RegisterRightsParams = {
          assetId: '12345',
          assetType: 'track',
          rightsType: 'master',
          ownerType: 'artist',
          percentage: 100,
          startDate,
          endDate
        };
        
        try {
          await apiRequest('/api/rights-management/register', {
            method: 'POST',
            data: params
          });
          
          throw new Error('Expected to fail with end date before start date');
        } catch (error) {
          // We expect this to fail due to the end date before start date
          if (!(error instanceof Error)) {
            throw new Error('Expected an Error object');
          }
          
          // Success - we caught the expected error
          return { expectedError: true };
        }
      }
    },
    {
      name: 'Register rights with extremely future end date',
      fn: async () => {
        const startDate = new Date();
        const endDate = new Date(startDate);
        endDate.setFullYear(startDate.getFullYear() + 1000); // 1000 years in the future
        
        const params: RegisterRightsParams = {
          assetId: '12345',
          assetType: 'track',
          rightsType: 'master',
          ownerType: 'artist',
          percentage: 100,
          startDate,
          endDate
        };
        
        // This might be valid depending on business rules
        const result = await apiRequest('/api/rights-management/register', {
          method: 'POST',
          data: params
        });
        
        assertEqual(result.success, true);
        assertObjectContains(result, { 
          rightsId: 1,
          message: 'Rights registered successfully' 
        });
      }
    },
    {
      name: 'Register rights with invalid asset type',
      fn: async () => {
        const params: any = {
          assetId: '12345',
          assetType: 'invalid_type', // Invalid asset type
          rightsType: 'master',
          ownerType: 'artist',
          percentage: 100,
          startDate: new Date()
        };
        
        try {
          await apiRequest('/api/rights-management/register', {
            method: 'POST',
            data: params
          });
          
          throw new Error('Expected to fail with invalid asset type');
        } catch (error) {
          // We expect this to fail due to the invalid asset type
          if (!(error instanceof Error)) {
            throw new Error('Expected an Error object');
          }
          
          // Success - we caught the expected error
          return { expectedError: true };
        }
      }
    },
    {
      name: 'Register multiple overlapping rights for same asset',
      fn: async () => {
        const params1: RegisterRightsParams = {
          assetId: '12345',
          assetType: 'track',
          rightsType: 'master',
          ownerType: 'artist',
          percentage: 60,
          startDate: new Date()
        };
        
        const params2: RegisterRightsParams = {
          assetId: '12345',
          assetType: 'track',
          rightsType: 'master',
          ownerType: 'producer',
          percentage: 40,
          startDate: new Date()
        };
        
        // First registration should succeed
        const result1 = await apiRequest('/api/rights-management/register', {
          method: 'POST',
          data: params1
        });
        
        assertEqual(result1.success, true);
        
        // Second registration should also succeed because total percentage is 100%
        const result2 = await apiRequest('/api/rights-management/register', {
          method: 'POST',
          data: params2
        });
        
        assertEqual(result2.success, true);
        
        // Try to register another right for the same asset, exceeding 100%
        const params3: RegisterRightsParams = {
          assetId: '12345',
          assetType: 'track',
          rightsType: 'master',
          ownerType: 'label',
          percentage: 10,
          startDate: new Date()
        };
        
        try {
          await apiRequest('/api/rights-management/register', {
            method: 'POST',
            data: params3
          });
          
          throw new Error('Expected to fail with total percentage > 100%');
        } catch (error) {
          // We expect this to fail due to the total percentage exceeding 100%
          if (!(error instanceof Error)) {
            throw new Error('Expected an Error object');
          }
          
          // Success - we caught the expected error
          return { expectedError: true };
        }
      }
    }
  ];
  
  await runTestSuite('Rights Registration Edge Cases', tests);
}

// Test suite for edge cases in blockchain verification
async function testBlockchainVerificationEdgeCases(): Promise<void> {
  const tests = [
    {
      name: 'Verify rights with valid parameters',
      fn: async () => {
        const params: VerifyRightsParams = {
          rightsId: 1,
          tokenId: '12345',
          signature: 'valid_signature',
          ownerAddress: '0x1234567890123456789012345678901234567890'
        };
        
        const result = await apiRequest('/api/blockchain/verify-rights', {
          method: 'POST',
          data: params
        });
        
        assertEqual(result.verified, true);
      }
    },
    {
      name: 'Verify rights with invalid rights ID',
      fn: async () => {
        const params: VerifyRightsParams = {
          rightsId: -1, // Invalid rights ID
          tokenId: '12345',
          signature: 'valid_signature',
          ownerAddress: '0x1234567890123456789012345678901234567890'
        };
        
        try {
          await apiRequest('/api/blockchain/verify-rights', {
            method: 'POST',
            data: params
          });
          
          throw new Error('Expected to fail with invalid rights ID');
        } catch (error) {
          // We expect this to fail due to the invalid rights ID
          if (!(error instanceof Error)) {
            throw new Error('Expected an Error object');
          }
          
          // Success - we caught the expected error
          return { expectedError: true };
        }
      }
    },
    {
      name: 'Verify rights with non-existent token ID',
      fn: async () => {
        const params: VerifyRightsParams = {
          rightsId: 1,
          tokenId: 'non_existent', // Non-existent token ID
          signature: 'valid_signature',
          ownerAddress: '0x1234567890123456789012345678901234567890'
        };
        
        // This should return a verification failure, not throw an error
        const result = await apiRequest('/api/blockchain/verify-rights', {
          method: 'POST',
          data: params
        });
        
        assertEqual(result.verified, false);
      }
    },
    {
      name: 'Verify rights with invalid blockchain signature',
      fn: async () => {
        const params: VerifyRightsParams = {
          rightsId: 1,
          tokenId: '12345',
          signature: 'invalid_signature', // Invalid signature
          ownerAddress: '0x1234567890123456789012345678901234567890'
        };
        
        // This should return a verification failure, not throw an error
        const result = await apiRequest('/api/blockchain/verify-rights', {
          method: 'POST',
          data: params
        });
        
        assertEqual(result.verified, false);
      }
    },
    {
      name: 'Verify rights with wrong owner address',
      fn: async () => {
        const params: VerifyRightsParams = {
          rightsId: 1,
          tokenId: '12345',
          signature: 'valid_signature',
          ownerAddress: '0x0000000000000000000000000000000000000000' // Wrong owner address
        };
        
        // This should return a verification failure, not throw an error
        const result = await apiRequest('/api/blockchain/verify-rights', {
          method: 'POST',
          data: params
        });
        
        assertEqual(result.verified, false);
      }
    },
    {
      name: 'Verify rights with rights ID and token ID mismatch',
      fn: async () => {
        // First, register rights for asset 12345
        const params1: RegisterRightsParams = {
          assetId: '12345',
          assetType: 'track',
          rightsType: 'master',
          ownerType: 'artist',
          percentage: 100,
          startDate: new Date()
        };
        
        const result1 = await apiRequest('/api/rights-management/register', {
          method: 'POST',
          data: params1
        });
        
        // Now, register rights for a different asset
        const params2: RegisterRightsParams = {
          assetId: '67890',
          assetType: 'track',
          rightsType: 'master',
          ownerType: 'artist',
          percentage: 100,
          startDate: new Date()
        };
        
        const result2 = await apiRequest('/api/rights-management/register', {
          method: 'POST',
          data: params2
        });
        
        // Try to verify with a mismatch between rights ID and token ID
        const verifyParams: VerifyRightsParams = {
          rightsId: result1.rightsId, // Rights ID for the first asset
          tokenId: result2.tokenId, // Token ID for the second asset
          signature: 'valid_signature',
          ownerAddress: '0x1234567890123456789012345678901234567890'
        };
        
        // This should return a verification failure, not throw an error
        const result = await apiRequest('/api/blockchain/verify-rights', {
          method: 'POST',
          data: verifyParams
        });
        
        assertEqual(result.verified, false);
      }
    },
    {
      name: 'Verify rights for expired rights',
      fn: async () => {
        // Register rights with an end date in the past
        const startDate = new Date();
        startDate.setFullYear(startDate.getFullYear() - 2); // 2 years ago
        
        const endDate = new Date();
        endDate.setFullYear(endDate.getFullYear() - 1); // 1 year ago
        
        const params: RegisterRightsParams = {
          assetId: '12345',
          assetType: 'track',
          rightsType: 'master',
          ownerType: 'artist',
          percentage: 100,
          startDate,
          endDate
        };
        
        const registerResult = await apiRequest('/api/rights-management/register', {
          method: 'POST',
          data: params
        });
        
        // Try to verify the expired rights
        const verifyParams: VerifyRightsParams = {
          rightsId: registerResult.rightsId,
          tokenId: registerResult.tokenId,
          signature: 'valid_signature',
          ownerAddress: '0x1234567890123456789012345678901234567890'
        };
        
        // This should return a verification failure for expired rights
        const result = await apiRequest('/api/blockchain/verify-rights', {
          method: 'POST',
          data: verifyParams
        });
        
        assertEqual(result.verified, false);
      }
    }
  ];
  
  await runTestSuite('Blockchain Verification Edge Cases', tests);
}

// Test suite for multi-network blockchain rights
async function testMultiNetworkBlockchainRights(): Promise<void> {
  const tests = [
    {
      name: 'Register rights on multiple networks',
      fn: async () => {
        // Register rights on Ethereum
        const paramsEth: RegisterRightsParams = {
          assetId: '12345',
          assetType: 'track',
          rightsType: 'master',
          ownerType: 'artist',
          percentage: 100,
          startDate: new Date(),
          networkId: 'ethereum'
        };
        
        const resultEth = await apiRequest('/api/blockchain/register-rights', {
          method: 'POST',
          data: paramsEth
        });
        
        assertEqual(resultEth.success, true);
        
        // Register rights on Polygon
        const paramsPolygon: RegisterRightsParams = {
          assetId: '12345',
          assetType: 'track',
          rightsType: 'master',
          ownerType: 'artist',
          percentage: 100,
          startDate: new Date(),
          networkId: 'polygon'
        };
        
        const resultPolygon = await apiRequest('/api/blockchain/register-rights', {
          method: 'POST',
          data: paramsPolygon
        });
        
        assertEqual(resultPolygon.success, true);
        
        // Verify that we have different token IDs for each network
        if (resultEth.tokenId === resultPolygon.tokenId) {
          throw new Error('Expected different token IDs for different networks');
        }
      }
    },
    {
      name: 'Verify rights on specific network',
      fn: async () => {
        // Register rights on Mumbai testnet
        const params: RegisterRightsParams = {
          assetId: '12345',
          assetType: 'track',
          rightsType: 'master',
          ownerType: 'artist',
          percentage: 100,
          startDate: new Date(),
          networkId: 'mumbai'
        };
        
        const result = await apiRequest('/api/blockchain/register-rights', {
          method: 'POST',
          data: params
        });
        
        // Verify rights on Mumbai testnet
        const verifyParams: VerifyRightsParams = {
          rightsId: result.rightsId,
          tokenId: result.tokenId,
          chainId: 80001, // Mumbai testnet
          signature: 'valid_signature',
          ownerAddress: '0x1234567890123456789012345678901234567890'
        };
        
        const verifyResult = await apiRequest('/api/blockchain/verify-rights', {
          method: 'POST',
          data: verifyParams
        });
        
        assertEqual(verifyResult.verified, true);
      }
    },
    {
      name: 'Verify rights on wrong network',
      fn: async () => {
        // Register rights on Mumbai testnet
        const params: RegisterRightsParams = {
          assetId: '12345',
          assetType: 'track',
          rightsType: 'master',
          ownerType: 'artist',
          percentage: 100,
          startDate: new Date(),
          networkId: 'mumbai'
        };
        
        const result = await apiRequest('/api/blockchain/register-rights', {
          method: 'POST',
          data: params
        });
        
        // Try to verify on Ethereum mainnet
        const verifyParams: VerifyRightsParams = {
          rightsId: result.rightsId,
          tokenId: result.tokenId,
          chainId: 1, // Ethereum mainnet
          signature: 'valid_signature',
          ownerAddress: '0x1234567890123456789012345678901234567890'
        };
        
        // This should return a verification failure due to network mismatch
        const verifyResult = await apiRequest('/api/blockchain/verify-rights', {
          method: 'POST',
          data: verifyParams
        });
        
        assertEqual(verifyResult.verified, false);
      }
    }
  ];
  
  await runTestSuite('Multi-Network Blockchain Rights', tests);
}

// Run all test suites
async function runAllTests(): Promise<void> {
  try {
    await testRightsRegistrationEdgeCases();
    await testBlockchainVerificationEdgeCases();
    await testMultiNetworkBlockchainRights();
    
    console.log('\n✅ All edge case tests completed!');
  } catch (error) {
    console.error('\n❌ Test execution failed:', error);
    process.exit(1);
  }
}

// Execute tests
runAllTests();