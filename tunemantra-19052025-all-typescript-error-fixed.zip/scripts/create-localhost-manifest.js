/**
 * Create Localhost Manifest Script
 * 
 * This script generates a manifest of files that should be included 
 * in the localhost package.
 */

import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Directories to exclude
const EXCLUDE_DIRS = [
  'node_modules',
  '.git',
  'dist',
  '.cache',
  '.upm',
  '.config',
  '.archive',
  'tmp',
  '.local'
];

// Files to exclude
const EXCLUDE_FILES = [
  '.env',
  '.env.development',
  '.env.production',
  '.DS_Store',
  '.replit',
  '.breakpoints',
  'replit.nix'
];

// File patterns to exclude (using simple string matching)
const EXCLUDE_PATTERNS = [
  '.agent_state_',
  '.bin',
  '.lesshst'
];

// Function to traverse the directory and collect files
function collectFiles(dir, fileList = []) {
  const files = fs.readdirSync(dir);
  
  files.forEach(file => {
    const fullPath = path.join(dir, file);
    
    // Skip excluded directories
    if (fs.statSync(fullPath).isDirectory()) {
      if (EXCLUDE_DIRS.includes(file)) {
        return;
      }
      collectFiles(fullPath, fileList);
      return;
    }
    
    // Skip excluded files
    if (EXCLUDE_FILES.includes(file)) {
      return;
    }
    
    // Skip files matching excluded patterns
    if (EXCLUDE_PATTERNS.some(pattern => file.includes(pattern))) {
      return;
    }
    
    fileList.push(fullPath);
  });
  
  return fileList;
}

// Create manifest file
function createManifest() {
  const rootDir = path.resolve(__dirname, '..');
  const files = collectFiles(rootDir);
  
  // Create relative paths
  const relativePaths = files.map(file => path.relative(rootDir, file));
  
  // Write manifest file
  fs.writeFileSync(
    path.join(rootDir, 'tmp', 'localhost-manifest.txt'),
    relativePaths.join('\n')
  );
  
  console.log(`Created manifest with ${relativePaths.length} files`);
  return relativePaths;
}

// Main function
function main() {
  // Create tmp directory if it doesn't exist
  const tmpDir = path.resolve(__dirname, '..', 'tmp');
  if (!fs.existsSync(tmpDir)) {
    fs.mkdirSync(tmpDir, { recursive: true });
  }
  
  const files = createManifest();
  
  console.log('Localhost package manifest created successfully!');
  console.log(`Total files: ${files.length}`);
  
  // Display instruction for manual download
  console.log('\nTo create a zip file for localhost development:');
  console.log('1. Download each file listed in the manifest');
  console.log('2. Maintain the directory structure');
  console.log('3. Create a zip file with all the files');
  console.log('4. Extract the zip file on your local machine');
  console.log('5. Follow the instructions in documentation/setup/LOCALHOST_SETUP.md');
}

main();