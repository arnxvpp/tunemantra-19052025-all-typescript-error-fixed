import { runAllMigrations } from './server/migrations';

// Run all migrations
console.log('Starting migrations process...');

runAllMigrations()
  .then(() => {
    console.log('✅ All migrations have been successfully applied!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('❌ Migration process failed:', error);
    process.exit(1);
  });