#!/usr/bin/env tsx

/**
 * This script runs all database migrations in the correct order.
 * Usage: npm run db:migrate
 */
import { runAllMigrations } from './server/migrations/index.js';
import { db } from './server/db.js';
import { runMigration as addEnhancedMetadata } from './server/migrations/add-enhanced-metadata.js';
import { runMigration as addPermissionsColumn } from './server/migrations/add-permissions-column.js';
import { runMigration as addRoleBasedAccess } from './server/migrations/add-role-based-access.js';

async function main() {
  try {
    console.log('Starting migration process...');
    
    // Run migrations in specific order
    console.log('Running add-role-based-access migration...');
    await addRoleBasedAccess();
    
    console.log('Running add-permissions-column migration...');
    await addPermissionsColumn();
    
    console.log('Running add-enhanced-metadata migration...');
    await addEnhancedMetadata();
    
    console.log('All migrations completed successfully!');
    
    // Close the database connection
    if (typeof (db as any).$client?.end === 'function') {
      await (db as any).$client.end();
    }
    
    process.exit(0);
  } catch (error) {
    console.error('Migration process failed:', error);
    process.exit(1);
  }
}

main();