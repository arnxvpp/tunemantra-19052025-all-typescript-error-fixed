-- Reset and populate database with demo data for TuneMantra music distribution platform
-- This script will reset all tables and add comprehensive demo data

-- Step 1: Truncate all tables
TRUNCATE TABLE account_approvals CASCADE;
TRUNCATE TABLE analytics CASCADE;
TRUNCATE TABLE daily_stats CASCADE;
TRUNCATE TABLE distribution_platforms CASCADE;
TRUNCATE TABLE distribution_records CASCADE;
TRUNCATE TABLE permission_templates CASCADE;
TRUNCATE TABLE release_approvals CASCADE;
TRUNCATE TABLE releases CASCADE;
TRUNCATE TABLE rights_management CASCADE;
TRUNCATE TABLE royalty_splits CASCADE;
TRUNCATE TABLE sub_label_audit_logs CASCADE;
TRUNCATE TABLE support_ticket_messages CASCADE;
TRUNCATE TABLE support_tickets CASCADE;
TRUNCATE TABLE tracks CASCADE;
TRUNCATE TABLE users CASCADE;
-- Keep super_admin table for application admin access

-- Step 2: Reset sequences
ALTER SEQUENCE users_id_seq RESTART WITH 1;
ALTER SEQUENCE releases_id_seq RESTART WITH 1;
ALTER SEQUENCE tracks_id_seq RESTART WITH 1;
ALTER SEQUENCE distribution_platforms_id_seq RESTART WITH 1;
ALTER SEQUENCE distribution_records_id_seq RESTART WITH 1;
ALTER SEQUENCE analytics_id_seq RESTART WITH 1;
ALTER SEQUENCE daily_stats_id_seq RESTART WITH 1;
ALTER SEQUENCE support_tickets_id_seq RESTART WITH 1;
ALTER SEQUENCE support_ticket_messages_id_seq RESTART WITH 1;

-- Step 3: Add demo users with different roles
-- Admin user
INSERT INTO users (username, password, email, full_name, role, status, created_at, entity_name, permissions, client_id)
VALUES ('admin', '$2b$10$VfMVfkts5jGZ5ZWayBVYne5ZCiKvEXQfAxSVyKfvrn9KepehKmyaG', 'admin@tunemantra.com', 
        'Admin User', 'admin', 'active', NOW(), 'TuneMantra', 
        '{"canCreateReleases": true, "canManageArtists": true, "canViewAnalytics": true, "canManageDistribution": true, 
          "canManageRoyalties": true, "canEditMetadata": true, "canAccessFinancials": true, "canInviteUsers": true, 
          "canManageUsers": true, "canManageSubscriptions": true, "canAccessAdminPanel": true, "canViewAllContent": true, 
          "canViewAllReports": true}', 'TMADN001');

-- Label users (3)
INSERT INTO users (username, password, email, full_name, role, status, created_at, entity_name, permissions, client_id, avatar_url)
VALUES 
('harmony_records', '$2b$10$VfMVfkts5jGZ5ZWayBVYne5ZCiKvEXQfAxSVyKfvrn9KepehKmyaG', 'contact@harmonyrecords.com', 
 'Sarah Johnson', 'label', 'active', NOW() - INTERVAL '60 days', 'Harmony Records', 
 '{"canCreateReleases": true, "canManageArtists": true, "canViewAnalytics": true, "canManageDistribution": true, 
   "canManageRoyalties": true, "canEditMetadata": true, "canAccessFinancials": true, "canInviteUsers": true}', 'TMLBL001',
 'https://api.dicebear.com/7.x/avataaars/svg?seed=harmony'),

('fusion_music', '$2b$10$VfMVfkts5jGZ5ZWayBVYne5ZCiKvEXQfAxSVyKfvrn9KepehKmyaG', 'management@fusionmusic.com', 
 'Michael Rodriguez', 'label', 'active', NOW() - INTERVAL '45 days', 'Fusion Music Group', 
 '{"canCreateReleases": true, "canManageArtists": true, "canViewAnalytics": true, "canManageDistribution": true, 
   "canManageRoyalties": true, "canEditMetadata": true, "canAccessFinancials": true, "canInviteUsers": true}', 'TMLBL002',
 'https://api.dicebear.com/7.x/avataaars/svg?seed=fusion'),

('indie_wave', '$2b$10$VfMVfkts5jGZ5ZWayBVYne5ZCiKvEXQfAxSVyKfvrn9KepehKmyaG', 'hello@indiewave.com', 
 'Jessica Smith', 'label', 'active', NOW() - INTERVAL '30 days', 'Indie Wave Records', 
 '{"canCreateReleases": true, "canManageArtists": true, "canViewAnalytics": true, "canManageDistribution": true, 
   "canManageRoyalties": true, "canEditMetadata": true, "canAccessFinancials": true, "canInviteUsers": true}', 'TMLBL003',
 'https://api.dicebear.com/7.x/avataaars/svg?seed=indie');

-- Artist Manager users (2)
INSERT INTO users (username, password, email, full_name, role, status, created_at, entity_name, permissions, client_id, avatar_url)
VALUES 
('pulse_mgmt', '$2b$10$VfMVfkts5jGZ5ZWayBVYne5ZCiKvEXQfAxSVyKfvrn9KepehKmyaG', 'contact@pulsemanagement.com', 
 'Alex Carter', 'artist_manager', 'active', NOW() - INTERVAL '40 days', 'Pulse Artist Management', 
 '{"canCreateReleases": true, "canManageArtists": true, "canViewAnalytics": true, "canManageDistribution": true, 
   "canManageRoyalties": true, "canEditMetadata": true, "canAccessFinancials": true, "canInviteUsers": false}', 'TMAMG001',
 'https://api.dicebear.com/7.x/avataaars/svg?seed=pulse'),

('nova_talent', '$2b$10$VfMVfkts5jGZ5ZWayBVYne5ZCiKvEXQfAxSVyKfvrn9KepehKmyaG', 'info@novatalent.com', 
 'Emma Wilson', 'artist_manager', 'active', NOW() - INTERVAL '35 days', 'Nova Talent Agency', 
 '{"canCreateReleases": true, "canManageArtists": true, "canViewAnalytics": true, "canManageDistribution": true, 
   "canManageRoyalties": true, "canEditMetadata": true, "canAccessFinancials": true, "canInviteUsers": false}', 'TMAMG002',
 'https://api.dicebear.com/7.x/avataaars/svg?seed=nova');

-- Artist users (5)
INSERT INTO users (username, password, email, full_name, role, status, created_at, entity_name, permissions, client_id, avatar_url)
VALUES 
('lunar_echo', '$2b$10$VfMVfkts5jGZ5ZWayBVYne5ZCiKvEXQfAxSVyKfvrn9KepehKmyaG', 'contact@lunarecho.com', 
 'Daniel Kim', 'artist', 'active', NOW() - INTERVAL '50 days', 'Lunar Echo', 
 '{"canCreateReleases": true, "canManageArtists": false, "canViewAnalytics": true, "canManageDistribution": true, 
   "canManageRoyalties": true, "canEditMetadata": true, "canAccessFinancials": true, "canInviteUsers": false}', 'TMART001',
 'https://api.dicebear.com/7.x/avataaars/svg?seed=lunar'),

('skyline', '$2b$10$VfMVfkts5jGZ5ZWayBVYne5ZCiKvEXQfAxSVyKfvrn9KepehKmyaG', 'music@skylineband.com', 
 'Jamie Taylor', 'artist', 'active', NOW() - INTERVAL '48 days', 'Skyline', 
 '{"canCreateReleases": true, "canManageArtists": false, "canViewAnalytics": true, "canManageDistribution": true, 
   "canManageRoyalties": true, "canEditMetadata": true, "canAccessFinancials": true, "canInviteUsers": false}', 'TMART002',
 'https://api.dicebear.com/7.x/avataaars/svg?seed=skyline'),

('neon_drift', '$2b$10$VfMVfkts5jGZ5ZWayBVYne5ZCiKvEXQfAxSVyKfvrn9KepehKmyaG', 'hello@neondrift.com', 
 'Oliver Wright', 'artist', 'active', NOW() - INTERVAL '45 days', 'Neon Drift', 
 '{"canCreateReleases": true, "canManageArtists": false, "canViewAnalytics": true, "canManageDistribution": true, 
   "canManageRoyalties": true, "canEditMetadata": true, "canAccessFinancials": true, "canInviteUsers": false}', 'TMART003',
 'https://api.dicebear.com/7.x/avataaars/svg?seed=neon'),

('crystal_voice', '$2b$10$VfMVfkts5jGZ5ZWayBVYne5ZCiKvEXQfAxSVyKfvrn9KepehKmyaG', 'management@crystalvoice.com', 
 'Sophia Lee', 'artist', 'active', NOW() - INTERVAL '40 days', 'Crystal Voice', 
 '{"canCreateReleases": true, "canManageArtists": false, "canViewAnalytics": true, "canManageDistribution": true, 
   "canManageRoyalties": true, "canEditMetadata": true, "canAccessFinancials": true, "canInviteUsers": false}', 'TMART004',
 'https://api.dicebear.com/7.x/avataaars/svg?seed=crystal'),

('digital_nomad', '$2b$10$VfMVfkts5jGZ5ZWayBVYne5ZCiKvEXQfAxSVyKfvrn9KepehKmyaG', 'bookings@digitalnomad.com', 
 'Ryan Patel', 'artist', 'active', NOW() - INTERVAL '38 days', 'Digital Nomad', 
 '{"canCreateReleases": true, "canManageArtists": false, "canViewAnalytics": true, "canManageDistribution": true, 
   "canManageRoyalties": true, "canEditMetadata": true, "canAccessFinancials": true, "canInviteUsers": false}', 'TMART005',
 'https://api.dicebear.com/7.x/avataaars/svg?seed=digital');

-- Team members (3)
INSERT INTO users (username, password, email, full_name, role, status, created_at, parent_id, team_role, permissions, client_id, avatar_url)
VALUES 
('harmony_team1', '$2b$10$VfMVfkts5jGZ5ZWayBVYne5ZCiKvEXQfAxSVyKfvrn9KepehKmyaG', 'team1@harmonyrecords.com', 
 'Chris Wong', 'team_member', 'active', NOW() - INTERVAL '55 days', 2, 'Content Manager', 
 '{"canCreateReleases": true, "canManageArtists": false, "canViewAnalytics": true, "canManageDistribution": true, 
   "canManageRoyalties": false, "canEditMetadata": true, "canAccessFinancials": false, "canInviteUsers": false}', 'TMTEM001',
 'https://api.dicebear.com/7.x/avataaars/svg?seed=harmony1'),

('harmony_team2', '$2b$10$VfMVfkts5jGZ5ZWayBVYne5ZCiKvEXQfAxSVyKfvrn9KepehKmyaG', 'team2@harmonyrecords.com', 
 'Nicole Adams', 'team_member', 'active', NOW() - INTERVAL '52 days', 2, 'Financial Manager', 
 '{"canCreateReleases": false, "canManageArtists": false, "canViewAnalytics": true, "canManageDistribution": false, 
   "canManageRoyalties": true, "canEditMetadata": false, "canAccessFinancials": true, "canInviteUsers": false}', 'TMTEM002',
 'https://api.dicebear.com/7.x/avataaars/svg?seed=harmony2'),

('fusion_team1', '$2b$10$VfMVfkts5jGZ5ZWayBVYne5ZCiKvEXQfAxSVyKfvrn9KepehKmyaG', 'team@fusionmusic.com', 
 'Tyler Gonzalez', 'team_member', 'active', NOW() - INTERVAL '44 days', 3, 'Distribution Manager', 
 '{"canCreateReleases": false, "canManageArtists": false, "canViewAnalytics": true, "canManageDistribution": true, 
   "canManageRoyalties": false, "canEditMetadata": true, "canAccessFinancials": false, "canInviteUsers": false}', 'TMTEM003',
 'https://api.dicebear.com/7.x/avataaars/svg?seed=fusion1');

-- Pending Approval user
INSERT INTO users (username, password, email, full_name, role, status, created_at, entity_name, permissions, client_id, avatar_url)
VALUES 
('cosmic_sounds', '$2b$10$VfMVfkts5jGZ5ZWayBVYne5ZCiKvEXQfAxSVyKfvrn9KepehKmyaG', 'info@cosmicsounds.com', 
 'Aisha Johnson', 'label', 'pending_approval', NOW() - INTERVAL '5 days', 'Cosmic Sounds Records', 
 '{"canCreateReleases": true, "canManageArtists": true, "canViewAnalytics": true, "canManageDistribution": true, 
   "canManageRoyalties": true, "canEditMetadata": true, "canAccessFinancials": true, "canInviteUsers": true}', 'TMPND001',
 'https://api.dicebear.com/7.x/avataaars/svg?seed=cosmic');

-- Add account approval record
INSERT INTO account_approvals (user_id, payment_id, plan_type, requested_at, status, admin_notes)
VALUES (12, 'PAY123456789', 'label', NOW() - INTERVAL '5 days', 'pending', NULL);

-- Step 4: Add distribution platforms
INSERT INTO distribution_platforms (name, type, api_endpoint, is_active, created_at, updated_at, api_credentials)
VALUES 
('Spotify', 'streaming', 'https://api.spotify.com/v1', true, NOW(), NOW(), 
 '{"clientId": "spotify-client-id", "clientSecret": "spotify-client-secret"}'),
('Apple Music', 'streaming', 'https://api.music.apple.com/v1', true, NOW(), NOW(), 
 '{"keyId": "apple-key-id", "teamId": "apple-team-id"}'),
('Amazon Music', 'streaming', 'https://api.amazonmusic.com/v1', true, NOW(), NOW(), 
 '{"accessKey": "amazon-access-key", "secretKey": "amazon-secret-key"}'),
('YouTube Music', 'streaming', 'https://youtube.googleapis.com/youtube/v3', true, NOW(), NOW(), 
 '{"apiKey": "youtube-api-key"}'),
('Deezer', 'streaming', 'https://api.deezer.com/v1', true, NOW(), NOW(), 
 '{"apiKey": "deezer-api-key"}'),
('Tidal', 'streaming', 'https://api.tidal.com/v1', true, NOW(), NOW(), 
 '{"clientId": "tidal-client-id", "clientSecret": "tidal-client-secret"}'),
('Pandora', 'streaming', 'https://api.pandora.com/v1', true, NOW(), NOW(), 
 '{"apiKey": "pandora-api-key"}'),
('SoundCloud', 'streaming', 'https://api.soundcloud.com/v1', true, NOW(), NOW(), 
 '{"clientId": "soundcloud-client-id", "clientSecret": "soundcloud-client-secret"}');

-- Step 5: Add releases
INSERT INTO releases (user_id, title, artist_name, label_name, upc, status, type, release_date, 
                     created_at, updated_at, genre, language, copyright_year, parental_advisory,
                     content_tags, primary_genre)
VALUES 
-- Lunar Echo releases
(7, 'Echoes of Tomorrow', 'Lunar Echo', 'Harmony Records', '123456789012', 'published', 'album',
 NOW() - INTERVAL '45 days', NOW() - INTERVAL '60 days', NOW() - INTERVAL '45 days', 'Electronic', 'english',
 2024, false, '{"genres": ["electronic", "ambient", "downtempo"], "moods": ["relaxing", "introspective"], 
 "themes": ["future", "space"], "keywords": ["electronic", "ambient", "atmospheric"]}', 'electronic'),

(7, 'Digital Dreams', 'Lunar Echo', 'Harmony Records', '123456789013', 'published', 'single',
 NOW() - INTERVAL '30 days', NOW() - INTERVAL '40 days', NOW() - INTERVAL '30 days', 'Electronic', 'english',
 2024, false, '{"genres": ["electronic", "ambient"], "moods": ["dreamy", "peaceful"], 
 "themes": ["dreams", "digital age"], "keywords": ["electronic", "ambient", "atmospheric"]}', 'electronic'),

-- Skyline releases
(8, 'Urban Horizons', 'Skyline', 'Fusion Music Group', '123456789014', 'published', 'album',
 NOW() - INTERVAL '40 days', NOW() - INTERVAL '55 days', NOW() - INTERVAL '40 days', 'Pop', 'english',
 2024, false, '{"genres": ["pop", "indie pop"], "moods": ["upbeat", "energetic"], 
 "themes": ["city life", "youth"], "keywords": ["pop", "indie", "urban"]}', 'pop'),

-- Neon Drift releases
(9, 'Neon Nights', 'Neon Drift', 'Indie Wave Records', '123456789015', 'published', 'ep',
 NOW() - INTERVAL '35 days', NOW() - INTERVAL '50 days', NOW() - INTERVAL '35 days', 'Synthwave', 'english',
 2024, false, '{"genres": ["synthwave", "retrowave"], "moods": ["nostalgic", "energetic"], 
 "themes": ["night", "retro"], "keywords": ["synthwave", "retrowave", "80s"]}', 'electronic'),

-- Crystal Voice releases
(10, 'Crystalline', 'Crystal Voice', 'Harmony Records', '123456789016', 'published', 'album',
 NOW() - INTERVAL '30 days', NOW() - INTERVAL '45 days', NOW() - INTERVAL '30 days', 'Pop', 'english',
 2024, false, '{"genres": ["pop", "r&b"], "moods": ["emotional", "inspiring"], 
 "themes": ["love", "empowerment"], "keywords": ["pop", "r&b", "vocals"]}', 'pop'),

(10, 'Shattered Glass', 'Crystal Voice', 'Harmony Records', '123456789017', 'published', 'single',
 NOW() - INTERVAL '15 days', NOW() - INTERVAL '25 days', NOW() - INTERVAL '15 days', 'Pop', 'english',
 2024, false, '{"genres": ["pop", "r&b"], "moods": ["melancholic", "powerful"], 
 "themes": ["heartbreak", "strength"], "keywords": ["pop", "ballad", "emotional"]}', 'pop'),

-- Digital Nomad releases
(11, 'Wanderlust', 'Digital Nomad', 'Fusion Music Group', '123456789018', 'published', 'album',
 NOW() - INTERVAL '25 days', NOW() - INTERVAL '40 days', NOW() - INTERVAL '25 days', 'Electronic', 'english',
 2024, false, '{"genres": ["electronic", "world"], "moods": ["adventurous", "curious"], 
 "themes": ["travel", "exploration"], "keywords": ["electronic", "world music", "travel"]}', 'electronic'),

-- Pending Releases
(7, 'Lunar Eclipse', 'Lunar Echo', 'Harmony Records', '123456789019', 'pending', 'album',
 NOW() + INTERVAL '10 days', NOW() - INTERVAL '10 days', NOW() - INTERVAL '10 days', 'Electronic', 'english',
 2024, false, '{"genres": ["electronic", "ambient", "experimental"], "moods": ["mysterious", "contemplative"], 
 "themes": ["space", "eclipse"], "keywords": ["electronic", "ambient", "atmospheric"]}', 'electronic'),

(9, 'Cybernetic', 'Neon Drift', 'Indie Wave Records', '123456789020', 'draft', 'album',
 NOW() + INTERVAL '30 days', NOW() - INTERVAL '5 days', NOW() - INTERVAL '5 days', 'Synthwave', 'english',
 2024, false, '{"genres": ["synthwave", "cyberpunk"], "moods": ["futuristic", "intense"], 
 "themes": ["technology", "future"], "keywords": ["synthwave", "cyberpunk", "electronic"]}', 'electronic');

-- Step 6: Add tracks
INSERT INTO tracks (release_id, title, track_number, isrc, duration, primary_artist, featured_artists, 
                   explicit_lyrics, created_at, updated_at, status)
VALUES 
-- Tracks for "Echoes of Tomorrow"
(1, 'First Light', '1', 'USXXX2101234', '03:42', 'Lunar Echo', NULL, false, NOW() - INTERVAL '60 days', NOW() - INTERVAL '45 days', 'active'),
(1, 'Orbital Path', '2', 'USXXX2101235', '04:15', 'Lunar Echo', NULL, false, NOW() - INTERVAL '60 days', NOW() - INTERVAL '45 days', 'active'),
(1, 'Stellar Drift', '3', 'USXXX2101236', '05:21', 'Lunar Echo', NULL, false, NOW() - INTERVAL '60 days', NOW() - INTERVAL '45 days', 'active'),
(1, 'Cosmic Waves', '4', 'USXXX2101237', '04:37', 'Lunar Echo', NULL, false, NOW() - INTERVAL '60 days', NOW() - INTERVAL '45 days', 'active'),
(1, 'Nebula Dreams', '5', 'USXXX2101238', '06:12', 'Lunar Echo', NULL, false, NOW() - INTERVAL '60 days', NOW() - INTERVAL '45 days', 'active'),
(1, 'Aurora', '6', 'USXXX2101239', '03:58', 'Lunar Echo', NULL, false, NOW() - INTERVAL '60 days', NOW() - INTERVAL '45 days', 'active'),
(1, 'Celestial Bodies', '7', 'USXXX2101240', '05:45', 'Lunar Echo', NULL, false, NOW() - INTERVAL '60 days', NOW() - INTERVAL '45 days', 'active'),
(1, 'Event Horizon', '8', 'USXXX2101241', '04:30', 'Lunar Echo', NULL, false, NOW() - INTERVAL '60 days', NOW() - INTERVAL '45 days', 'active'),
(1, 'Interstellar', '9', 'USXXX2101242', '06:25', 'Lunar Echo', NULL, false, NOW() - INTERVAL '60 days', NOW() - INTERVAL '45 days', 'active'),
(1, 'Beyond Tomorrow', '10', 'USXXX2101243', '05:18', 'Lunar Echo', NULL, false, NOW() - INTERVAL '60 days', NOW() - INTERVAL '45 days', 'active'),

-- Track for "Digital Dreams"
(2, 'Digital Dreams', '1', 'USXXX2101244', '03:35', 'Lunar Echo', NULL, false, NOW() - INTERVAL '40 days', NOW() - INTERVAL '30 days', 'active'),

-- Tracks for "Urban Horizons"
(3, 'City Lights', '1', 'USXXX2101245', '03:15', 'Skyline', NULL, false, NOW() - INTERVAL '55 days', NOW() - INTERVAL '40 days', 'active'),
(3, 'Rooftop View', '2', 'USXXX2101246', '03:42', 'Skyline', NULL, false, NOW() - INTERVAL '55 days', NOW() - INTERVAL '40 days', 'active'),
(3, 'Downtown', '3', 'USXXX2101247', '03:28', 'Skyline', NULL, false, NOW() - INTERVAL '55 days', NOW() - INTERVAL '40 days', 'active'),
(3, 'Neon Streets', '4', 'USXXX2101248', '04:03', 'Skyline', NULL, false, NOW() - INTERVAL '55 days', NOW() - INTERVAL '40 days', 'active'),
(3, 'Midnight Drive', '5', 'USXXX2101249', '03:56', 'Skyline', NULL, false, NOW() - INTERVAL '55 days', NOW() - INTERVAL '40 days', 'active'),
(3, 'Urban Jungle', '6', 'USXXX2101250', '03:22', 'Skyline', NULL, false, NOW() - INTERVAL '55 days', NOW() - INTERVAL '40 days', 'active'),
(3, 'Concrete Dreams', '7', 'USXXX2101251', '04:17', 'Skyline', NULL, false, NOW() - INTERVAL '55 days', NOW() - INTERVAL '40 days', 'active'),
(3, 'Metropolitan', '8', 'USXXX2101252', '03:49', 'Skyline', NULL, false, NOW() - INTERVAL '55 days', NOW() - INTERVAL '40 days', 'active'),

-- Tracks for "Neon Nights"
(4, 'Retrowave', '1', 'USXXX2101253', '04:12', 'Neon Drift', NULL, false, NOW() - INTERVAL '50 days', NOW() - INTERVAL '35 days', 'active'),
(4, 'Synthscape', '2', 'USXXX2101254', '05:05', 'Neon Drift', NULL, false, NOW() - INTERVAL '50 days', NOW() - INTERVAL '35 days', 'active'),
(4, 'Night Drive', '3', 'USXXX2101255', '04:35', 'Neon Drift', NULL, false, NOW() - INTERVAL '50 days', NOW() - INTERVAL '35 days', 'active'),
(4, 'Neon Glow', '4', 'USXXX2101256', '03:58', 'Neon Drift', NULL, false, NOW() - INTERVAL '50 days', NOW() - INTERVAL '35 days', 'active'),
(4, '1985', '5', 'USXXX2101257', '04:22', 'Neon Drift', NULL, false, NOW() - INTERVAL '50 days', NOW() - INTERVAL '35 days', 'active'),

-- Tracks for "Crystalline"
(5, 'Crystal Clear', '1', 'USXXX2101258', '03:24', 'Crystal Voice', NULL, false, NOW() - INTERVAL '45 days', NOW() - INTERVAL '30 days', 'active'),
(5, 'Reflections', '2', 'USXXX2101259', '03:57', 'Crystal Voice', NULL, false, NOW() - INTERVAL '45 days', NOW() - INTERVAL '30 days', 'active'),
(5, 'Shimmering Light', '3', 'USXXX2101260', '04:02', 'Crystal Voice', NULL, false, NOW() - INTERVAL '45 days', NOW() - INTERVAL '30 days', 'active'),
(5, 'Transparent', '4', 'USXXX2101261', '03:36', 'Crystal Voice', NULL, false, NOW() - INTERVAL '45 days', NOW() - INTERVAL '30 days', 'active'),
(5, 'Prism', '5', 'USXXX2101262', '03:44', 'Crystal Voice', NULL, false, NOW() - INTERVAL '45 days', NOW() - INTERVAL '30 days', 'active'),
(5, 'Diamond Heart', '6', 'USXXX2101263', '04:13', 'Crystal Voice', NULL, false, NOW() - INTERVAL '45 days', NOW() - INTERVAL '30 days', 'active'),
(5, 'Clarity', '7', 'USXXX2101264', '03:28', 'Crystal Voice', NULL, false, NOW() - INTERVAL '45 days', NOW() - INTERVAL '30 days', 'active'),
(5, 'Pure', '8', 'USXXX2101265', '03:51', 'Crystal Voice', NULL, false, NOW() - INTERVAL '45 days', NOW() - INTERVAL '30 days', 'active'),
(5, 'Fragile', '9', 'USXXX2101266', '04:25', 'Crystal Voice', NULL, false, NOW() - INTERVAL '45 days', NOW() - INTERVAL '30 days', 'active'),

-- Track for "Shattered Glass"
(6, 'Shattered Glass', '1', 'USXXX2101267', '03:45', 'Crystal Voice', NULL, false, NOW() - INTERVAL '25 days', NOW() - INTERVAL '15 days', 'active'),

-- Tracks for "Wanderlust"
(7, 'Nomad', '1', 'USXXX2101268', '03:37', 'Digital Nomad', NULL, false, NOW() - INTERVAL '40 days', NOW() - INTERVAL '25 days', 'active'),
(7, 'Passport', '2', 'USXXX2101269', '04:05', 'Digital Nomad', NULL, false, NOW() - INTERVAL '40 days', NOW() - INTERVAL '25 days', 'active'),
(7, 'Backpacker', '3', 'USXXX2101270', '03:52', 'Digital Nomad', NULL, false, NOW() - INTERVAL '40 days', NOW() - INTERVAL '25 days', 'active'),
(7, 'Time Zones', '4', 'USXXX2101271', '04:21', 'Digital Nomad', NULL, false, NOW() - INTERVAL '40 days', NOW() - INTERVAL '25 days', 'active'),
(7, 'Global Citizen', '5', 'USXXX2101272', '03:45', 'Digital Nomad', NULL, false, NOW() - INTERVAL '40 days', NOW() - INTERVAL '25 days', 'active'),
(7, 'Remote', '6', 'USXXX2101273', '04:12', 'Digital Nomad', NULL, false, NOW() - INTERVAL '40 days', NOW() - INTERVAL '25 days', 'active'),
(7, 'Destination Unknown', '7', 'USXXX2101274', '05:03', 'Digital Nomad', NULL, false, NOW() - INTERVAL '40 days', NOW() - INTERVAL '25 days', 'active'),
(7, 'Wanderer', '8', 'USXXX2101275', '04:38', 'Digital Nomad', NULL, false, NOW() - INTERVAL '40 days', NOW() - INTERVAL '25 days', 'active');

-- Step 7: Add distribution records
INSERT INTO distribution_records (release_id, platform_id, status, created_at, updated_at, last_attempt)
VALUES 
-- Distributions for "Echoes of Tomorrow"
(1, 1, 'completed', NOW() - INTERVAL '45 days', NOW() - INTERVAL '45 days', NOW() - INTERVAL '45 days'),
(1, 2, 'completed', NOW() - INTERVAL '45 days', NOW() - INTERVAL '45 days', NOW() - INTERVAL '45 days'),
(1, 3, 'completed', NOW() - INTERVAL '45 days', NOW() - INTERVAL '45 days', NOW() - INTERVAL '45 days'),
(1, 4, 'completed', NOW() - INTERVAL '45 days', NOW() - INTERVAL '45 days', NOW() - INTERVAL '45 days'),
(1, 5, 'completed', NOW() - INTERVAL '45 days', NOW() - INTERVAL '45 days', NOW() - INTERVAL '45 days'),

-- Distributions for "Digital Dreams"
(2, 1, 'completed', NOW() - INTERVAL '30 days', NOW() - INTERVAL '30 days', NOW() - INTERVAL '30 days'),
(2, 2, 'completed', NOW() - INTERVAL '30 days', NOW() - INTERVAL '30 days', NOW() - INTERVAL '30 days'),
(2, 3, 'completed', NOW() - INTERVAL '30 days', NOW() - INTERVAL '30 days', NOW() - INTERVAL '30 days'),

-- Distributions for "Urban Horizons"
(3, 1, 'completed', NOW() - INTERVAL '40 days', NOW() - INTERVAL '40 days', NOW() - INTERVAL '40 days'),
(3, 2, 'completed', NOW() - INTERVAL '40 days', NOW() - INTERVAL '40 days', NOW() - INTERVAL '40 days'),
(3, 3, 'completed', NOW() - INTERVAL '40 days', NOW() - INTERVAL '40 days', NOW() - INTERVAL '40 days'),
(3, 4, 'completed', NOW() - INTERVAL '40 days', NOW() - INTERVAL '40 days', NOW() - INTERVAL '40 days'),

-- Distributions for "Neon Nights"
(4, 1, 'completed', NOW() - INTERVAL '35 days', NOW() - INTERVAL '35 days', NOW() - INTERVAL '35 days'),
(4, 2, 'completed', NOW() - INTERVAL '35 days', NOW() - INTERVAL '35 days', NOW() - INTERVAL '35 days'),
(4, 5, 'completed', NOW() - INTERVAL '35 days', NOW() - INTERVAL '35 days', NOW() - INTERVAL '35 days'),
(4, 6, 'completed', NOW() - INTERVAL '35 days', NOW() - INTERVAL '35 days', NOW() - INTERVAL '35 days'),

-- Distributions for "Crystalline"
(5, 1, 'completed', NOW() - INTERVAL '30 days', NOW() - INTERVAL '30 days', NOW() - INTERVAL '30 days'),
(5, 2, 'completed', NOW() - INTERVAL '30 days', NOW() - INTERVAL '30 days', NOW() - INTERVAL '30 days'),
(5, 3, 'completed', NOW() - INTERVAL '30 days', NOW() - INTERVAL '30 days', NOW() - INTERVAL '30 days'),
(5, 4, 'completed', NOW() - INTERVAL '30 days', NOW() - INTERVAL '30 days', NOW() - INTERVAL '30 days'),
(5, 5, 'completed', NOW() - INTERVAL '30 days', NOW() - INTERVAL '30 days', NOW() - INTERVAL '30 days'),

-- Distributions for "Shattered Glass"
(6, 1, 'completed', NOW() - INTERVAL '15 days', NOW() - INTERVAL '15 days', NOW() - INTERVAL '15 days'),
(6, 2, 'completed', NOW() - INTERVAL '15 days', NOW() - INTERVAL '15 days', NOW() - INTERVAL '15 days'),
(6, 3, 'completed', NOW() - INTERVAL '15 days', NOW() - INTERVAL '15 days', NOW() - INTERVAL '15 days'),
(6, 6, 'failed', NOW() - INTERVAL '15 days', NOW() - INTERVAL '14 days', NOW() - INTERVAL '14 days'),
(6, 7, 'processing', NOW() - INTERVAL '15 days', NOW() - INTERVAL '14 days', NOW() - INTERVAL '14 days'),

-- Distributions for "Wanderlust"
(7, 1, 'completed', NOW() - INTERVAL '25 days', NOW() - INTERVAL '25 days', NOW() - INTERVAL '25 days'),
(7, 2, 'completed', NOW() - INTERVAL '25 days', NOW() - INTERVAL '25 days', NOW() - INTERVAL '25 days'),
(7, 3, 'completed', NOW() - INTERVAL '25 days', NOW() - INTERVAL '25 days', NOW() - INTERVAL '25 days'),
(7, 4, 'completed', NOW() - INTERVAL '25 days', NOW() - INTERVAL '25 days', NOW() - INTERVAL '25 days'),
(7, 5, 'completed', NOW() - INTERVAL '25 days', NOW() - INTERVAL '25 days', NOW() - INTERVAL '25 days'),
(7, 8, 'pending', NOW() - INTERVAL '25 days', NOW() - INTERVAL '25 days', NULL);

-- Step 8: Add analytics data
INSERT INTO analytics (track_id, platform, streams, revenue, date, region, created_at, updated_at)
VALUES 
-- Analytics for Lunar Echo "First Light"
(1, 'Spotify', 12500, 50.00, NOW() - INTERVAL '44 days', 'US', NOW(), NOW()),
(1, 'Spotify', 8700, 34.80, NOW() - INTERVAL '43 days', 'US', NOW(), NOW()),
(1, 'Spotify', 9200, 36.80, NOW() - INTERVAL '42 days', 'US', NOW(), NOW()),
(1, 'Spotify', 10500, 42.00, NOW() - INTERVAL '41 days', 'US', NOW(), NOW()),
(1, 'Spotify', 11000, 44.00, NOW() - INTERVAL '40 days', 'US', NOW(), NOW()),
(1, 'Spotify', 5600, 22.40, NOW() - INTERVAL '44 days', 'UK', NOW(), NOW()),
(1, 'Spotify', 4800, 19.20, NOW() - INTERVAL '43 days', 'UK', NOW(), NOW()),
(1, 'Spotify', 5200, 20.80, NOW() - INTERVAL '42 days', 'UK', NOW(), NOW()),
(1, 'Spotify', 6100, 24.40, NOW() - INTERVAL '41 days', 'UK', NOW(), NOW()),
(1, 'Spotify', 5900, 23.60, NOW() - INTERVAL '40 days', 'UK', NOW(), NOW()),
(1, 'Apple Music', 8900, 44.50, NOW() - INTERVAL '44 days', 'US', NOW(), NOW()),
(1, 'Apple Music', 7600, 38.00, NOW() - INTERVAL '43 days', 'US', NOW(), NOW()),
(1, 'Apple Music', 8100, 40.50, NOW() - INTERVAL '42 days', 'US', NOW(), NOW()),
(1, 'Apple Music', 8800, 44.00, NOW() - INTERVAL '41 days', 'US', NOW(), NOW()),
(1, 'Apple Music', 9200, 46.00, NOW() - INTERVAL '40 days', 'US', NOW(), NOW()),

-- Analytics for Crystal Voice "Crystal Clear"
(27, 'Spotify', 18600, 74.40, NOW() - INTERVAL '29 days', 'US', NOW(), NOW()),
(27, 'Spotify', 17800, 71.20, NOW() - INTERVAL '28 days', 'US', NOW(), NOW()),
(27, 'Spotify', 19200, 76.80, NOW() - INTERVAL '27 days', 'US', NOW(), NOW()),
(27, 'Spotify', 20500, 82.00, NOW() - INTERVAL '26 days', 'US', NOW(), NOW()),
(27, 'Spotify', 21000, 84.00, NOW() - INTERVAL '25 days', 'US', NOW(), NOW()),
(27, 'Spotify', 9500, 38.00, NOW() - INTERVAL '29 days', 'UK', NOW(), NOW()),
(27, 'Spotify', 9200, 36.80, NOW() - INTERVAL '28 days', 'UK', NOW(), NOW()),
(27, 'Spotify', 9800, 39.20, NOW() - INTERVAL '27 days', 'UK', NOW(), NOW()),
(27, 'Spotify', 10100, 40.40, NOW() - INTERVAL '26 days', 'UK', NOW(), NOW()),
(27, 'Spotify', 10500, 42.00, NOW() - INTERVAL '25 days', 'UK', NOW(), NOW()),
(27, 'Apple Music', 15600, 78.00, NOW() - INTERVAL '29 days', 'US', NOW(), NOW()),
(27, 'Apple Music', 14900, 74.50, NOW() - INTERVAL '28 days', 'US', NOW(), NOW()),
(27, 'Apple Music', 16200, 81.00, NOW() - INTERVAL '27 days', 'US', NOW(), NOW()),
(27, 'Apple Music', 17500, 87.50, NOW() - INTERVAL '26 days', 'US', NOW(), NOW()),
(27, 'Apple Music', 18200, 91.00, NOW() - INTERVAL '25 days', 'US', NOW(), NOW()),

-- Analytics for Skyline "City Lights"
(12, 'Spotify', 22500, 90.00, NOW() - INTERVAL '39 days', 'US', NOW(), NOW()),
(12, 'Spotify', 23800, 95.20, NOW() - INTERVAL '38 days', 'US', NOW(), NOW()),
(12, 'Spotify', 24200, 96.80, NOW() - INTERVAL '37 days', 'US', NOW(), NOW()),
(12, 'Spotify', 25500, 102.00, NOW() - INTERVAL '36 days', 'US', NOW(), NOW()),
(12, 'Spotify', 26000, 104.00, NOW() - INTERVAL '35 days', 'US', NOW(), NOW()),
(12, 'Spotify', 11600, 46.40, NOW() - INTERVAL '39 days', 'UK', NOW(), NOW()),
(12, 'Spotify', 12800, 51.20, NOW() - INTERVAL '38 days', 'UK', NOW(), NOW()),
(12, 'Spotify', 13200, 52.80, NOW() - INTERVAL '37 days', 'UK', NOW(), NOW()),
(12, 'Spotify', 14100, 56.40, NOW() - INTERVAL '36 days', 'UK', NOW(), NOW()),
(12, 'Spotify', 13900, 55.60, NOW() - INTERVAL '35 days', 'UK', NOW(), NOW()),
(12, 'Amazon Music', 16900, 84.50, NOW() - INTERVAL '39 days', 'US', NOW(), NOW()),
(12, 'Amazon Music', 17600, 88.00, NOW() - INTERVAL '38 days', 'US', NOW(), NOW()),
(12, 'Amazon Music', 18100, 90.50, NOW() - INTERVAL '37 days', 'US', NOW(), NOW()),
(12, 'Amazon Music', 18800, 94.00, NOW() - INTERVAL '36 days', 'US', NOW(), NOW()),
(12, 'Amazon Music', 19200, 96.00, NOW() - INTERVAL '35 days', 'US', NOW(), NOW());

-- Step 9: Add royalty splits
INSERT INTO royalty_splits (release_id, recipient_user_id, role, percentage, created_at, updated_at)
VALUES 
-- Splits for "Echoes of Tomorrow"
(1, 7, 'artist', 80, NOW() - INTERVAL '60 days', NOW() - INTERVAL '60 days'),
(1, 2, 'label', 20, NOW() - INTERVAL '60 days', NOW() - INTERVAL '60 days'),

-- Splits for "Digital Dreams"
(2, 7, 'artist', 80, NOW() - INTERVAL '40 days', NOW() - INTERVAL '40 days'),
(2, 2, 'label', 20, NOW() - INTERVAL '40 days', NOW() - INTERVAL '40 days'),

-- Splits for "Urban Horizons"
(3, 8, 'artist', 75, NOW() - INTERVAL '55 days', NOW() - INTERVAL '55 days'),
(3, 3, 'label', 25, NOW() - INTERVAL '55 days', NOW() - INTERVAL '55 days'),

-- Splits for "Neon Nights"
(4, 9, 'artist', 70, NOW() - INTERVAL '50 days', NOW() - INTERVAL '50 days'),
(4, 4, 'label', 30, NOW() - INTERVAL '50 days', NOW() - INTERVAL '50 days'),

-- Splits for "Crystalline"
(5, 10, 'artist', 80, NOW() - INTERVAL '45 days', NOW() - INTERVAL '45 days'),
(5, 2, 'label', 20, NOW() - INTERVAL '45 days', NOW() - INTERVAL '45 days'),

-- Splits for "Shattered Glass"
(6, 10, 'artist', 80, NOW() - INTERVAL '25 days', NOW() - INTERVAL '25 days'),
(6, 2, 'label', 20, NOW() - INTERVAL '25 days', NOW() - INTERVAL '25 days'),

-- Splits for "Wanderlust"
(7, 11, 'artist', 75, NOW() - INTERVAL '40 days', NOW() - INTERVAL '40 days'),
(7, 3, 'label', 25, NOW() - INTERVAL '40 days', NOW() - INTERVAL '40 days');

-- Step 10: Add rights management records
INSERT INTO rights_management (release_id, ownership_type, rights_holder, territory, start_date, end_date, created_at, updated_at)
VALUES 
-- Rights for "Echoes of Tomorrow"
(1, 'original', 'Lunar Echo / Harmony Records', 'Worldwide', NOW() - INTERVAL '60 days', NOW() + INTERVAL '10 years', NOW() - INTERVAL '60 days', NOW() - INTERVAL '60 days'),

-- Rights for "Digital Dreams"
(2, 'original', 'Lunar Echo / Harmony Records', 'Worldwide', NOW() - INTERVAL '40 days', NOW() + INTERVAL '10 years', NOW() - INTERVAL '40 days', NOW() - INTERVAL '40 days'),

-- Rights for "Urban Horizons"
(3, 'original', 'Skyline / Fusion Music Group', 'Worldwide', NOW() - INTERVAL '55 days', NOW() + INTERVAL '10 years', NOW() - INTERVAL '55 days', NOW() - INTERVAL '55 days'),

-- Rights for "Neon Nights"
(4, 'original', 'Neon Drift / Indie Wave Records', 'Worldwide', NOW() - INTERVAL '50 days', NOW() + INTERVAL '10 years', NOW() - INTERVAL '50 days', NOW() - INTERVAL '50 days'),

-- Rights for "Crystalline"
(5, 'original', 'Crystal Voice / Harmony Records', 'Worldwide', NOW() - INTERVAL '45 days', NOW() + INTERVAL '10 years', NOW() - INTERVAL '45 days', NOW() - INTERVAL '45 days'),

-- Rights for "Shattered Glass"
(6, 'original', 'Crystal Voice / Harmony Records', 'Worldwide', NOW() - INTERVAL '25 days', NOW() + INTERVAL '10 years', NOW() - INTERVAL '25 days', NOW() - INTERVAL '25 days'),

-- Rights for "Wanderlust"
(7, 'original', 'Digital Nomad / Fusion Music Group', 'Worldwide', NOW() - INTERVAL '40 days', NOW() + INTERVAL '10 years', NOW() - INTERVAL '40 days', NOW() - INTERVAL '40 days');

-- Step 11: Add support tickets
INSERT INTO support_tickets (user_id, subject, message, status, priority, category, created_at, updated_at)
VALUES 
(7, 'Distribution Issue with Tidal', 'My release "Digital Dreams" has not appeared on Tidal yet although it shows as processed.', 'open', 'medium', 'distribution', NOW() - INTERVAL '20 days', NOW() - INTERVAL '20 days'),
(10, 'Royalty Payment Question', 'I have not received my royalty payment for last month. Can you check this?', 'in_progress', 'high', 'billing', NOW() - INTERVAL '15 days', NOW() - INTERVAL '15 days'),
(8, 'Metadata Update Request', 'I need to update the genre tags for my album "Urban Horizons".', 'closed', 'low', 'content', NOW() - INTERVAL '30 days', NOW() - INTERVAL '10 days'),
(9, 'Account Access Issue', 'I cannot access my analytics dashboard. It gives me an error.', 'open', 'medium', 'technical', NOW() - INTERVAL '5 days', NOW() - INTERVAL '5 days'),
(11, 'Release Takedown Request', 'I need to temporarily take down one of my tracks for remixing.', 'waiting', 'medium', 'distribution', NOW() - INTERVAL '8 days', NOW() - INTERVAL '8 days');

-- Step 12: Add support ticket messages
INSERT INTO support_ticket_messages (ticket_id, sender_id, sender_type, content, created_at)
VALUES 
(1, 7, 'user', 'My release "Digital Dreams" has not appeared on Tidal yet although it shows as processed. Can you check what might be causing the delay?', NOW() - INTERVAL '20 days'),
(1, 1, 'admin', 'Thank you for reporting this issue. I checked with Tidal and there appears to be a delay in their ingestion system. They have confirmed receipt of your release and it should appear within 24-48 hours.', NOW() - INTERVAL '19 days'),
(1, 7, 'user', 'Thank you for checking. I will wait and let you know if it doesn''t appear by then.', NOW() - INTERVAL '18 days'),

(2, 10, 'user', 'I have not received my royalty payment for last month. My dashboard shows earnings but nothing has been transferred to my account.', NOW() - INTERVAL '15 days'),
(2, 1, 'admin', 'I apologize for the inconvenience. I can see that the payment was initiated but may have been delayed. Let me check with our finance department and get back to you.', NOW() - INTERVAL '14 days'),
(2, 1, 'admin', 'Our finance team confirmed that there was a processing delay with the payment provider. The payment has been re-initiated and should reach your account within 3 business days.', NOW() - INTERVAL '13 days'),
(2, 10, 'user', 'Thank you for looking into this. I''ll keep an eye on my account.', NOW() - INTERVAL '12 days'),

(3, 8, 'user', 'I need to update the genre tags for my album "Urban Horizons". It should be classified as Indie Pop rather than just Pop.', NOW() - INTERVAL '30 days'),
(3, 1, 'admin', 'We can certainly help with that. I''ve updated the genre tags for your release. The changes should propagate to the streaming platforms within 3-5 business days.', NOW() - INTERVAL '28 days'),
(3, 8, 'user', 'Great, thank you for the quick help!', NOW() - INTERVAL '27 days'),
(3, 1, 'admin', 'You''re welcome! I''ve confirmed that the changes have been accepted by all platforms. Is there anything else you need help with?', NOW() - INTERVAL '20 days'),
(3, 8, 'user', 'No, that''s all. Thanks again!', NOW() - INTERVAL '19 days'),
(3, 1, 'system', 'This ticket has been marked as resolved and closed.', NOW() - INTERVAL '10 days'),

(4, 9, 'user', 'I cannot access my analytics dashboard. It gives me an error saying "Failed to load data".', NOW() - INTERVAL '5 days'),
(4, 1, 'admin', 'I''m sorry you''re experiencing this issue. Could you please provide some additional information? Which browser are you using, and have you tried clearing your cache?', NOW() - INTERVAL '4 days'),
(4, 9, 'user', 'I''m using Chrome, and yes, I tried clearing the cache but still get the same error.', NOW() - INTERVAL '3 days'),
(4, 1, 'admin', 'Thank you for the information. Our technical team is investigating this issue. We''ve found similar reports from other users and are working on a fix. I''ll update you as soon as we have more information.', NOW() - INTERVAL '2 days'),

(5, 11, 'user', 'I need to temporarily take down one of my tracks for remixing. It''s "Nomad" from my "Wanderlust" album.', NOW() - INTERVAL '8 days'),
(5, 1, 'admin', 'We can help with this takedown request. Before proceeding, please note that takedowns can take 3-7 business days to process across all platforms. Also, some streaming history and playlists may be lost when you re-upload. Would you like to proceed?', NOW() - INTERVAL '7 days'),
(5, 11, 'user', 'I understand the implications. Yes, please proceed with the takedown.', NOW() - INTERVAL '6 days'),
(5, 1, 'admin', 'Thank you for confirming. I''ve initiated the takedown request for your track "Nomad". We''re now waiting for confirmation from the platforms. I''ll update you once we receive responses.', NOW() - INTERVAL '5 days'),
(5, 1, 'system', 'This ticket is waiting for platform responses and has been marked as waiting.', NOW() - INTERVAL '5 days');

-- Step 13: Add permission templates
INSERT INTO permission_templates (name, description, permissions, is_default, created_at, updated_at)
VALUES 
('Full Access', 'Complete access to all features and functionality', 
 '{"canCreateReleases": true, "canManageArtists": true, "canViewAnalytics": true, "canManageDistribution": true, 
   "canManageRoyalties": true, "canEditMetadata": true, "canAccessFinancials": true, "canInviteUsers": true}', 
 true, NOW(), NOW()),

('Content Manager', 'Can manage releases and content but not financials', 
 '{"canCreateReleases": true, "canManageArtists": false, "canViewAnalytics": true, "canManageDistribution": true, 
   "canManageRoyalties": false, "canEditMetadata": true, "canAccessFinancials": false, "canInviteUsers": false}', 
 false, NOW(), NOW()),

('Finance Manager', 'Can access financial information and royalties', 
 '{"canCreateReleases": false, "canManageArtists": false, "canViewAnalytics": true, "canManageDistribution": false, 
   "canManageRoyalties": true, "canEditMetadata": false, "canAccessFinancials": true, "canInviteUsers": false}', 
 false, NOW(), NOW()),

('Distribution Manager', 'Focused on distributing and managing content across platforms', 
 '{"canCreateReleases": false, "canManageArtists": false, "canViewAnalytics": true, "canManageDistribution": true, 
   "canManageRoyalties": false, "canEditMetadata": true, "canAccessFinancials": false, "canInviteUsers": false}', 
 false, NOW(), NOW()),

('Viewer', 'Read-only access to catalog and basic analytics', 
 '{"canCreateReleases": false, "canManageArtists": false, "canViewAnalytics": true, "canManageDistribution": false, 
   "canManageRoyalties": false, "canEditMetadata": false, "canAccessFinancials": false, "canInviteUsers": false}', 
 false, NOW(), NOW());

-- Step 14: Add daily stats for aggregated metrics
INSERT INTO daily_stats (date, total_streams, total_revenue, platform_breakdown, region_breakdown, created_at, updated_at)
VALUES 
(NOW() - INTERVAL '44 days', 56200, 225.50, 
 '{"Spotify": 31800, "Apple Music": 24400}', 
 '{"US": 42200, "UK": 14000}', 
 NOW(), NOW()),

(NOW() - INTERVAL '43 days', 51600, 206.40, 
 '{"Spotify": 29100, "Apple Music": 22500}', 
 '{"US": 38500, "UK": 13100}', 
 NOW(), NOW()),

(NOW() - INTERVAL '42 days', 54200, 216.60, 
 '{"Spotify": 30500, "Apple Music": 23700}', 
 '{"US": 40300, "UK": 13900}', 
 NOW(), NOW()),

(NOW() - INTERVAL '41 days', 58000, 232.00, 
 '{"Spotify": 32700, "Apple Music": 25300}', 
 '{"US": 43400, "UK": 14600}', 
 NOW(), NOW()),

(NOW() - INTERVAL '40 days', 59800, 239.60, 
 '{"Spotify": 33700, "Apple Music": 26100}', 
 '{"US": 44900, "UK": 14900}', 
 NOW(), NOW()),

(NOW() - INTERVAL '39 days', 62600, 250.40, 
 '{"Spotify": 34100, "Amazon Music": 16900, "Apple Music": 11600}', 
 '{"US": 39400, "UK": 23200}', 
 NOW(), NOW()),

(NOW() - INTERVAL '38 days', 66000, 264.00, 
 '{"Spotify": 36600, "Amazon Music": 17600, "Apple Music": 11800}', 
 '{"US": 41400, "UK": 24600}', 
 NOW(), NOW()),

(NOW() - INTERVAL '37 days', 68500, 274.00, 
 '{"Spotify": 37400, "Amazon Music": 18100, "Apple Music": 13000}', 
 '{"US": 42300, "UK": 26200}', 
 NOW(), NOW()),

(NOW() - INTERVAL '36 days', 71400, 285.60, 
 '{"Spotify": 39600, "Amazon Music": 18800, "Apple Music": 13000}', 
 '{"US": 44300, "UK": 27100}', 
 NOW(), NOW()),

(NOW() - INTERVAL '35 days', 72300, 289.20, 
 '{"Spotify": 39900, "Amazon Music": 19200, "Apple Music": 13200}', 
 '{"US": 45200, "UK": 27100}', 
 NOW(), NOW()),

(NOW() - INTERVAL '29 days', 85100, 340.00, 
 '{"Spotify": 59600, "Apple Music": 15600, "Amazon Music": 9900}', 
 '{"US": 65100, "UK": 20000}', 
 NOW(), NOW()),

(NOW() - INTERVAL '28 days', 82100, 328.00, 
 '{"Spotify": 57100, "Apple Music": 14900, "Amazon Music": 10100}', 
 '{"US": 62700, "UK": 19400}', 
 NOW(), NOW()),

(NOW() - INTERVAL '27 days', 88000, 352.00, 
 '{"Spotify": 61400, "Apple Music": 16200, "Amazon Music": 10400}', 
 '{"US": 67500, "UK": 20500}', 
 NOW(), NOW()),

(NOW() - INTERVAL '26 days', 92700, 370.00, 
 '{"Spotify": 64100, "Apple Music": 17500, "Amazon Music": 11100}', 
 '{"US": 71300, "UK": 21400}', 
 NOW(), NOW()),

(NOW() - INTERVAL '25 days', 95300, 381.00, 
 '{"Spotify": 66100, "Apple Music": 18200, "Amazon Music": 11000}', 
 '{"US": 73400, "UK": 21900}', 
 NOW(), NOW()),

(NOW() - INTERVAL '15 days', 42500, 170.00, 
 '{"Spotify": 28600, "Apple Music": 13900}', 
 '{"US": 31800, "UK": 10700}', 
 NOW(), NOW()),

(NOW() - INTERVAL '14 days', 44100, 176.40, 
 '{"Spotify": 29800, "Apple Music": 14300}', 
 '{"US": 33000, "UK": 11100}', 
 NOW(), NOW()),

(NOW() - INTERVAL '13 days', 43800, 175.20, 
 '{"Spotify": 29500, "Apple Music": 14300}', 
 '{"US": 32700, "UK": 11100}', 
 NOW(), NOW()),

(NOW() - INTERVAL '12 days', 45200, 180.80, 
 '{"Spotify": 30600, "Apple Music": 14600}', 
 '{"US": 33800, "UK": 11400}', 
 NOW(), NOW()),

(NOW() - INTERVAL '11 days', 46500, 186.00, 
 '{"Spotify": 31400, "Apple Music": 15100}', 
 '{"US": 34800, "UK": 11700}', 
 NOW(), NOW()),

(NOW() - INTERVAL '10 days', 48200, 192.80, 
 '{"Spotify": 32500, "Apple Music": 15700}', 
 '{"US": 36100, "UK": 12100}', 
 NOW(), NOW()),

(NOW() - INTERVAL '9 days', 47800, 191.20, 
 '{"Spotify": 32200, "Apple Music": 15600}', 
 '{"US": 35800, "UK": 12000}', 
 NOW(), NOW()),

(NOW() - INTERVAL '8 days', 49500, 198.00, 
 '{"Spotify": 33400, "Apple Music": 16100}', 
 '{"US": 37000, "UK": 12500}', 
 NOW(), NOW()),

(NOW() - INTERVAL '7 days', 50200, 200.80, 
 '{"Spotify": 33800, "Apple Music": 16400}', 
 '{"US": 37600, "UK": 12600}', 
 NOW(), NOW()),

(NOW() - INTERVAL '6 days', 51800, 207.20, 
 '{"Spotify": 34900, "Apple Music": 16900}', 
 '{"US": 38800, "UK": 13000}', 
 NOW(), NOW()),

(NOW() - INTERVAL '5 days', 52500, 210.00, 
 '{"Spotify": 35400, "Apple Music": 17100}', 
 '{"US": 39300, "UK": 13200}', 
 NOW(), NOW()),

(NOW() - INTERVAL '4 days', 53800, 215.20, 
 '{"Spotify": 36200, "Apple Music": 17600}', 
 '{"US": 40300, "UK": 13500}', 
 NOW(), NOW()),

(NOW() - INTERVAL '3 days', 54500, 218.00, 
 '{"Spotify": 36700, "Apple Music": 17800}', 
 '{"US": 40800, "UK": 13700}', 
 NOW(), NOW()),

(NOW() - INTERVAL '2 days', 55200, 220.80, 
 '{"Spotify": 37200, "Apple Music": 18000}', 
 '{"US": 41400, "UK": 13800}', 
 NOW(), NOW()),

(NOW() - INTERVAL '1 day', 56100, 224.40, 
 '{"Spotify": 37800, "Apple Music": 18300}', 
 '{"US": 42000, "UK": 14100}', 
 NOW(), NOW());