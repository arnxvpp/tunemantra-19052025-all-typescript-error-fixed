/**
 * Database Test for Rights Records
 * 
 * Simple test to create a rights record in the database
 * 
 * USAGE: npx tsx scripts/db-test.ts
 */

import { createRightsRecord } from '../server/services/db-helpers';

async function testDatabaseInsert() {
  try {
    console.log("Testing direct rights record insertion to database...");
    
    // Create a simple rights record directly in the database
    const result = await createRightsRecord({
      assetId: "DIRECT_DB_TEST_" + Date.now(),
      assetType: "track",
      rightsType: "master",
      ownerType: "artist",
      ownerId: 1,
      ownerAddress: "0x1234567890123456789012345678901234567890",
      percentage: 100,
      startDate: new Date(),
      endDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000),
      territories: ["global"],
      blockchainNetworkId: "mumbai",
      verificationStatus: "pending"
    });
    
    console.log("Direct database insertion successful!");
    console.log("Inserted record:", result);
    
    return result;
  } catch (error) {
    console.error("Error with direct database insertion:");
    if (error instanceof Error) {
      console.error(`   Message: ${error.message}`);
      console.error(`   Stack: ${error.stack}`);
    } else {
      console.error(error);
    }
    
    return null;
  }
}

// Run the test
testDatabaseInsert()
  .then(() => console.log("Test completed."))
  .catch(err => console.error("Test failed:", err));