# TuneMantra Testing Scripts

This directory contains comprehensive testing scripts for validating all aspects of the TuneMantra platform.

## Quick Start

For a complete blockchain test run:

```bash
# Set up environment variables
npx tsx setup-blockchain-env.ts

# Run all blockchain tests
npx tsx complete-blockchain-test-suite.ts

# Run all tests across the platform
npx tsx master-test-runner.ts
```

## Testing Scripts Overview

### Core Test Suites

- **complete-blockchain-test-suite.ts** - Comprehensive blockchain functionality tests
- **master-test-runner.ts** - Run all test suites and generate reports
- **production-readiness-check.ts** - Verify production deployment readiness

### Setup Scripts

- **setup-blockchain-env.ts** - Configure environment variables for blockchain testing
- **setup-test-database.ts** - Initialize test database schema
- **setup-missing-tables.ts** - Create any missing database tables

### Component-Specific Tests

- **blockchain-simulator.ts** - Simulate blockchain operations
- **blockchain-verification-test.ts** - Test rights verification
- **test-blockchain-connector.ts** - Test blockchain connector service
- **blockchain-debug.ts** - Debug blockchain connection issues
- **blockchain-debug-modified.ts** - Enhanced debugging for blockchain
- **test-rights-management.ts** - Test rights management functionality
- **test-rights-verification.ts** - Test rights verification flows
- **test-royalty-calculation.ts** - Test royalty calculations

### Utilities

- **db-utils.ts** - Database helper functions for tests
- **utils.ts** - General testing utilities
- **test-framework.ts** - Testing framework foundations

## Detailed Documentation

For detailed information on testing blockchain functionality, refer to the [Blockchain Testing Guide](../documentation/technical/blockchain-testing-guide.md) in the documentation directory.

## Production Validation

Before deploying to production, run the production readiness check:

```bash
npx tsx production-readiness-check.ts
```

This will verify all components are properly configured for production deployment.