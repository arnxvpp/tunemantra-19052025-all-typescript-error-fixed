/**
 * Verify Database Content Script
 * 
 * This script checks the content of the database tables to verify data integrity
 * and confirm that test data has been correctly created and modified.
 * 
 * Usage: npx tsx scripts/verify-database.ts
 */

import { executeQuery } from '../server/db';
import * as dbUtils from './db-utils';

/**
 * Check tables and record counts
 */
async function checkTables() {
  console.log('Checking database tables...\n');
  
  const tables = [
    'users', 
    'tracks', 
    'blockchain_nfts', 
    'user_wallets', 
    'rights', 
    'rights_records', 
    'rights_conflicts', 
    'rights_transfers'
  ];
  
  console.log('Table | Records');
  console.log('-------------');
  
  for (const table of tables) {
    const exists = await dbUtils.tableExists(table);
    
    if (exists) {
      const count = await dbUtils.countRecords(table);
      console.log(`${table.padEnd(20)} | ${count}`);
    } else {
      console.log(`${table.padEnd(20)} | Table doesn't exist`);
    }
  }
}

/**
 * Check blockchain NFTs in database
 */
async function checkBlockchainNFTs() {
  console.log('\nChecking blockchain NFTs...');
  
  try {
    const nfts = await executeQuery('SELECT * FROM blockchain_nfts');
    
    if (nfts.rows.length === 0) {
      console.log('No blockchain NFTs found in database.');
      return;
    }
    
    console.log(`Found ${nfts.rows.length} blockchain NFTs:`);
    
    for (const nft of nfts.rows) {
      console.log(`\nNFT ID: ${nft.id}`);
      console.log(`Token ID: ${nft.token_id}`);
      console.log(`Track ID: ${nft.track_id}`);
      console.log(`User ID: ${nft.user_id}`);
      console.log(`Network: ${nft.network_id}`);
      console.log(`Status: ${nft.status}`);
      console.log(`Created: ${nft.created_at}`);
      
      // If metadata exists, display some of it
      if (nft.metadata) {
        try {
          const metadata = typeof nft.metadata === 'string' 
            ? JSON.parse(nft.metadata) 
            : nft.metadata;
          
          console.log('Metadata:');
          console.log(`  Name: ${metadata.name || 'N/A'}`);
          console.log(`  Artist: ${metadata.artist || 'N/A'}`);
          console.log(`  Image: ${metadata.image || 'N/A'}`);
        } catch (e) {
          console.log('Error parsing metadata', e);
        }
      }
    }
  } catch (error) {
    console.error('Error checking blockchain NFTs:', error);
  }
}

/**
 * Check rights records in database
 */
async function checkRightsRecords() {
  console.log('\nChecking rights records...');
  
  try {
    const rights = await executeQuery('SELECT * FROM rights_records');
    
    if (rights.rows.length === 0) {
      console.log('No rights records found in database.');
      return;
    }
    
    console.log(`Found ${rights.rows.length} rights records:`);
    
    for (const right of rights.rows) {
      console.log(`\nRight ID: ${right.id}`);
      console.log(`Asset ID: ${right.asset_id}`);
      console.log(`Rights Type: ${right.rights_type}`);
      console.log(`Owner ID: ${right.owner_id}`);
      console.log(`Percentage: ${right.percentage}%`);
      console.log(`Territory: ${right.territory}`);
      console.log(`Status: ${right.verification_status}`);
    }
  } catch (error) {
    console.error('Error checking rights records:', error);
  }
}

/**
 * Main function to run verifications
 */
async function runVerifications() {
  console.log('Starting database verification...\n');
  
  try {
    await checkTables();
    await checkBlockchainNFTs();
    await checkRightsRecords();
    
    console.log('\nVerification completed successfully.');
  } catch (error) {
    console.error('Verification error:', error);
  } finally {
    // Close DB connection
    await dbUtils.closeDatabase();
  }
}

// Run the verification
runVerifications();