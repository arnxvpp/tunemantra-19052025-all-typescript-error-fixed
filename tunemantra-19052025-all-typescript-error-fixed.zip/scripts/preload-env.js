// scripts/preload-env.js
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

// Determine the root directory based on the script's location
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..'); // Go up one level from scripts/

// Determine the correct .env file path
const envPath = process.env.NODE_ENV === 'production'
  ? path.resolve(rootDir, '.env.production')
  : path.resolve(rootDir, '.env.development');

// Load the environment variables
const result = dotenv.config({ path: envPath });

if (result.error) {
  // Attempt to load the default .env file if the specific one fails or NODE_ENV is not set
  console.warn(`Could not load ${path.basename(envPath)}, attempting to load default .env file.`);
  dotenv.config({ path: path.resolve(rootDir, '.env') });
}

// Set NODE_ENV to 'development' if it's not already set,
// ensuring the correct file is loaded by default in dev environments.
if (!process.env.NODE_ENV) {
  process.env.NODE_ENV = 'development';
  console.log("NODE_ENV not set, defaulting to 'development'.");
  // Reload env vars if NODE_ENV was just set to development
   dotenv.config({ path: path.resolve(rootDir, '.env.development'), override: true });
}

console.log(`Preloaded environment variables from: ${process.env.NODE_ENV === 'production' ? '.env.production' : '.env.development'}`);
// Add a check to confirm DATABASE_URL is loaded after config
if (!process.env.DATABASE_URL) {
    console.error("preload-env.js: DATABASE_URL is still not set after dotenv.config()");
} else {
    console.log("preload-env.js: DATABASE_URL successfully loaded.");
}