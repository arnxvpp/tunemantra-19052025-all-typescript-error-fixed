/**
 * TuneMantra Testing Framework
 * 
 * A unified testing framework for validating rights management, blockchain integration,
 * and security across the TuneMantra platform.
 * 
 * This framework provides:
 * 1. Common test utilities and assertions
 * 2. Environment setup and teardown
 * 3. Reporting for test results
 * 4. Fixtures for repeatable test data
 */

import pkg from 'pg';
const { Pool } = pkg;
import * as dotenv from 'dotenv';
import * as fs from 'fs';
import * as path from 'path';
import { performance } from 'perf_hooks';

// Load environment variables from .env file
dotenv.config();

// Define test types
export type TestResult = {
  name: string;
  passed: boolean;
  error?: Error;
  duration: number;
  details?: any;
};

export type TestSuite = {
  name: string;
  tests: TestResult[];
  startTime: number;
  endTime?: number;
  duration?: number;
  passed?: boolean;
};

// Create database connection pool
export const dbPool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

// Test reporting
export class TestReporter {
  private suites: TestSuite[] = [];
  private currentSuite: TestSuite | null = null;
  private startTime: number = 0;
  private logFile: string;

  constructor(outputDir: string = 'test-results') {
    this.startTime = Date.now();
    
    // Create output directory if it doesn't exist
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir, { recursive: true });
    }
    
    // Create log file
    const timestamp = new Date().toISOString().replace(/:/g, '-');
    this.logFile = path.join(outputDir, `test-run-${timestamp}.log`);
    
    // Initialize log file
    fs.writeFileSync(this.logFile, `Test Run Started: ${new Date().toISOString()}\n\n`);
    
    this.log('Test framework initialized');
  }

  startSuite(name: string): void {
    if (this.currentSuite) {
      this.endSuite();
    }
    
    this.currentSuite = {
      name,
      tests: [],
      startTime: Date.now(),
    };
    
    this.log(`Starting test suite: ${name}`);
  }

  endSuite(): void {
    if (!this.currentSuite) {
      throw new Error('No test suite is currently running');
    }
    
    this.currentSuite.endTime = Date.now();
    this.currentSuite.duration = this.currentSuite.endTime - this.currentSuite.startTime;
    
    // Calculate pass status
    const totalTests = this.currentSuite.tests.length;
    const passedTests = this.currentSuite.tests.filter(test => test.passed).length;
    this.currentSuite.passed = passedTests === totalTests;
    
    this.log(`Ending test suite: ${this.currentSuite.name}`);
    this.log(`Results: ${passedTests}/${totalTests} tests passed`);
    this.log(`Duration: ${this.currentSuite.duration}ms`);
    
    this.suites.push(this.currentSuite);
    this.currentSuite = null;
  }

  recordTest(result: TestResult): void {
    if (!this.currentSuite) {
      throw new Error('No test suite is currently running');
    }
    
    this.currentSuite.tests.push(result);
    
    const status = result.passed ? 'PASS' : 'FAIL';
    this.log(`Test: ${result.name} - ${status} (${result.duration}ms)`);
    
    if (!result.passed && result.error) {
      this.log(`  Error: ${result.error.message}`);
      if (result.error.stack) {
        this.log(`  Stack: ${result.error.stack}`);
      }
    }
    
    if (result.details) {
      this.log(`  Details: ${JSON.stringify(result.details, null, 2)}`);
    }
  }

  getSummary(): any {
    const totalSuites = this.suites.length;
    const passedSuites = this.suites.filter(suite => suite.passed).length;
    
    const totalTests = this.suites.reduce((sum, suite) => sum + suite.tests.length, 0);
    const passedTests = this.suites.reduce(
      (sum, suite) => sum + suite.tests.filter(test => test.passed).length, 
      0
    );
    
    const totalDuration = Date.now() - this.startTime;
    
    return {
      totalSuites,
      passedSuites,
      totalTests,
      passedTests,
      totalDuration,
      passed: passedSuites === totalSuites,
    };
  }

  logSummary(): void {
    const summary = this.getSummary();
    
    this.log('\n=== TEST SUMMARY ===');
    this.log(`Suites: ${summary.passedSuites}/${summary.totalSuites} passed`);
    this.log(`Tests: ${summary.passedTests}/${summary.totalTests} passed`);
    this.log(`Total Duration: ${summary.totalDuration}ms`);
    this.log(`Overall Result: ${summary.passed ? 'PASSED' : 'FAILED'}`);
    
    // Write summary to CSV
    const outputDir = path.dirname(this.logFile);
    const csvFile = path.join(outputDir, 'test-summary.csv');
    
    // Check if file exists to decide whether to write headers
    const writeHeaders = !fs.existsSync(csvFile);
    
    const csvLine = [
      new Date().toISOString(),
      summary.totalSuites,
      summary.passedSuites,
      summary.totalTests,
      summary.passedTests,
      summary.totalDuration,
      summary.passed ? 'PASSED' : 'FAILED'
    ].join(',');
    
    if (writeHeaders) {
      const headers = [
        'Timestamp',
        'Total Suites',
        'Passed Suites',
        'Total Tests',
        'Passed Tests',
        'Duration (ms)',
        'Result'
      ].join(',');
      
      fs.writeFileSync(csvFile, headers + '\n' + csvLine + '\n');
    } else {
      fs.appendFileSync(csvFile, csvLine + '\n');
    }
  }

  private log(message: string): void {
    const timestamp = new Date().toISOString();
    const logMessage = `[${timestamp}] ${message}`;
    
    console.log(logMessage);
    fs.appendFileSync(this.logFile, logMessage + '\n');
  }
}

// Test runner
export async function runTest(
  reporter: TestReporter,
  name: string,
  testFn: () => Promise<void | any>
): Promise<void> {
  const startTime = performance.now();
  let passed = false;
  let error: Error | undefined;
  let details: any;
  
  try {
    details = await testFn();
    passed = true;
  } catch (err) {
    error = err instanceof Error ? err : new Error(String(err));
    passed = false;
  }
  
  const duration = performance.now() - startTime;
  
  reporter.recordTest({
    name,
    passed,
    error,
    duration,
    details,
  });
}

// Database test utilities
export async function clearTestData(tableName: string, condition?: string): Promise<void> {
  const query = condition
    ? `DELETE FROM "${tableName}" WHERE ${condition}`
    : `DELETE FROM "${tableName}"`;
  
  try {
    await dbPool.query(query);
  } catch (error) {
    console.error(`Error clearing test data from ${tableName}:`, error);
    throw error;
  }
}

export async function insertTestData<T>(tableName: string, data: T): Promise<any> {
  const keys = Object.keys(data as any);
  const values = Object.values(data as any);
  
  const placeholders = keys.map((_, i) => `$${i + 1}`).join(', ');
  const columns = keys.map(k => `"${k}"`).join(', ');
  
  const query = `
    INSERT INTO "${tableName}" (${columns})
    VALUES (${placeholders})
    RETURNING *
  `;
  
  try {
    const result = await dbPool.query(query, values);
    return result.rows[0];
  } catch (error) {
    console.error(`Error inserting test data into ${tableName}:`, error);
    throw error;
  }
}

// Cleanup function
export async function cleanup(): Promise<void> {
  await dbPool.end();
}

// HTTP test utilities
export async function makeRequest(url: string, options: RequestInit = {}): Promise<Response> {
  const baseUrl = process.env.API_BASE_URL || 'http://localhost:5000';
  const fullUrl = `${baseUrl}${url}`;
  
  try {
    const response = await fetch(fullUrl, options);
    return response;
  } catch (error) {
    console.error(`Error making request to ${fullUrl}:`, error);
    throw error;
  }
}

// Load test utilities
export async function runConcurrentRequests(
  url: string,
  options: RequestInit = {},
  concurrency: number
): Promise<{ successCount: number; failureCount: number; averageTime: number; maxTime: number }> {
  const startTime = performance.now();
  const promises: Promise<{ success: boolean; time: number }>[] = [];
  
  for (let i = 0; i < concurrency; i++) {
    promises.push(
      (async () => {
        const requestStart = performance.now();
        try {
          await makeRequest(url, options);
          return { success: true, time: performance.now() - requestStart };
        } catch (error) {
          return { success: false, time: performance.now() - requestStart };
        }
      })()
    );
  }
  
  const results = await Promise.all(promises);
  const successCount = results.filter(r => r.success).length;
  const failureCount = concurrency - successCount;
  
  const times = results.map(r => r.time);
  const totalTime = times.reduce((sum, time) => sum + time, 0);
  const averageTime = totalTime / concurrency;
  const maxTime = Math.max(...times);
  
  return {
    successCount,
    failureCount,
    averageTime,
    maxTime,
  };
}

// Blockchain test utilities
export async function mockBlockchainTransaction(): Promise<string> {
  // Generate a mock transaction hash
  const hash = '0x' + Array.from({ length: 64 }, () => 
    Math.floor(Math.random() * 16).toString(16)
  ).join('');
  
  return hash;
}

// Assertions
export function assertEqual(actual: any, expected: any, message?: string): void {
  if (actual !== expected) {
    throw new Error(message || `Expected ${expected}, but got ${actual}`);
  }
}

export function assertObjectContains(obj: any, expectedProps: any, message?: string): void {
  for (const [key, value] of Object.entries(expectedProps)) {
    if (obj[key] !== value) {
      throw new Error(
        message || `Expected object to have property ${key} with value ${value}, but got ${obj[key]}`
      );
    }
  }
}

export function assertGreaterThan(actual: number, expected: number, message?: string): void {
  if (actual <= expected) {
    throw new Error(message || `Expected ${actual} to be greater than ${expected}`);
  }
}

export function assertLessThan(actual: number, expected: number, message?: string): void {
  if (actual >= expected) {
    throw new Error(message || `Expected ${actual} to be less than ${expected}`);
  }
}

// Main test execution function
export async function runTestSuite(
  suiteName: string,
  tests: Array<{ name: string; fn: () => Promise<void | any> }>
): Promise<boolean> {
  const reporter = new TestReporter();
  
  try {
    reporter.startSuite(suiteName);
    
    for (const test of tests) {
      await runTest(reporter, test.name, test.fn);
    }
    
    reporter.endSuite();
    reporter.logSummary();
    
    const summary = reporter.getSummary();
    return summary.passed;
  } finally {
    await cleanup();
  }
}