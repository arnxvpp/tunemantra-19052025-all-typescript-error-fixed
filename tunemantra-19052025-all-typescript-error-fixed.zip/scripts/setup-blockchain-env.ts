/**
 * Blockchain Environment Setup Script
 * 
 * This script sets up the necessary environment variables for blockchain testing
 * and ensures that all required configurations are in place.
 * 
 * USAGE: npx tsx scripts/setup-blockchain-env.ts
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import readline from 'readline';
import dotenv from 'dotenv';
import colors from 'colors';

// Configure colors for terminal output
colors.enable();

// Setup file paths
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');
const devEnvPath = path.join(rootDir, '.env.development');

// Create readline interface for user input
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// Helper to prompt for user input
function prompt(question: string): Promise<string> {
  return new Promise((resolve) => {
    rl.question(question, (answer) => {
      resolve(answer);
    });
  });
}

// Main setup function
async function setupBlockchainEnvironment() {
  console.log(`\n${'='.repeat(80)}`.cyan);
  console.log(`BLOCKCHAIN ENVIRONMENT SETUP - TuneMantra Platform`.cyan.bold);
  console.log(`${'='.repeat(80)}\n`.cyan);
  
  console.log('This script will help you set up the environment variables needed for blockchain testing.');
  console.log('You can use the default simulation values or provide your own values for testing with real networks.\n');
  
  // Check if .env.development exists
  let envVars: Record<string, string> = {};
  if (fs.existsSync(devEnvPath)) {
    console.log(`Found existing environment file at: ${devEnvPath}`.green);
    dotenv.config({ path: devEnvPath });
    
    // Read existing values
    const envContent = fs.readFileSync(devEnvPath, 'utf8');
    const envLines = envContent.split('\n');
    
    for (const line of envLines) {
      if (line && !line.startsWith('#')) {
        const match = line.match(/^([^=]+)=(.*)$/);
        if (match) {
          envVars[match[1]] = match[2];
        }
      }
    }
  } else {
    console.log(`No environment file found. Creating new file: ${devEnvPath}`.yellow);
  }
  
  // Determine if we're using simulation mode
  console.log(`\n${'-'.repeat(40)}`.yellow);
  console.log('BLOCKCHAIN SIMULATION MODE'.yellow);
  console.log(`${'-'.repeat(40)}`.yellow);
  
  let useSimulation = envVars.BLOCKCHAIN_SIMULATION === 'true';
  const simulationAnswer = await prompt(`Enable blockchain simulation mode? (y/n) [${useSimulation ? 'y' : 'n'}]: `);
  if (simulationAnswer.toLowerCase() === 'y') {
    useSimulation = true;
  } else if (simulationAnswer.toLowerCase() === 'n') {
    useSimulation = false;
  }
  envVars.BLOCKCHAIN_SIMULATION = useSimulation ? 'true' : 'false';
  
  // Configure networks
  const networks = ['mumbai', 'polygon', 'ethereum', 'optimism', 'arbitrum', 'base'];
  
  for (const network of networks) {
    const upperNetwork = network.toUpperCase();
    
    console.log(`\n${'-'.repeat(40)}`.yellow);
    console.log(`${upperNetwork} NETWORK CONFIGURATION`.yellow);
    console.log(`${'-'.repeat(40)}`.yellow);
    
    const configureNetwork = await prompt(`Configure ${network} network? (y/n) [y]: `);
    if (configureNetwork.toLowerCase() === 'n') {
      continue;
    }
    
    // RPC URL
    const defaultRpcUrl = 
      envVars[`${upperNetwork}_RPC_URL`] || 
      (network === 'mumbai' ? 'https://rpc-mumbai.maticvigil.com' : '');
    
    const rpcUrl = await prompt(`${upperNetwork}_RPC_URL [${defaultRpcUrl}]: `);
    envVars[`${upperNetwork}_RPC_URL`] = rpcUrl || defaultRpcUrl;
    
    // Only ask for private key and contract addresses if simulation mode is disabled
    if (!useSimulation) {
      // Private Key (handle with care!)
      const hasPrivateKey = !!envVars[`${upperNetwork}_PRIVATE_KEY`];
      const privateKeyPrompt = hasPrivateKey 
        ? `${upperNetwork}_PRIVATE_KEY is already set. Update it? (y/n) [n]: `
        : `Enter ${upperNetwork}_PRIVATE_KEY: `;
      
      const updatePrivateKey = hasPrivateKey 
        ? (await prompt(privateKeyPrompt)).toLowerCase() === 'y'
        : true;
      
      if (updatePrivateKey) {
        console.log('⚠️  Warning: Private keys should be kept secure!'.yellow);
        const privateKey = await prompt(`Enter ${upperNetwork}_PRIVATE_KEY: `);
        if (privateKey) {
          envVars[`${upperNetwork}_PRIVATE_KEY`] = privateKey;
        }
      }
    } else {
      // In simulation mode, use a dummy private key
      envVars[`${upperNetwork}_PRIVATE_KEY`] = '0x0123456789012345678901234567890123456789012345678901234567890123';
      console.log(`Using simulation private key for ${network}`.yellow);
    }
    
    // NFT Contract Address
    const defaultNftAddress = 
      envVars[`${upperNetwork}_NFT_CONTRACT_ADDRESS`] || 
      (useSimulation ? '0x0000000000000000000000000000000000000001' : '');
    
    const nftAddress = await prompt(`${upperNetwork}_NFT_CONTRACT_ADDRESS [${defaultNftAddress}]: `);
    envVars[`${upperNetwork}_NFT_CONTRACT_ADDRESS`] = nftAddress || defaultNftAddress;
    
    // Rights Contract Address
    const defaultRightsAddress = 
      envVars[`${upperNetwork}_RIGHTS_CONTRACT_ADDRESS`] || 
      (useSimulation ? '0x0000000000000000000000000000000000000002' : '');
    
    const rightsAddress = await prompt(`${upperNetwork}_RIGHTS_CONTRACT_ADDRESS [${defaultRightsAddress}]: `);
    envVars[`${upperNetwork}_RIGHTS_CONTRACT_ADDRESS`] = rightsAddress || defaultRightsAddress;
  }
  
  // Save environment variables to .env.development
  let envContent = '# Blockchain Environment Settings (Auto-generated)\n';
  envContent += '# Created by setup-blockchain-env.ts\n\n';
  
  for (const [key, value] of Object.entries(envVars)) {
    envContent += `${key}=${value}\n`;
  }
  
  fs.writeFileSync(devEnvPath, envContent);
  console.log(`\n✅ Environment variables saved to ${devEnvPath}`.green);
  
  // Instructions for next steps
  console.log('\nNext steps:');
  console.log('1. Run the blockchain test suite: npx tsx scripts/complete-blockchain-test-suite.ts');
  console.log('2. Set BLOCKCHAIN_SIMULATION=false in .env.development when ready to test with real networks');
  
  rl.close();
}

// Run the setup
setupBlockchainEnvironment().catch(error => {
  console.error(`Error setting up blockchain environment:`.red, error);
  process.exit(1);
});