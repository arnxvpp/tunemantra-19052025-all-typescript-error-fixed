/**
 * Security Scanner for TuneMantra
 * 
 * This script scans the codebase for potentially vulnerable patterns
 * and reports them for manual review. It helps identify:
 * 
 * 1. SQL Injection vulnerabilities
 * 2. XSS vulnerabilities
 * 3. Unsafe data handling patterns
 * 4. Missing input validation
 */

import * as fs from 'fs';
import * as path from 'path';

// Define patterns to search for
const VULNERABLE_PATTERNS = [
  // SQL Injection patterns
  {
    name: 'SQL injection via array join',
    regex: /sql`.*IN \(\$\{.*\.join\(.*\)\}\)/g,
    severity: 'HIGH',
    suggestion: 'Use inArray() from Drizzle ORM instead of string join'
  },
  {
    name: 'Unsafe SQL string interpolation',
    regex: /sql`.*\$\{(?!.*\bsql\b).*\}`/g,
    severity: 'HIGH',
    suggestion: 'Use parameterized queries with Drizzle ORM'
  },
  {
    name: 'Raw SQL execution',
    regex: /\.execute\(.*\)/g,
    severity: 'MEDIUM',
    suggestion: 'Review to ensure parameters are properly sanitized'
  },
  
  // XSS patterns
  {
    name: 'Potential XSS in React',
    regex: /dangerouslySetInnerHTML/g,
    severity: 'HIGH',
    suggestion: 'Avoid dangerouslySetInnerHTML or ensure content is sanitized'
  },
  {
    name: 'Direct DOM manipulation',
    regex: /document\.write|\.innerHTML\s*=|eval\(/g,
    severity: 'HIGH',
    suggestion: 'Avoid direct DOM manipulation to prevent XSS'
  },
  
  // CSRF patterns
  {
    name: 'Missing CSRF token validation',
    regex: /fetch\(.*method:\s*["'](?:POST|PUT|DELETE)["']/g,
    severity: 'MEDIUM',
    suggestion: 'Ensure CSRF token is included in request headers'
  },
  
  // Input validation patterns
  {
    name: 'Missing input validation',
    regex: /req\.body\./g,
    severity: 'MEDIUM',
    suggestion: 'Ensure input is validated with Zod before processing'
  }
];

// Extensions to scan
const FILE_EXTENSIONS = ['.ts', '.tsx', '.js', '.jsx'];

// Directories to skip
const SKIP_DIRECTORIES = ['node_modules', 'dist', 'build', '.git'];

// Total issues found
let totalIssues = 0;

// Function to scan a file
function scanFile(filePath: string): void {
  try {
    const content = fs.readFileSync(filePath, 'utf8');
    let fileHasIssues = false;
    
    VULNERABLE_PATTERNS.forEach(pattern => {
      const matches = content.match(pattern.regex);
      
      if (matches && matches.length > 0) {
        if (!fileHasIssues) {
          console.log(`\n\x1b[1m${filePath}\x1b[0m`);
          fileHasIssues = true;
        }
        
        console.log(`  \x1b[${pattern.severity === 'HIGH' ? '31' : '33'}m[${pattern.severity}]\x1b[0m ${pattern.name}`);
        
        // Get line numbers for each match
        matches.forEach(match => {
          const lines = content.split('\n');
          let lineNum = 0;
          let charCount = 0;
          
          for (let i = 0; i < lines.length; i++) {
            charCount += lines[i].length + 1; // +1 for the newline
            if (charCount > content.indexOf(match)) {
              lineNum = i + 1;
              break;
            }
          }
          
          console.log(`    Line ${lineNum}: ${match.slice(0, 100)}${match.length > 100 ? '...' : ''}`);
          console.log(`    \x1b[32mSuggestion: ${pattern.suggestion}\x1b[0m`);
        });
        
        totalIssues += matches.length;
      }
    });
  } catch (error) {
    console.error(`Error scanning file ${filePath}:`, error);
  }
}

// Function to scan a directory recursively
function scanDirectory(dir: string): void {
  try {
    const files = fs.readdirSync(dir);
    
    files.forEach(file => {
      const fullPath = path.join(dir, file);
      
      try {
        const stats = fs.statSync(fullPath);
        
        if (stats.isDirectory() && !SKIP_DIRECTORIES.includes(file)) {
          scanDirectory(fullPath);
        } else if (stats.isFile() && FILE_EXTENSIONS.includes(path.extname(fullPath))) {
          scanFile(fullPath);
        }
      } catch (error) {
        console.error(`Error processing ${fullPath}:`, error);
      }
    });
  } catch (error) {
    console.error(`Error reading directory ${dir}:`, error);
  }
}

// Main function
function main(): void {
  console.log('\x1b[1m\x1b[36mTuneMantra Security Scanner\x1b[0m');
  console.log('Scanning for security vulnerabilities...\n');
  
  const startTime = Date.now();
  
  // Scan server and client directories
  scanDirectory('./server');
  scanDirectory('./client');
  
  const duration = ((Date.now() - startTime) / 1000).toFixed(2);
  
  console.log(`\n\x1b[1mScan completed in ${duration}s\x1b[0m`);
  console.log(`\x1b[${totalIssues > 0 ? '31' : '32'}mFound ${totalIssues} potential security issues\x1b[0m`);
  
  if (totalIssues > 0) {
    console.log('\nReview these issues and fix them using our established patterns.');
    console.log('For SQL injection: Use Drizzle\'s inArray() and parameterized queries');
    console.log('For XSS: Use the sanitizeObject utility from server/middleware/security.ts');
    console.log('For CSRF: Ensure all state-changing requests include the CSRF token');
    console.log('For input validation: Use Zod schemas for validation before processing');
  } else {
    console.log('\nNo security issues found! Great job on maintaining a secure codebase.');
  }
}

// Run the scanner
main();