/**
 * Database Setup Script for Tests
 * 
 * This script creates missing tables needed for the testing scripts
 * including user_wallets, rights tables, and ensures all dependencies exist.
 * 
 * Usage: npx tsx scripts/setup-test-database.ts
 */

import { db, pool } from '../server/db';

/**
 * Main function to setup database tables for testing
 */
async function setupDatabase() {
  console.log('Starting database setup for tests...');
  
  try {
    // Create user_wallets table if not exists
    await db.execute(`
      CREATE TABLE IF NOT EXISTS user_wallets (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL,
        address TEXT NOT NULL,
        wallet_type TEXT NOT NULL,
        default_wallet BOOLEAN NOT NULL DEFAULT false,
        created_at TIMESTAMP NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMP NOT NULL DEFAULT NOW()
      );
    `);
    console.log('✓ user_wallets table created/verified');
    
    // Create rights table if not exists
    await db.execute(`
      CREATE TABLE IF NOT EXISTS rights (
        id SERIAL PRIMARY KEY,
        asset_id TEXT NOT NULL,
        asset_type TEXT NOT NULL,
        rights_type TEXT NOT NULL,
        owner_id INTEGER NOT NULL,
        owner_type TEXT NOT NULL,
        percentage NUMERIC NOT NULL,
        territory TEXT,
        start_date TIMESTAMP NOT NULL,
        end_date TIMESTAMP,
        blockchain_reference TEXT,
        status TEXT NOT NULL DEFAULT 'active',
        source TEXT NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMP NOT NULL DEFAULT NOW()
      );
    `);
    console.log('✓ rights table created/verified');
    
    // Create rights_conflicts table if not exists
    await db.execute(`
      CREATE TABLE IF NOT EXISTS rights_conflicts (
        id SERIAL PRIMARY KEY,
        asset_id TEXT NOT NULL,
        conflict_type TEXT NOT NULL,
        rights_ids INTEGER[] NOT NULL,
        status TEXT NOT NULL DEFAULT 'open',
        resolution_notes TEXT,
        created_at TIMESTAMP NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMP NOT NULL DEFAULT NOW()
      );
    `);
    console.log('✓ rights_conflicts table created/verified');
    
    // Ensure royalty_calculations table exists
    await db.execute(`
      CREATE TABLE IF NOT EXISTS royalty_calculations (
        id SERIAL PRIMARY KEY,
        distribution_record_id INTEGER NOT NULL,
        release_id INTEGER NOT NULL,
        track_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        amount NUMERIC NOT NULL,
        stream_count INTEGER NOT NULL DEFAULT 0,
        rate_per_stream NUMERIC,
        timeframe JSONB,
        royalty_type TEXT NOT NULL,
        platform_id INTEGER,
        split_percentage NUMERIC NOT NULL,
        recipient_id INTEGER NOT NULL,
        is_processed BOOLEAN NOT NULL DEFAULT false,
        is_paid BOOLEAN NOT NULL DEFAULT false,
        processing_date TIMESTAMP,
        payment_date TIMESTAMP,
        payment_reference TEXT,
        created_at TIMESTAMP NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMP NOT NULL DEFAULT NOW()
      );
    `);
    console.log('✓ royalty_calculations table created/verified');
    
    // Ensure distribution_records table exists
    await db.execute(`
      CREATE TABLE IF NOT EXISTS distribution_records (
        id SERIAL PRIMARY KEY,
        release_id INTEGER NOT NULL,
        platform_id INTEGER NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending',
        distribution_date TIMESTAMP,
        platform_release_id TEXT,
        platform_metadata JSONB NOT NULL DEFAULT '{}',
        status_details JSONB,
        error_details JSONB,
        retry_count INTEGER DEFAULT 0,
        next_retry_at TIMESTAMP,
        last_checked TIMESTAMP,
        last_attempt TIMESTAMP,
        royalty_integration_status TEXT,
        last_update_details JSONB,
        created_at TIMESTAMP NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMP NOT NULL DEFAULT NOW()
      );
    `);
    console.log('✓ distribution_records table created/verified');
    
    // Ensure distribution_platforms table exists
    await db.execute(`
      CREATE TABLE IF NOT EXISTS distribution_platforms (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL UNIQUE,
        type TEXT NOT NULL,
        api_credentials JSONB NOT NULL DEFAULT '{}',
        status TEXT NOT NULL DEFAULT 'active',
        icon TEXT,
        color TEXT,
        created_at TIMESTAMP NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMP NOT NULL DEFAULT NOW()
      );
    `);
    console.log('✓ distribution_platforms table created/verified');
    
    console.log('Database setup completed successfully!');
  } catch (error) {
    console.error('Error setting up database:', error);
  } finally {
    // Close DB connection
    try {
      await pool.end();
      console.log('Database connection closed');
    } catch (e) {
      console.error('Error closing database connection:', e);
    }
  }
}

// Run setup
setupDatabase();