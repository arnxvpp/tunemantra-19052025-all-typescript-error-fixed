/**
 * Rights Management Simulation Test Script
 * 
 * This script simulates rights management functionality without requiring actual database access.
 * It tests the core logic of rights handling, conflict detection, and ownership verification.
 * 
 * Usage: npx tsx scripts/rights-management-simulator.ts
 */

// Types representing the rights data structures
interface RightsRecord {
  id: number;
  assetId: string;
  userId: number;
  rightsType: string;
  territory: string[];
  startDate: Date;
  endDate: Date | null;
  percentage: number;
  status: 'active' | 'pending' | 'expired' | 'transferred' | 'disputed';
  verificationStatus: 'verified' | 'unverified' | 'blockchain_verified';
  blockchainReference?: string;
  createdAt: Date;
  updatedAt: Date;
}

interface RightsConflict {
  id: number;
  assetId: string;
  rightsTypeId: number;
  conflictingRightsId: number;
  status: 'active' | 'resolved';
  resolution?: string;
  createdAt: Date;
  updatedAt: Date;
}

interface RightsTransfer {
  id: number;
  rightsId: number;
  fromUserId: number;
  toUserId: number;
  percentage: number;
  status: 'pending' | 'completed' | 'rejected';
  createdAt: Date;
  updatedAt: Date;
}

/**
 * Rights Management Simulation class
 */
class RightsManagementSimulator {
  private nextId: number = 1;
  private rights: RightsRecord[] = [];
  private conflicts: RightsConflict[] = [];
  private transfers: RightsTransfer[] = [];
  
  constructor() {
    console.log('Rights management simulator initialized');
  }
  
  /**
   * Register new rights for an asset
   */
  async registerRights(data: {
    assetId: string;
    userId: number;
    rightsType: string;
    territory: string[];
    startDate: Date;
    endDate?: Date | null;
    percentage: number;
  }): Promise<{ success: boolean; rightsId?: number; message?: string; conflicts?: any[] }> {
    console.log(`Registering ${data.rightsType} rights for asset ${data.assetId} by user ${data.userId}`);
    
    // Check for conflicts with existing rights
    const conflicts = await this.checkForConflicts(
      data.assetId,
      data.rightsType,
      undefined,
      data.territory,
      data.startDate,
      data.endDate || null,
      data.percentage
    );
    
    if (conflicts.length > 0) {
      console.log(`Found ${conflicts.length} conflicts with existing rights`);
      return {
        success: false,
        message: 'Rights registration would create conflicts with existing rights',
        conflicts
      };
    }
    
    // Create new rights record
    const rightsId = this.nextId++;
    const rightsRecord: RightsRecord = {
      id: rightsId,
      assetId: data.assetId,
      userId: data.userId,
      rightsType: data.rightsType,
      territory: data.territory,
      startDate: data.startDate,
      endDate: data.endDate || null,
      percentage: data.percentage,
      status: 'active',
      verificationStatus: 'unverified',
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    this.rights.push(rightsRecord);
    
    console.log(`Successfully registered rights with ID ${rightsId}`);
    return {
      success: true,
      rightsId,
      message: 'Rights registered successfully'
    };
  }
  
  /**
   * Check for conflicts with existing rights
   */
  async checkForConflicts(
    assetId: string,
    rightsType: string,
    excludeRightsId?: number,
    territory: string[] = ['GLOBAL'],
    startDate: Date = new Date(),
    endDate: Date | null = null,
    percentage: number = 100
  ): Promise<any[]> {
    console.log(`Checking for ${rightsType} rights conflicts on asset ${assetId}`);
    
    const conflicts: any[] = [];
    
    // Filter rights records that could conflict
    const potentialConflicts = this.rights.filter(rights => 
      rights.assetId === assetId &&
      rights.rightsType === rightsType &&
      rights.id !== excludeRightsId &&
      rights.status === 'active'
    );
    
    for (const existing of potentialConflicts) {
      // Check for territorial conflicts
      const hasTerritoralOverlap = this.checkTerritorialOverlap(existing.territory, territory);
      
      // Check for time period conflicts
      const hasTimeOverlap = this.checkTimeOverlap(
        existing.startDate,
        existing.endDate,
        startDate,
        endDate
      );
      
      // If both territorial and time overlaps exist, we have a conflict
      if (hasTerritoralOverlap && hasTimeOverlap) {
        // Check if total percentage exceeds 100%
        const totalPercentage = existing.percentage + percentage;
        
        if (totalPercentage > 100) {
          conflicts.push({
            conflictingRightsId: existing.id,
            userId: existing.userId,
            rightsType,
            territory: existing.territory,
            startDate: existing.startDate,
            endDate: existing.endDate,
            percentage: existing.percentage,
            conflictType: 'percentage_exceeded',
            message: `Total percentage (${totalPercentage}%) exceeds 100%`
          });
        }
      }
    }
    
    return conflicts;
  }
  
  /**
   * Check if two time periods overlap
   */
  private checkTimeOverlap(
    existingStart: Date,
    existingEnd: Date | null,
    newStart: Date,
    newEnd: Date | null
  ): boolean {
    // If either period has no end date, it extends indefinitely
    if (existingEnd === null && newEnd === null) {
      return true; // Both extend indefinitely, so they overlap
    }
    
    if (existingEnd === null) {
      // Existing rights extend indefinitely
      return newStart <= existingStart || newEnd === null || newEnd > existingStart;
    }
    
    if (newEnd === null) {
      // New rights extend indefinitely
      return existingStart <= newStart || existingEnd > newStart;
    }
    
    // Both have end dates, check for overlap
    return (
      (newStart >= existingStart && newStart <= existingEnd) ||
      (newEnd >= existingStart && newEnd <= existingEnd) ||
      (newStart <= existingStart && newEnd >= existingEnd)
    );
  }
  
  /**
   * Check if two territory arrays overlap
   */
  private checkTerritorialOverlap(
    existingTerritories: string[],
    newTerritories: string[]
  ): boolean {
    // If either includes 'GLOBAL', there's an overlap
    if (existingTerritories.includes('GLOBAL') || newTerritories.includes('GLOBAL')) {
      return true;
    }
    
    // Check for any overlapping territories
    return existingTerritories.some(territory => newTerritories.includes(territory));
  }
  
  /**
   * Verify if a user has ownership rights for an asset
   */
  async verifyRightsOwnership(
    assetId: string,
    rightsType: string,
    userId: number
  ): Promise<{
    hasRights: boolean;
    percentage?: number;
    territories?: string[];
    conflictsExist?: boolean;
    message?: string;
  }> {
    console.log(`Verifying ${rightsType} rights ownership for asset ${assetId} by user ${userId}`);
    
    // Find active rights records for this asset, type, and user
    const userRights = this.rights.filter(
      rights =>
        rights.assetId === assetId &&
        rights.rightsType === rightsType &&
        rights.userId === userId &&
        rights.status === 'active'
    );
    
    if (userRights.length === 0) {
      return {
        hasRights: false,
        message: 'No active rights found for this user'
      };
    }
    
    // Calculate total percentage owned by user
    const totalPercentage = userRights.reduce(
      (sum, rights) => sum + rights.percentage,
      0
    );
    
    // Get all territories covered
    const territories = Array.from(
      new Set(
        userRights.flatMap(rights => rights.territory)
      )
    );
    
    // Check for conflicts
    const conflicts = this.conflicts.filter(
      conflict =>
        conflict.status === 'active' &&
        userRights.some(rights => rights.id === conflict.rightsTypeId || rights.id === conflict.conflictingRightsId)
    );
    
    return {
      hasRights: true,
      percentage: totalPercentage,
      territories,
      conflictsExist: conflicts.length > 0,
      message: `User owns ${totalPercentage}% of ${rightsType} rights`
    };
  }
  
  /**
   * Register rights with blockchain verification
   */
  async registerRightsWithBlockchain(
    data: {
      assetId: string;
      userId: number;
      rightsType: string;
      territory: string[];
      startDate: Date;
      endDate?: Date | null;
      percentage: number;
      blockchainNetwork?: string;
    }
  ): Promise<{
    success: boolean;
    rightsId?: number;
    blockchainReference?: string;
    message?: string;
  }> {
    console.log(`Registering blockchain-verified ${data.rightsType} rights for asset ${data.assetId}`);
    
    // First register the rights normally
    const registrationResult = await this.registerRights(data);
    
    if (!registrationResult.success) {
      return {
        success: false,
        message: registrationResult.message
      };
    }
    
    const rightsId = registrationResult.rightsId;
    
    // Simulate blockchain verification
    const blockchainReference = `bct-${Date.now()}-${Math.floor(Math.random() * 1000000)}`;
    
    // Update the rights record with blockchain verification
    const rightsRecord = this.rights.find(r => r.id === rightsId);
    if (rightsRecord) {
      rightsRecord.verificationStatus = 'blockchain_verified';
      rightsRecord.blockchainReference = blockchainReference;
      rightsRecord.updatedAt = new Date();
    }
    
    console.log(`Rights registered and verified on blockchain with reference ${blockchainReference}`);
    
    return {
      success: true,
      rightsId,
      blockchainReference,
      message: 'Rights registered and verified on blockchain successfully'
    };
  }
  
  /**
   * Get all rights for an asset
   */
  async getAssetRights(
    assetId: string,
    rightsType?: string
  ): Promise<RightsRecord[]> {
    // Filter rights based on asset ID and optional rights type
    return this.rights.filter(
      rights =>
        rights.assetId === assetId &&
        (rightsType ? rights.rightsType === rightsType : true)
    );
  }
  
  /**
   * Get all rights owned by a user
   */
  async getUserRights(
    userId: number,
    options: {
      page?: number;
      limit?: number;
      rightsType?: string;
      status?: string;
    } = {}
  ): Promise<{
    rights: RightsRecord[];
    total: number;
  }> {
    const { page = 1, limit = 10, rightsType, status } = options;
    
    // Filter rights based on user ID and optional filters
    const filteredRights = this.rights.filter(
      rights =>
        rights.userId === userId &&
        (rightsType ? rights.rightsType === rightsType : true) &&
        (status ? rights.status === status : true)
    );
    
    // Pagination
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    
    return {
      rights: filteredRights.slice(startIndex, endIndex),
      total: filteredRights.length
    };
  }
  
  /**
   * Get blockchain-verified rights
   */
  async getBlockchainVerifiedRights(
    userId: number,
    options: {
      page?: number;
      limit?: number;
    } = {}
  ): Promise<{
    rights: RightsRecord[];
    total: number;
  }> {
    const { page = 1, limit = 10 } = options;
    
    // Filter blockchain-verified rights for this user
    const verifiedRights = this.rights.filter(
      rights =>
        rights.userId === userId &&
        rights.verificationStatus === 'blockchain_verified'
    );
    
    // Pagination
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    
    return {
      rights: verifiedRights.slice(startIndex, endIndex),
      total: verifiedRights.length
    };
  }
  
  /**
   * Initialize with some test data
   */
  initializeTestData(): void {
    // Add some test tracks
    const assetIds = [
      'track-123',
      'track-456',
      'track-789'
    ];
    
    // Add test users
    const userIds = [101, 102, 103];
    
    // Add test rights
    this.rights.push({
      id: this.nextId++,
      assetId: assetIds[0],
      userId: userIds[0],
      rightsType: 'master',
      territory: ['GLOBAL'],
      startDate: new Date('2024-01-01'),
      endDate: new Date('2029-12-31'),
      percentage: 100,
      status: 'active',
      verificationStatus: 'verified',
      createdAt: new Date(),
      updatedAt: new Date()
    });
    
    this.rights.push({
      id: this.nextId++,
      assetId: assetIds[1],
      userId: userIds[1],
      rightsType: 'publishing',
      territory: ['US', 'CA'],
      startDate: new Date('2024-01-01'),
      endDate: null,
      percentage: 75,
      status: 'active',
      verificationStatus: 'unverified',
      createdAt: new Date(),
      updatedAt: new Date()
    });
    
    this.rights.push({
      id: this.nextId++,
      assetId: assetIds[1],
      userId: userIds[2],
      rightsType: 'publishing',
      territory: ['US', 'CA'],
      startDate: new Date('2024-01-01'),
      endDate: null,
      percentage: 25,
      status: 'active',
      verificationStatus: 'unverified',
      createdAt: new Date(),
      updatedAt: new Date()
    });
    
    console.log(`Initialized ${this.rights.length} test rights records`);
  }
}

/**
 * Main test function to simulate rights management operations
 */
async function simulateRightsManagement(): Promise<void> {
  console.log('Starting rights management simulation tests...');
  
  const simulator = new RightsManagementSimulator();
  simulator.initializeTestData();
  
  // Test 1: Verify rights ownership
  console.log('\n--- Testing Rights Ownership Verification ---');
  const ownershipResult = await simulator.verifyRightsOwnership('track-123', 'master', 101);
  console.log(`Ownership verification result: ${JSON.stringify(ownershipResult, null, 2)}`);
  
  // Test 2: Check for conflicts - add overlapping rights to create a conflict
  console.log('\n--- Testing Conflict Detection ---');
  const conflictResult = await simulator.registerRights({
    assetId: 'track-123',
    userId: 102,
    rightsType: 'master',
    territory: ['GLOBAL'],
    startDate: new Date('2025-01-01'),
    endDate: new Date('2026-12-31'),
    percentage: 50
  });
  console.log(`Conflict detection result: ${JSON.stringify(conflictResult, null, 2)}`);
  
  // Test 3: Register rights with blockchain verification
  console.log('\n--- Testing Blockchain Rights Registration ---');
  const blockchainRegistration = await simulator.registerRightsWithBlockchain({
    assetId: 'track-789',
    userId: 103,
    rightsType: 'master',
    territory: ['EU', 'UK'],
    startDate: new Date('2024-03-01'),
    percentage: 100,
    blockchainNetwork: 'polygon'
  });
  console.log(`Blockchain registration result: ${JSON.stringify(blockchainRegistration, null, 2)}`);
  
  // Test 4: Get all rights for an asset
  console.log('\n--- Testing Asset Rights Retrieval ---');
  const assetRights = await simulator.getAssetRights('track-456');
  console.log(`Asset rights (${assetRights.length} found):`);
  for (const rights of assetRights) {
    console.log(`- ${rights.rightsType} rights: ${rights.percentage}% owned by user ${rights.userId}`);
  }
  
  // Test 5: Get user rights
  console.log('\n--- Testing User Rights Retrieval ---');
  const userRights = await simulator.getUserRights(103);
  console.log(`User rights for user 103: ${userRights.total} found`);
  for (const rights of userRights.rights) {
    console.log(`- ${rights.percentage}% ${rights.rightsType} rights for asset ${rights.assetId}`);
    if (rights.blockchainReference) {
      console.log(`  Blockchain verified: ${rights.blockchainReference}`);
    }
  }
  
  console.log('\nAll simulation tests completed successfully.');
}

// Run simulation
simulateRightsManagement();