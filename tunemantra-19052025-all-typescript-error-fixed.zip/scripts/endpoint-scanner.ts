/**
 * Endpoint Scanner
 * 
 * This utility scans all route files in the project to create a comprehensive
 * inventory of API endpoints with their validation status.
 * 
 * It identifies:
 * - HTTP method (GET, POST, PUT, DELETE)
 * - Path
 * - Whether validation is already implemented
 * - Risk level based on the operation
 */

import * as fs from 'fs';
import * as path from 'path';
import * as readline from 'readline';
import { promisify } from 'util';
import { glob } from 'glob';
import { fileURLToPath } from 'url';

// Handle ESM module path resolution
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Constants
const SERVER_DIR = path.join(__dirname, '../server');
const ROUTES_DIR = path.join(SERVER_DIR, 'routes');
const OUTPUT_FILE = path.join(__dirname, 'endpoint-inventory.json');

// Promisify fs functions
const readFileAsync = promisify(fs.readFile);
const writeFileAsync = promisify(fs.writeFile);

// Interface for endpoint data
interface Endpoint {
  method: string;
  path: string;
  file: string;
  hasValidation: boolean;
  riskLevel: 'high' | 'medium' | 'low';
  validationSchema?: string;
  lineNumber: number;
}

/**
 * Determine risk level based on method and path
 */
function determineRiskLevel(method: string, path: string): 'high' | 'medium' | 'low' {
  // Higher risk for data modification operations
  if (['POST', 'PUT', 'DELETE', 'PATCH'].includes(method.toUpperCase())) {
    return 'high';
  }
  
  // Medium risk for admin or privileged user operations
  if (path.includes('/admin') || path.includes('/approve') || path.includes('/payment')) {
    return 'medium';
  }
  
  // Lower risk for read-only operations
  return 'low';
}

/**
 * Check if validation is present for an endpoint
 */
function hasValidation(line: string): boolean {
  return line.includes('validateRequest') || 
         line.includes('validateFileUpload') || 
         line.includes('validate') && line.includes('Schema');
}

/**
 * Find validation schema if present
 */
function extractValidationSchema(line: string): string | undefined {
  const match = line.match(/validateRequest\(([^,)]+)/);
  if (match && match[1]) {
    return match[1].trim();
  }
  return undefined;
}

/**
 * Process a single route file to extract endpoints
 */
async function processRouteFile(filePath: string): Promise<Endpoint[]> {
  const fileContent = await readFileAsync(filePath, 'utf8');
  const lines = fileContent.split('\n');
  const endpoints: Endpoint[] = [];
  const relativePath = path.relative(SERVER_DIR, filePath);

  const routeRegex = /router\.(get|post|put|delete|patch)\s*\(\s*['"]([^'"]+)['"]/i;
  const routePrefix = extractRoutePrefix(fileContent);

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const match = line.match(routeRegex);
    
    if (match) {
      const method = match[1].toUpperCase();
      let routePath = match[2];
      
      // Adjust path if route prefix is used
      if (routePrefix && !routePath.startsWith('/')) {
        routePath = `${routePrefix}/${routePath}`.replace(/\/+/g, '/');
      } else if (routePrefix) {
        routePath = `${routePrefix}${routePath}`.replace(/\/+/g, '/');
      }
      
      // Check next few lines for validation
      let validationFound = false;
      let validationSchema: string | undefined = undefined;
      
      for (let j = i; j < Math.min(i + 5, lines.length); j++) {
        if (hasValidation(lines[j])) {
          validationFound = true;
          validationSchema = extractValidationSchema(lines[j]);
          break;
        }
      }
      
      endpoints.push({
        method,
        path: routePath,
        file: relativePath,
        hasValidation: validationFound,
        riskLevel: determineRiskLevel(method, routePath),
        validationSchema,
        lineNumber: i + 1
      });
    }
  }

  return endpoints;
}

/**
 * Extract route prefix if used with router.use()
 */
function extractRoutePrefix(fileContent: string): string | null {
  const lines = fileContent.split('\n');
  
  // Look for patterns like:
  // router.use('/prefix', subRouter)
  // or app.use('/prefix', router)
  const prefixRegex = /\.(use|useRouter)\s*\(\s*['"]([^'"]+)['"]/i;
  
  for (const line of lines) {
    const match = line.match(prefixRegex);
    if (match && match[2]) {
      return match[2];
    }
  }
  
  return null;
}

/**
 * Main execution function
 */
async function main() {
  try {
    // Find all route files
    const routeFiles = await glob(`${ROUTES_DIR}/**/*.ts`);
    
    // Add main routes.ts file
    routeFiles.push(path.join(SERVER_DIR, 'routes.ts'));
    
    console.log(`Found ${routeFiles.length} route files to process`);
    
    // Process all files
    const endpoints: Endpoint[] = [];
    for (const file of routeFiles) {
      const fileEndpoints = await processRouteFile(file);
      endpoints.push(...fileEndpoints);
      console.log(`Processed ${file}: found ${fileEndpoints.length} endpoints`);
    }
    
    // Generate statistics
    const totalEndpoints = endpoints.length;
    const validatedEndpoints = endpoints.filter(e => e.hasValidation).length;
    const highRiskEndpoints = endpoints.filter(e => e.riskLevel === 'high').length;
    const highRiskValidated = endpoints.filter(e => e.riskLevel === 'high' && e.hasValidation).length;
    
    const summary = {
      totalEndpoints,
      validatedEndpoints,
      validationCoverage: `${((validatedEndpoints / totalEndpoints) * 100).toFixed(2)}%`,
      highRiskEndpoints,
      highRiskValidated,
      highRiskCoverage: `${((highRiskValidated / highRiskEndpoints) * 100).toFixed(2)}%`,
      endpoints
    };
    
    // Save the results
    await writeFileAsync(OUTPUT_FILE, JSON.stringify(summary, null, 2));
    
    console.log('Endpoint inventory complete!');
    console.log(`Total endpoints: ${totalEndpoints}`);
    console.log(`Validated endpoints: ${validatedEndpoints} (${summary.validationCoverage})`);
    console.log(`High-risk endpoints: ${highRiskEndpoints}`);
    console.log(`High-risk with validation: ${highRiskValidated} (${summary.highRiskCoverage})`);
    console.log(`Results saved to ${OUTPUT_FILE}`);
  } catch (error) {
    console.error('Error generating endpoint inventory:', error);
  }
}

main();